# PS ASSISTANT V1.5 — AI4Bharat IndicTTS Voice

Configured voice profile:
- Engine: AI4Bharat IndicTTS
- Language: Hindi (`hi`)
- Gender: Female
- Requested sample rate: 48000 Hz
- Local endpoint: `http://127.0.0.1:5050/`
- Used by both Admin Training and phone/voice sessions.

This project does not scrape the public AI4Bharat demo. It is designed to use the open-source Indic-TTS inference server locally on the office PC.

## Official local server

1. Clone `AI4Bharat/Indic-TTS`.
2. Enter its `inference` directory.
3. Install the official server/ML/utils requirements.
4. Download the Hindi checkpoint into `inference/checkpoints/hi`.
5. Start the official server on port 5050:

```powershell
uvicorn server:api --host 127.0.0.1 --port 5050
```

The Admin UI sends this request shape:

```json
{
  "input": [{"source": "नमस्ते, मैं PS ASSISTANT V1.5 बोल रही हूँ।"}],
  "config": {
    "language": {"sourceLanguage": "hi"},
    "gender": "female",
    "samplingRate": 48000
  }
}
```

The frontend reads `audio[0].audioContent` from the official response and plays the WAV audio.

If the local IndicTTS service is unavailable, browser voice fallback can be enabled/disabled from Developer > System Control.

## Windows one-click helper included in this project

From the project root:

```powershell
powershell -ExecutionPolicy Bypass -File .\phone-bridge\indictts\setup-indictts.ps1
powershell -ExecutionPolicy Bypass -File .\phone-bridge\indictts\start-indictts.ps1
```

The custom `server_hindi.py` loads only the Hindi checkpoint and automatically uses CUDA when PyTorch sees a supported GPU; otherwise it attempts CPU inference.
