$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Repo = Join-Path $Here "AI4Bharat-Indic-TTS"
$EnvName = "ps-indictts"

Write-Host "PS ASSISTANT V1.5 - AI4Bharat IndicTTS Hindi Female setup" -ForegroundColor Cyan
if (-not (Get-Command conda -ErrorAction SilentlyContinue)) { throw "Conda/Anaconda is required for this one-click Windows setup." }
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw "Git is required. Install Git for Windows and run this again." }

$envList = conda env list
if ($envList -notmatch "(?m)^$EnvName\s") {
  Write-Host "Creating Python 3.10 environment..."
  conda create -n $EnvName python=3.10 -y
}

if (-not (Test-Path $Repo)) {
  Write-Host "Cloning official AI4Bharat Indic-TTS..."
  git clone https://github.com/AI4Bharat/Indic-TTS.git $Repo
}

$Inference = Join-Path $Repo "inference"
Write-Host "Installing official inference dependencies..."
conda run -n $EnvName python -m pip install --upgrade pip
conda run -n $EnvName python -m pip install -r (Join-Path $Inference "requirements-server.txt") -r (Join-Path $Inference "requirements-ml.txt") -r (Join-Path $Inference "requirements-utils.txt")

$Checkpoints = Join-Path $Inference "checkpoints"
$Hindi = Join-Path $Checkpoints "hi"
if (-not (Test-Path (Join-Path $Hindi "fastpitch\best_model.pth"))) {
  New-Item -ItemType Directory -Force -Path $Checkpoints | Out-Null
  $Zip = Join-Path $Here "hi.zip"
  Write-Host "Downloading official Hindi model checkpoint..."
  Invoke-WebRequest -Uri "https://github.com/AI4Bharat/Indic-TTS/releases/download/v1-checkpoints-release/hi.zip" -OutFile $Zip
  $Temp = Join-Path $Here "_hi_extract"
  Remove-Item $Temp -Recurse -Force -ErrorAction SilentlyContinue
  Expand-Archive -Path $Zip -DestinationPath $Temp -Force
  if (Test-Path (Join-Path $Temp "hi")) {
    Remove-Item $Hindi -Recurse -Force -ErrorAction SilentlyContinue
    Move-Item (Join-Path $Temp "hi") $Hindi
  } else {
    New-Item -ItemType Directory -Force -Path $Hindi | Out-Null
    Copy-Item (Join-Path $Temp "*") $Hindi -Recurse -Force
  }
  Remove-Item $Temp -Recurse -Force
  Remove-Item $Zip -Force
}

Write-Host "Setup complete." -ForegroundColor Green
Write-Host "Start voice with: powershell -ExecutionPolicy Bypass -File .\phone-bridge\indictts\start-indictts.ps1"
