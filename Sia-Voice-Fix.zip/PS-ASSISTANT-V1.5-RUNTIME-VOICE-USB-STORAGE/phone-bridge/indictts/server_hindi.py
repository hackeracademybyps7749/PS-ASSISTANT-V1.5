"""PS ASSISTANT V1.5 local AI4Bharat IndicTTS server (Hindi only).
Run from the official AI4Bharat/Indic-TTS/inference directory or set INDIC_TTS_INFERENCE.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
INFERENCE = Path(os.environ.get("INDIC_TTS_INFERENCE", HERE / "AI4Bharat-Indic-TTS" / "inference")).resolve()
if not INFERENCE.exists():
    raise RuntimeError(f"Indic-TTS inference folder not found: {INFERENCE}")
sys.path.insert(0, str(INFERENCE))
os.chdir(INFERENCE)

import torch  # type: ignore
from fastapi import FastAPI, Request  # type: ignore
from fastapi.middleware.cors import CORSMiddleware  # type: ignore
from TTS.utils.synthesizer import Synthesizer  # type: ignore
from src.inference import TextToSpeechEngine  # type: ignore
from src.models.request import TTSRequest  # type: ignore

use_cuda = bool(torch.cuda.is_available())
print(f"[PS ASSISTANT] Loading AI4Bharat IndicTTS Hindi model. CUDA={use_cuda}")

model = Synthesizer(
    tts_checkpoint="checkpoints/hi/fastpitch/best_model.pth",
    tts_config_path="checkpoints/hi/fastpitch/config.json",
    tts_speakers_file="checkpoints/hi/fastpitch/speakers.pth",
    tts_languages_file=None,
    vocoder_checkpoint="checkpoints/hi/hifigan/best_model.pth",
    vocoder_config="checkpoints/hi/hifigan/config.json",
    encoder_checkpoint="",
    encoder_config="",
    use_cuda=use_cuda,
)
engine = TextToSpeechEngine({"hi": model}, allow_transliteration=True)

api = FastAPI(title="PS ASSISTANT IndicTTS Hindi Voice")
api.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@api.middleware("http")
async def local_network_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["Access-Control-Allow-Private-Network"] = "true"
    response.headers["Cache-Control"] = "no-store"
    return response

@api.get("/health")
def health():
    return {
        "ok": True,
        "engine": "AI4Bharat IndicTTS",
        "language": "hi",
        "gender": "female",
        "cuda": use_cuda,
    }

@api.post("/")
async def synthesize(request: TTSRequest):
    # Gender/language are taken from the request. PS ASSISTANT defaults to hi/female.
    return engine.infer_from_request(request)
