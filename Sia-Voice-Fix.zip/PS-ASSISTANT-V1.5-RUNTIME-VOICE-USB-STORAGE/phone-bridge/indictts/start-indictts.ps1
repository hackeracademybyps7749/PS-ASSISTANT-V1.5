$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Repo = Join-Path $Here "AI4Bharat-Indic-TTS"
$Inference = Join-Path $Repo "inference"
if (-not (Test-Path $Inference)) { throw "IndicTTS is not installed. Run setup-indictts.ps1 first." }
$env:INDIC_TTS_INFERENCE = $Inference
Write-Host "Starting PS ASSISTANT IndicTTS Hindi Female on http://127.0.0.1:5050" -ForegroundColor Green
conda run -n ps-indictts python -m uvicorn server_hindi:api --app-dir $Here --host 127.0.0.1 --port 5050
