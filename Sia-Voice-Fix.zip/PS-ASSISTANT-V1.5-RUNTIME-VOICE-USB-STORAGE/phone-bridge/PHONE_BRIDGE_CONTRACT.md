# PS ASSISTANT V1.5 — Phone Bridge Contract

Cloudflare Workers cannot directly place a cellular/PSTN call. A real call transport is connected through the Developer Console → System Control → Phone Bridge URL.

## 1. Dial request sent by PS ASSISTANT
The configured bridge receives an HTTP POST with JSON similar to:
```json
{
  "call_id": 123,
  "client_id": 55,
  "phone": "+9198XXXXXXXX",
  "call_ref": "PS-12345678",
  "business_name": "Example Business",
  "callback_base": "/api/bridge"
}
```
Authenticate the dial endpoint with the optional Bearer token configured in Developer Console.

## 2. Bridge callbacks
The bridge calls the deployed PS ASSISTANT Worker using the same bridge token.

### Call started
POST `/api/bridge/event`
```json
{"call_id":123,"event":"started"}
```

### AI turn
After the bridge performs STT on the customer speech, POST `/api/bridge/ai-turn`:
```json
{"call_id":123,"text":"Website kitne me banegi?"}
```
Response:
```json
{"ok":true,"text":"...PS ASSISTANT reply...","needsAdmin":false,"language":"hi-IN"}
```
The bridge converts `text` to speech using its TTS engine and plays it to the customer. If the customer interrupts, the bridge should stop TTS playback, capture the new utterance, and call `/api/bridge/ai-turn` again.

### Call ended
POST `/api/bridge/event`
```json
{"call_id":123,"event":"ended","duration_seconds":315,"outcome":"interested"}
```

## 3. Automatic scheduler
A Cloudflare Cron Trigger runs every minute. It checks the active campaign, start/end time, call interval, retry gap and per-client attempt limit. When a call is due, it sends a dial request to the configured bridge.

## 4. Supported transports
The bridge can be implemented as an authorized:
- SIP/PBX adapter
- GSM gateway service
- Android/SIM bridge under your control
- Twilio/Exotel/other compliant telephony adapter
- custom HTTP telephony service

The AI/backend remains unchanged when the transport changes.
