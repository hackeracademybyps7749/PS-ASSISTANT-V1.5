from __future__ import annotations

import asyncio
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from starlette.background import BackgroundTask
from pydantic import BaseModel

try:
    import edge_tts
except Exception:
    edge_tts = None

ROOT = Path(__file__).resolve().parent
ADB_CANDIDATES = [
    os.environ.get("PS_ADB", ""),
    str(ROOT / "platform-tools" / "adb.exe"),
    str(ROOT / "platform-tools" / "adb"),
    shutil.which("adb") or "",
]
ADB = next((x for x in ADB_CANDIDATES if x and Path(x).exists()), shutil.which("adb") or "adb")

app = FastAPI(title="PS ASSISTANT V1.5 USB Phone Bridge", version="1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r"^(https://([a-z0-9-]+\.)*psassistant\.online|https://[a-z0-9.-]+\.workers\.dev|http://(127\.0\.0\.1|localhost)(:\d+)?)$",
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.middleware("http")
async def private_network_header(request: Request, call_next):
    response = await call_next(request)
    response.headers["Access-Control-Allow-Private-Network"] = "true"
    response.headers["Cache-Control"] = "no-store"
    return response

class DialBody(BaseModel):
    phone: str

class TtsBody(BaseModel):
    text: str
    voice: str = "hi-IN-SwaraNeural"
    rate: str = "+10%"
    pitch: str = "+4Hz"


def run_adb(*args: str, timeout: float = 8.0, check: bool = False) -> subprocess.CompletedProcess:
    try:
        return subprocess.run([ADB, *args], capture_output=True, text=True, timeout=timeout, check=check)
    except FileNotFoundError as exc:
        raise HTTPException(503, "ADB not installed. Run SETUP-USB-PHONE-BRIDGE.ps1 first.") from exc
    except subprocess.TimeoutExpired as exc:
        raise HTTPException(504, "Android phone did not respond in time.") from exc


def devices():
    p = run_adb("devices")
    rows = []
    for line in p.stdout.splitlines()[1:]:
        line = line.strip()
        if not line:
            continue
        bits = line.split()
        if len(bits) >= 2:
            rows.append({"serial": bits[0], "state": bits[1]})
    return rows


def ready_device():
    ds = devices()
    good = [x for x in ds if x["state"] == "device"]
    if not good:
        return None
    return good[0]


def prop(name: str) -> str:
    p = run_adb("shell", "getprop", name)
    return p.stdout.strip()


def battery_percent() -> Optional[int]:
    p = run_adb("shell", "dumpsys", "battery")
    m = re.search(r"level:\s*(\d+)", p.stdout)
    return int(m.group(1)) if m else None


def parse_android_call_state(telecom: str, telephony: str) -> str:
    states = [int(x) for x in re.findall(r"mCallState\s*=\s*(\d+)", telephony)]
    # Current telephony states take precedence over historical telecom dumps.
    if states and all(x == 0 for x in states):
        return "IDLE"
    if 1 in states and 2 not in states:
        return "RINGING"
    live = re.split(r"Historical Calls|Call History|HistoricalCalls", telecom, maxsplit=1, flags=re.I)[0].upper()
    if re.search(r"(?:STATE|MSTATE)\s*[:=]\s*ACTIVE\b", live):
        return "ACTIVE"
    if re.search(r"(?:STATE|MSTATE)\s*[:=]\s*(DIALING|CONNECTING|SELECT_PHONE_ACCOUNT|NEW)\b", live):
        return "DIALING"
    if re.search(r"(?:STATE|MSTATE)\s*[:=]\s*RINGING\b", live):
        return "RINGING"
    if 2 in states:
        return "OFFHOOK"
    return "UNKNOWN"


def parse_call_state() -> str:
    telephony = run_adb("shell", "dumpsys", "telephony.registry", timeout=4).stdout
    states = [int(x) for x in re.findall(r"mCallState\s*=\s*(\d+)", telephony)]
    if states and all(x == 0 for x in states):
        return "IDLE"
    telecom = run_adb("shell", "dumpsys", "telecom", timeout=4).stdout
    return parse_android_call_state(telecom, telephony)


@app.get("/health")
def health():
    ds = devices()
    d = ready_device()
    return {
        "ok": True,
        "adb": ADB,
        "devices": ds,
        "connected": bool(d),
        "serial": d["serial"] if d else None,
        "model": prop("ro.product.model") if d else None,
        "manufacturer": prop("ro.product.manufacturer") if d else None,
        "android": prop("ro.build.version.release") if d else None,
        "battery": battery_percent() if d else None,
        "call_state": "CONNECTED" if d else "DISCONNECTED",
        "neural_tts": edge_tts is not None,
        "voice": "hi-IN-SwaraNeural",
    }


@app.post("/connect")
def connect():
    # Starting adb-server is safe and makes the Connect button deterministic.
    run_adb("start-server", timeout=10)
    info = health()
    if not info["connected"]:
        raise HTTPException(409, "Phone not authorized. USB debugging ON karke phone par Allow USB debugging press karo.")
    return info


@app.get("/call-state")
def call_state():
    d = ready_device()
    if not d:
        raise HTTPException(409, "Phone disconnected")
    return {"ok": True, "state": parse_call_state(), "battery": battery_percent()}


@app.post("/dial")
def dial(body: DialBody):
    d = ready_device()
    if not d:
        raise HTTPException(409, "Phone disconnected")
    phone = re.sub(r"[^0-9+]", "", body.phone or "")
    if not re.fullmatch(r"\+?\d{7,15}", phone):
        raise HTTPException(400, "Invalid phone number")
    # ADB shell launches the normal Android SIM dial intent. Some OEMs may still show a confirmation UI.
    p = run_adb("shell", "am", "start", "-a", "android.intent.action.CALL", "-d", f"tel:{phone}", timeout=10)
    if p.returncode != 0:
        raise HTTPException(500, (p.stderr or p.stdout or "Dial command failed")[-400:])
    return {"ok": True, "phone": phone, "state": parse_call_state()}


@app.post("/hangup")
def hangup():
    d = ready_device()
    if not d:
        raise HTTPException(409, "Phone disconnected")
    # KEYCODE_ENDCALL works on many Android builds when sent by adb shell.
    p = run_adb("shell", "input", "keyevent", "KEYCODE_ENDCALL", timeout=5)
    if p.returncode != 0:
        raise HTTPException(500, "Android hangup command failed. End the call on the phone.")
    return {"ok": True, "state": parse_call_state()}


@app.post("/tts")
async def tts(body: TtsBody):
    text = re.sub(r"\s+", " ", body.text or "").strip()
    if not text:
        raise HTTPException(400, "Text required")
    if len(text) > 1400:
        text = text[:1400]
    if edge_tts is None:
        raise HTTPException(503, "Neural voice package missing. Run SETUP-USB-PHONE-BRIDGE.ps1")
    fd, path = tempfile.mkstemp(prefix="ps_sia_", suffix=".mp3")
    os.close(fd)
    try:
        communicator = edge_tts.Communicate(text, voice=body.voice, rate=body.rate, pitch=body.pitch)
        await asyncio.wait_for(communicator.save(path), timeout=12)
        return FileResponse(path, media_type="audio/mpeg", filename="ps-sia.mp3", background=BackgroundTask(lambda: os.path.exists(path) and os.unlink(path)))
    except Exception as exc:
        try:
            os.unlink(path)
        except Exception:
            pass
        raise HTTPException(502, f"Neural voice failed: {exc}") from exc


@app.get("/")
def root():
    return {"name": "PS ASSISTANT V1.5 USB Phone Bridge", "health": "/health"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8765, log_level="info")
