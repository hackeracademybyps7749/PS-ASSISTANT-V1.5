# PS ASSISTANT V1.5 - Personal Phone AI Mode (No Telephony Provider)

This mode is for using your existing normal mobile SIM/number without Twilio, Exotel, SIP or a GSM gateway.

## What it can do

1. In Admin -> Client Database, select one client or press **Phone AI**.
2. Click **Open Dialer** (on a phone, or on a computer that has a `tel:` handler such as Phone Link) or copy the number and dial from your normal phone.
3. Put the phone on **speaker** near the computer microphone/speakers.
4. Click **Start AI Session**.
5. Chrome/Edge speech recognition listens to the customer through the computer mic.
6. The recognized text is sent to PS ASSISTANT's configured AI provider.
7. PS ASSISTANT speaks the reply through the computer speakers, which the phone microphone picks up.
8. The customer/SIA text transcript is stored in D1.
9. Click **End & Analyze** to save duration/outcome and run post-call analysis.

## Important limitation

A normal third-party browser/app on stock Android or iPhone does **not** get unrestricted access to the cellular call's two-way audio stream. Therefore a completely unattended AI that directly injects/captures call audio on the same stock phone is not reliable without a supported telephony bridge/provider, privileged OEM integration, or dedicated hardware.

Personal Phone AI mode is intentionally an **acoustic speakerphone companion**. It avoids a separate telephony provider fee, but audio quality depends on room noise, echo, phone speaker volume, and microphone placement.

## Best setup

- Use a laptop/desktop and the normal phone as two separate devices.
- Keep phone on speaker 20-50 cm from the computer.
- Use a quiet room.
- Keep computer speaker at moderate volume to reduce echo.
- Use Chrome or Edge and allow microphone access.
- Use **Interrupt / Listen Now** if the customer speaks while SIA is talking.

## For fully automatic unattended dialing

Use the existing Phone Bridge interface in Developer Console with an authorized telephony transport (SIP/PBX, provider adapter, or compatible device). That is separate from Personal Phone AI mode.
