$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$adb = Join-Path $here "platform-tools\adb.exe"
if (Test-Path $adb) { $env:PS_ADB = $adb }
Write-Host "PS ASSISTANT V1.5 USB Phone Bridge" -ForegroundColor Cyan
Write-Host "Local bridge: http://127.0.0.1:8765" -ForegroundColor Green
Write-Host "Keep this window open while using USB calling / Neural Female Voice." -ForegroundColor Yellow
python (Join-Path $here "ps_usb_phone_bridge.py")
