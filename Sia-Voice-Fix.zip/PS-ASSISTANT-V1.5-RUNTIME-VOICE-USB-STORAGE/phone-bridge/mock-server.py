"""Mock authorized call bridge for local development only.
Replace this with your own SIP/telephony/Android-SIM bridge later.
It DOES NOT place real phone calls.
"""
from http.server import BaseHTTPRequestHandler, HTTPServer
import json, time

class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path != '/dial':
            self.send_response(404); self.end_headers(); return
        length = int(self.headers.get('content-length', '0'))
        data = json.loads(self.rfile.read(length) or b'{}')
        time.sleep(0.05)
        if data.get('type') == 'health_check':
            out = {"ok": True, "mode": "mock", "message": "Mock bridge is healthy"}
        else:
            out = {"ok": True, "mode": "mock", "phone": data.get("phone"), "message": "Mock bridge accepted dial request"}
        body = json.dumps(out).encode()
        self.send_response(200)
        self.send_header('content-type','application/json')
        self.send_header('content-length', str(len(body)))
        self.end_headers(); self.wfile.write(body)

if __name__ == '__main__':
    print('Mock call bridge listening on http://127.0.0.1:8099')
    HTTPServer(('127.0.0.1',8099), Handler).serve_forever()
