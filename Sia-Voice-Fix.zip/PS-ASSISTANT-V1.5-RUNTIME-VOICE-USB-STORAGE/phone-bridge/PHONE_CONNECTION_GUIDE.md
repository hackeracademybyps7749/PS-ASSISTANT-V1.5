# PS ASSISTANT V1.5 — Real Phone Connection Guide

PS ASSISTANT's Cloudflare Worker is the control/AI backend. It does **not** itself contain a mobile radio, so a real phone call needs one authorized telephony transport.

## Recommended production architecture

```text
Admin Excel / Scheduler
        ↓
Cloudflare Worker + D1
        ↓ HTTP dial request
Your Phone Bridge
        ↓
SIP/PBX or GSM-to-SIP gateway
        ↓
Customer's phone

Customer speech
        ↓
Bridge STT (local Whisper/faster-whisper can be used)
        ↓
POST /api/bridge/ai-turn
        ↓
Configured AI provider
        ↓
Bridge TTS (local TTS can be used)
        ↓
Customer hears PS ASSISTANT V1.5
```

The bridge must stop TTS playback as soon as customer speech is detected, then send the new utterance to `/api/bridge/ai-turn`. This provides interruption/barge-in behavior.

## Option A — Existing SIM with GSM/SIP hardware

Best fit when you want calls to use your own SIM plan rather than a per-minute cloud telephony API.

1. Put your authorized SIM in a GSM/LTE-to-SIP gateway that supports your carrier/voice network.
2. Connect the gateway to Asterisk/FreeSWITCH or your own bridge service.
3. The bridge exposes an HTTPS dial endpoint matching `PHONE_BRIDGE_CONTRACT.md`.
4. Set that endpoint and a strong bridge token in Developer Console → System Control.
5. Use **Test Bridge**.

Hardware/carrier compatibility matters, especially for VoLTE. This route can avoid a separate telephony API fee, but the SIM plan and hardware are still external costs.

## Option B — SIP / telephony provider

Use a SIP trunk or a provider adapter. This is the most reliable and easiest production route, but the provider normally charges for calls/minutes.

The PS ASSISTANT backend does not care which provider is behind the bridge; only the bridge adapter changes.

## Option C — Android phone bridge

A normal Android app cannot reliably capture **and inject** two-way audio into an ordinary cellular call on all phones because Android restricts call-audio routing/recording. It may work only with specific OEM capabilities, privileged/system access, supported accessibility/telecom APIs, or custom/rooted setups. Therefore Android is not the recommended production transport.

## Exposing an office/local bridge to Cloudflare

If the bridge runs on your office PC, a Cloudflare Tunnel can expose the bridge HTTPS endpoint without opening router ports.

Example local bridge:

```text
http://127.0.0.1:8099/dial
```

Expose the local HTTP service with Cloudflare Tunnel, then put the resulting HTTPS `/dial` URL into Developer Console. Protect the bridge with the bearer token; do not leave it unauthenticated.

## Bridge health check

Developer Console → **Test Bridge** sends this to the configured Bridge URL:

```json
{
  "type": "health_check",
  "source": "PS ASSISTANT V1.5",
  "timestamp": "..."
}
```

Your adapter should return HTTP 200 for that payload.

## Live callbacks to PS ASSISTANT

The bridge must call the deployed Worker with the same bridge token:

- `POST /api/bridge/event` — started / transcript / ended
- `POST /api/bridge/ai-turn` — customer utterance → assistant response

See `PHONE_BRIDGE_CONTRACT.md` for exact payloads.

## No audio recording

The supplied backend stores text transcript, call outcome, lead score and summary. It does not store call recordings. Configure the telephony transport not to record audio if you want the same behavior end-to-end.
