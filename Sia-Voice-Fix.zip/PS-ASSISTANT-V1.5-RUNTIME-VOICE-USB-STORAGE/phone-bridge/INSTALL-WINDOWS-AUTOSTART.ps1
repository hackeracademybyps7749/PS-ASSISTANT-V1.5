$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$startup = [Environment]::GetFolderPath('Startup')
$cmd = Join-Path $startup 'PS-ASSISTANT-USB-BRIDGE.cmd'
$startScript = Join-Path $here 'START-USB-PHONE-BRIDGE.ps1'
$line = '@echo off' + "`r`n" + 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $startScript + '"'
Set-Content -Path $cmd -Value $line -Encoding ASCII
Write-Host "Installed Windows auto-start:" -ForegroundColor Green
Write-Host $cmd -ForegroundColor Cyan
Write-Host "The bridge will start automatically next Windows login." -ForegroundColor Yellow
