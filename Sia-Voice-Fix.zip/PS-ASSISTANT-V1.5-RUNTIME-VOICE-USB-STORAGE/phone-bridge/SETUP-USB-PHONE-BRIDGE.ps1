$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host "PS ASSISTANT V1.5 - USB Phone Bridge Setup" -ForegroundColor Cyan

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
  throw "Python was not found. Install Python 3.11+ first."
}

Write-Host "[1/3] Installing local bridge + neural female voice packages..." -ForegroundColor Yellow
python -m pip install --upgrade fastapi uvicorn edge-tts pydantic
if ($LASTEXITCODE -ne 0) { throw "Python package installation failed" }

$adb = Join-Path $here "platform-tools\adb.exe"
if (-not (Test-Path $adb)) {
  Write-Host "[2/3] Downloading official Android Platform Tools (ADB)..." -ForegroundColor Yellow
  $zip = Join-Path $here "platform-tools.zip"
  Invoke-WebRequest -Uri "https://dl.google.com/android/repository/platform-tools-latest-windows.zip" -OutFile $zip
  Expand-Archive -Path $zip -DestinationPath $here -Force
  Remove-Item $zip -Force
} else {
  Write-Host "[2/3] ADB already present." -ForegroundColor Green
}

Write-Host "[3/3] Starting ADB and checking phone..." -ForegroundColor Yellow
& $adb start-server
& $adb devices
Write-Host ""
Write-Host "Phone par USB debugging ON karke 'Always allow from this computer' -> Allow dabao." -ForegroundColor Green
Write-Host "Setup complete. Ab START-USB-PHONE-BRIDGE.ps1 chalao." -ForegroundColor Cyan
