# General questions and official market lookup

Deploy this updated panel using LIVE_DEPLOY.ps1. Preserve your existing worker/.dev.vars, Cloudflare worker name and D1 database configuration. Do not reset the database. Existing saved training remains in that database.

Voice engine, key, rate and pitch are unchanged. GENZ TECH SOLUTION and Gen Z Tech Solutions pronunciation is normalized to जेन ज़ी टेक सॉल्यूशन when no custom pronunciation is set.

In Developer > System Control, enable automatic web search and configure a valid Brave Search API key in the existing web search key field. A text-model API key is not a search key. Without a full search key, encyclopedia references cover general explanations, but current market hours cannot be verified. Provider charges/quotas apply.

Customer and Admin can ask general questions. Basic trading definitions reply locally without a network lookup. Market timings trigger official exchange lookup, ask which exchange if unspecified, and preserve an exchange-only follow-up. Only allowlisted official exchange pages are retrieved; unverified third-party timing snippets are discarded. Failed/blocked pages or unavailable search return a clear unverified response, never a guessed time. Results appear in the existing sources list; source names can be mentioned in speech. Holidays, segments and timezone must be distinguished from regular hours. No arbitrary question or provider can be guaranteed accurate or instant.

Training still requires the training password. Customer conversation does not change Admin memory. Save confirmation should match Saved Knowledge. Web results are temporary reference data and are not automatically stored as company policy.

Deployment now installs development dependencies before invoking Wrangler, addressing the interrupted-install missing-CLI failure. Close applications locking node_modules if npm reports EBUSY.

The bundled Kaggle notebook includes cached binary execute-permission and shared-library repair in its model startup cell. If your current Kaggle session works, these web-answer features only require the panel update; replacing the running notebook is unnecessary.

Validation: mocked provider/search/exchange-page tests, persistent memory/security tests and voice cancellation/prefetch tests; frontend build and Worker dry run. No live customer phone, Kaggle GPU or production search key was tested.
