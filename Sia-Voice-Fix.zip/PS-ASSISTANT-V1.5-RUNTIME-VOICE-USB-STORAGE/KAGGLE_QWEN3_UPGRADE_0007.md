# 0007 Kaggle Qwen3 Fast API
- Adds owner-side `Kaggle Qwen3 4B` AI-provider preset.
- Adds ready-to-run Kaggle notebook using Qwen3 4B Q4_K_M + llama.cpp CUDA.
- Uses OpenAI-compatible `/v1/chat/completions`.
- Adds bearer API-key protection and a Cloudflare Quick Tunnel for HTTPS access from the deployed Worker.
- Keeps provider credentials out of the Admin Panel.
