# PS ASSISTANT V1.5 — Real Data / Functional Tabs Fix

This build removes dashboard sample/fallback business data and makes the Admin/Developer navigation functional.

## Important
- Admin data comes from Cloudflare D1.
- Empty database = honest empty states, not fake customers/calls.
- Actual phone dialing is disabled until `CALL_BRIDGE_URL` is configured.
- AWS Bedrock is used only for real assistant responses / call analysis.
- Developer Console uses recorded `ai_usage`, imports and system events; it no longer invents token/cost/call values.

## After replacing the project
Run from the `worker` folder:

```powershell
npx wrangler d1 migrations apply DB --remote
```

This applies `0002_real_data.sql` and adds import/event tracking.

Then build:

```powershell
cd ../app
npm run build
cd ../worker
npx wrangler dev
```

Open the Worker URL printed by Wrangler (normally http://127.0.0.1:8787).

## Real tabs now wired
- Dashboard
- Live Calls
- Call Scheduler
- Client Upload
- Client Database
- Call Queue
- Leads
- Follow-ups
- Training Center
- Knowledge Base
- Unanswered Questions
- Export Center
- SIA Settings

## Real phone calls
The UI/DB queue is functional, but phone dialing requires an authorized SIM/SIP/telephony bridge. Until that bridge is configured, clicking Dial explicitly reports that the phone bridge is not configured instead of pretending that a call happened.
