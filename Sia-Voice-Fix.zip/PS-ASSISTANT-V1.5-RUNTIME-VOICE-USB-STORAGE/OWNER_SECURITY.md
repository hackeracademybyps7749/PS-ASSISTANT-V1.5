# OWNER-ONLY SECURITY NOTES — PS ASSISTANT V1.5

## What admins can and cannot see

The Admin UI intentionally exposes business operations only: clients, calls, schedules, transcripts, lead scores, training, unanswered questions and exports.

It does **not** show provider names, model IDs, AWS region, API keys, token counts, per-request AI cost, developer logs, or the Developer Console route.

## Where sensitive logic lives

Sensitive logic stays in the Cloudflare Worker:

- AI provider credential
- provider/model configuration
- company prompt assembly
- technical usage/cost logging
- developer metrics
- call-bridge token

Never put these values in React/Vite environment variables prefixed with `VITE_`.

## Authentication

Sessions use an HttpOnly SameSite=Strict cookie. Browser JavaScript cannot read the session token. Admin and developer roles are independently verified by the Worker on every protected request.

Developer metrics require the developer role server-side. Knowing a URL is not authorization.

## Frontend visibility reality

No web frontend can be made literally impossible to inspect. A browser must receive HTML/CSS/JavaScript to render it. This release therefore uses the correct protection model:

1. keep secrets and proprietary decision logic server-side;
2. minify production frontend bundles;
3. disable source maps;
4. lazy-load the engineering console in a separate production chunk;
5. expose only generic business endpoints to the Admin UI;
6. never give the source ZIP to an admin/customer.

For an admin/client handoff, give only the deployed URL and their Admin access code. Keep this source ZIP owner-only.

## Do not misrepresent the system

The Admin UI does not need technical provider details, but do not make contractual/privacy claims saying no external AI service is used if an external service actually processes data. Keep any required customer/privacy disclosures accurate.
