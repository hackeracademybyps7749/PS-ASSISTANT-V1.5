# PS ASSISTANT V1.5 — Runtime / Voice / USB / Storage Upgrade 0008

## What changed

### Developer Storage Monitor
- Shows measured D1 database bytes when Cloudflare returns `meta.size_after`, with a safe fallback estimate.
- Shows per-database remaining capacity using the selected Cloudflare plan.
- Shows configured account maximum and an "if this is the only D1 DB" remaining estimate.
- Shows row counts and approximate payload by Clients, Calls, Transcripts, Knowledge, AI Usage, and Imports.
- Shows a live **Operational Load** score from real recent AI request count, AI latency, failures, active calls, queue depth, due clients, and pending learning. This is intentionally not presented as CPU %, because Cloudflare Workers do not expose a live CPU-percent meter to application code.

Default plan limits in this build:
- Workers Free D1: 500 MB per database; 5 GB total account storage.
- Workers Paid D1: 10 GB per database; 1 TB maximum account storage.
These are configurable in Developer → System Control in case the platform limits change.

### Natural female voice
- Default voice engine: local office-PC bridge using `edge-tts` neural speech.
- Default Hindi female voice: `hi-IN-SwaraNeural`.
- Short answers are synthesized as one audio segment for smoother speech; longer answers are sentence-aware chunks with prefetching.
- Browser Hindi/Indian female voice remains automatic fallback.
- This is a natural neural female voice; it is not a clone of ChatGPT, Gemini, or any real person.

### More accurate live speech recognition
- New Kaggle notebook: `kaggle/PS_ASSISTANT_QWEN3_VOICE_API_V3.ipynb`.
- Qwen3 4B runs the conversational brain on GPU 0.
- Faster-Whisper `large-v3-turbo` runs speech recognition (GPU 1 on T4x2 when available).
- Cloudflare Worker automatically derives `/v1/audio/transcriptions` from the active OpenAI-compatible Kaggle provider.
- Speech is auto-language detected and biased with company / assistant names.
- Saved speech corrections remain active; common `Genz Tech Solution` misrecognitions are preloaded.

### Live Admin Classroom
- Admin statements become persistent D1 lessons; they survive Kaggle restarts and Cloudflare deployments.
- Questions stay in answer mode unless Admin explicitly presses **Teach This**.
- Admin can edit the recognized text and press **Save Correction** to permanently correct future recognition.
- Customer-specific memory is refreshed after analyzed calls.
- Customer-derived global knowledge is placed in **Customer Learning Inbox** for Admin Approve/Reject; customer claims are never blindly promoted into company facts.

### Android USB normal-SIM calling
- Local bridge: `phone-bridge/ps_usb_phone_bridge.py`.
- ADB controls normal Android SIM dial/hangup and reads call state.
- Admin has **Connect USB Phone** and **Auto Dial + AI ON**.
- Cloud schedule is polled while the Admin page is open; due contacts are dialed one-by-one.
- When Android reports an ACTIVE call, the live AI loop starts automatically: customer speech → accurate STT → Qwen → neural female voice → call audio path.
- Call transcript is written to D1 and analyzed at the end.
- Busy/no-answer/failure is sent back to Cloudflare for retry scheduling.

## Important physical audio limitation
A normal USB data cable can control Android dialing/status, but stock Android does **not** expose unrestricted raw cellular-call audio to a web page over that data cable. For clean two-way AI call audio, use a compatible phone USB-C/headset ↔ PC wired audio interface and set it as the PC's default input/output. This avoids a telephony API/gateway, but the audio path still needs compatible hardware.

## First-time phone setup
1. Android Developer Options → USB debugging ON.
2. Plug the office Android phone into the PC with a data-capable USB cable.
3. Run `phone-bridge\SETUP-USB-PHONE-BRIDGE.ps1`.
4. Approve "Always allow from this computer" on Android.
5. Optional: run `phone-bridge\INSTALL-WINDOWS-AUTOSTART.ps1` so the local bridge starts automatically with Windows.
6. Open live Admin → Connect USB Phone → Auto Dial + AI ON.

## Kaggle V3
Upload `kaggle/PS_ASSISTANT_QWEN3_VOICE_API_V3.ipynb`, enable T4/T4x2 + Internet, Run All, then update Developer → AI Providers with the printed Base URL/API key. The existing V2 endpoint still works for chat, but V3 is required for the accurate Whisper endpoint.
