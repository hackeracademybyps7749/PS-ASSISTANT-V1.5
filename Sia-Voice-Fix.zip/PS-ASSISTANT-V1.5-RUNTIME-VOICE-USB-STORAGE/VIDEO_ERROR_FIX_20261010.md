# Video-observed repetition and call-script training

The supplied 3-second video frames show repeated words/phrases in the reply and the label Device voice fallback. The frames do not show a specific HTTP error code. The selected neural service was not used for that playback; installing this code alone cannot make a missing or unreachable speech service available.

## Apply

Copy your old `worker/.dev.vars` into a fresh extraction of this ZIP and preserve your existing Worker/D1 configuration. From the project root run:

```powershell
powershell -ExecutionPolicy Bypass -File .\LIVE_DEPLOY.ps1
```

Refresh the live app after deploy. The reusable Kaggle notebook is unchanged: no model re-download/recompile is needed for this update. Qwen repetition controls are sent from the Worker with its voice request.

## Admin teaching

Open Talk & Teach → Call greeting & ending. Fill Opening line after AI introduction and Closing line before ending the call, then Save call training. The next call uses these saved lines. The AI introduction still discloses that Sia is an AI assistant.

The Live Phone AI End & Analyze and USB Hangup actions play the saved closing line before the app ends or hangs up, once. If the customer already hangs up, there is no live line on which to play a farewell. Scripts cannot play over a SIM call without working audio routing.

Normal approved facts can still be taught with “याद रखो …” or Teach this. A bare numeric lesson such as 12299 is excluded from model context; it is not silently deleted. Teach a complete approved fact with a service name, currency and price.

## Voice checklist

On the PC used for speaking, run `phone-bridge/START-USB-PHONE-BRIDGE.ps1`, select Neural Female Voice / Local Bridge with `hi-IN-SwaraNeural`, and Save & test voice. Install bridge dependencies using its setup script first if necessary. Keep the bridge window open. The existing `ADVANCED_RUNTIME_SETUP_20261009.md` explains cloud speech for mobile and optional paid services.

Device voice fallback means local/cloud synthesis failed or was unavailable. The Classroom now displays an explanatory notice. Use the selected service's voice test before customer calls. A text-generation API alone does not provide natural speech synthesis. Voice settings requests are shared across simultaneous sentence preparation and reuse the last successful config after a temporary settings-fetch failure.

## Repetition protection

Repetitive model output is stopped and retried once with a short-answer instruction and without previous assistant output. Persistent repetition then uses a configured fallback or reports an error instead of treating the loop as a successful complete answer. Streaming reader resources are cancelled on failure. Qwen voice requests also include its supported repetition penalty. The retry is bounded by the existing request deadline; this does not guarantee instant or perfect model replies.

## Checks

Local fixtures passed for repetition detection and clean retry, saved greeting/closing lines, cancellation, voice preparation, pronunciation and settings-request sharing. Production app build and Worker dry-run passed. These fixtures do not test a real voice provider, device speaker/mic, the customer's live domain or SIM audio wiring.
