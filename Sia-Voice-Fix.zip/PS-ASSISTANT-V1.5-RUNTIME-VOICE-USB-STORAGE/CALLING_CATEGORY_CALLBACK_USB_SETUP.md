# PS V1.5: Category calling, callback consent and Android USB setup

## Update the deployed panel

1. Stop active calls before updating.
2. Extract this ZIP into a new folder. Copy your working `worker/.dev.vars` into the new folder. Keep the same worker name, D1 database ID and configuration in `worker/wrangler.toml`. Keep AUTH_SECRET and CONFIG_ENCRYPTION_KEY unchanged if already configured; never publish these files or API keys.
3. Open PowerShell in the project folder and run:

```powershell
powershell -ExecutionPolicy Bypass -File .\LIVE_DEPLOY.ps1
```

The script installs dependencies, applies migrations (including 0021), builds and deploys. Close apps locking node_modules if npm reports EBUSY. After successful deployment refresh the panel.

Current working Kaggle can stay running: these conversation changes are in the panel backend/frontend. The bundled notebook also has cached binary/shared-library repair if you need a fresh notebook later.

## Company and approved training

In Admin > Training Center unlock with the training password. Set company name `GENZ TECH SOLUTION`, the accurate introduction, address, working hours, services and approved starting prices. In Live Training / Teach Me, set company pronunciation to `जेन ज़ी टेक सॉल्यूशन`, then Save call training. Saved voice engine, pitch/rate and key are unchanged.

Say `याद रखो ...` or enable automatic Admin learning for clear company statements. Confirm the fact appears in Saved Knowledge / Saved lessons. Uploaded PDF text and approved sources remain visible in their source inspector. The same Cloudflare D1 retains saved knowledge when Kaggle stops. Customer conversation cannot change approved Admin company facts. Web results are references, not automatically approved company policies or model weight training.

Example opening after AI introduction (save it if this matches your company policy):

`{business_name} के व्यवसाय के लिए हमारी वेबसाइट development services के बारे में संपर्क कर रही हूँ। क्या अभी थोड़ी बात कर सकती हूँ?`

Example closing: `आपका समय देने के लिए धन्यवाद। आपका दिन शुभ हो।`

The agent introduces itself as the company's AI assistant and can include the saved company introduction. It uses the customer's business name and category from Excel. It asks one question at a time. Admin scripts remain editable; do not put multiple questions or long monologues in the opening.

## Customer Excel and conversation

Upload through Client Upload. Use these column headings:

`Business Name | Contact Number | Address | Category`

Category examples: Cafe, Restaurant, Clinic, Salon, School, Hotel, Retail Store, Real Estate. Unknown categories use a neutral business pitch; the model gets the exact uploaded category and address. The built-in Excel template is available in the panel. Queue only the clients you want to call.

When a customer says their website already exists, acknowledge it and ask whether they want improvements in design, speed or enquiries. Do not repeat a new-website pitch. General questions remain answerable. Unapproved company pricing is never inferred from a competitor's web page. When pricing/details are missing, offer a team callback and WAIT for permission.

Callback flow:

- Pending: ask whether the customer wants the team to call back. Merely asking about price does not authorize a callback.
- Yes / haan / ji: save accepted consent and ask for preferred day/time.
- No / ji nahi: save declined consent, speak the closing and finish.
- Preferred time: store the customer's words for team review and speak the closing. A bare `5` asks morning/evening. This is a request, not a guaranteed booked appointment. Automatic analysis does not invent a tomorrow callback from an interest score.

In Live Call Monitor select a call to see Customer conversation & searches: consent, preferred time, question and retrieved source links. Failed searches are shown without fabricated sources. Accepted requests appear in Follow-ups. The team must review the request and availability; exact automated appointment scheduling is not added.

## Web search

In Developer > System Control enable automatic web search and configure a valid Brave Search API key. Model API keys do not replace a search key. Market timings require official exchange pages; unverified/blocked pages or unavailable search return a clear verification failure. Other web questions receive source references, but no arbitrary answer can be guaranteed correct or instant. The existing speech API endpoint must remain connected and online.

## Android USB: first-time installation

Prerequisites: Windows PC with Python 3.11+ and Node/npm, Android with a SIM and working outgoing calls, data-capable USB cable. Android USB debugging controls dial/status/hangup. It does not by itself supply clean bidirectional SIM call audio to the browser.

On Android, open Settings > About phone > tap Build number seven times (location varies), then Developer options > USB debugging ON. Connect USB, unlock the phone and approve the RSA debugging prompt for this PC. Windows may need the phone manufacturer's ADB driver.

Run in project-root PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File .\phone-bridge\SETUP-USB-PHONE-BRIDGE.ps1
powershell -ExecutionPolicy Bypass -File .\phone-bridge\START-USB-PHONE-BRIDGE.ps1
```

Keep the bridge terminal open. Diagnose connection with:

```powershell
.\phone-bridge\platform-tools\adb.exe devices
```

The phone must show `device`, not `unauthorized` or `offline`. Approve the phone prompt or reconnect if needed. Bridge health is at `http://127.0.0.1:8765/health`. Open the Admin panel on this same PC; allow microphone and any browser prompt for access to the local bridge. Developer USB bridge URL uses `http://127.0.0.1:8765` unless you changed its port.

## SIM-call audio: required before real customer calls

Use a phone-compatible headset/call-audio interface providing separate bidirectional phone-to-PC audio, or a supported SIP/GSM gateway. A basic USB data cable or arbitrary headphone splitter is not a substitute. Confirm the interface supports microphone injection into a SIM call and receiving customer audio; some USB-C accessories occupy the only phone port or switch it out of USB data mode, so both connections must be compatible with your phone. Android restricts direct call-audio capture to privileged/system apps.

Set Windows input to the interface carrying CUSTOMER audio, and Windows output to the path feeding AI speech into the PHONE microphone. In the browser microphone settings choose the customer-audio input, not the laptop mic. Test with your own second phone first: customer speech must reach the Admin transcript and AI speech must reach the remote phone without feeding the AI output back into its own input. No specific hardware has been tested here. For a temporary acoustic test, phone speaker + PC mic/speaker may work but can produce echo; do not assume production voice quality.

## Daily operation

1. Start Kaggle until ready and connect its current endpoint/key (or start your existing API provider).
2. Connect Android USB and the tested call-audio interface.
3. Run START-USB-PHONE-BRIDGE.ps1; keep its window open.
4. Open the live Admin panel on this PC, Connect USB Phone, grant microphone permission.
5. Import/select clients and add them to the queue. Set campaign hours and turn scheduler on as required by your existing queue workflow.
6. Turn Auto Dial + AI ON. The scheduler and global USB runtime run while the Admin tab stays open. Some Android OEMs can still require on-phone dial confirmation.
7. The AI starts only when call state is confirmed ACTIVE. On a closing response it waits for speech playback before sending hangup. If speech or hangup fails, end the call on the phone. A customer who hangs up first cannot hear a subsequent closing.
8. Turn Auto Dial OFF to pause subsequent calls. Review Call Monitor, callback requests, unanswered questions and saved training.

Optional Windows-start bridge:

```powershell
powershell -ExecutionPolicy Bypass -File .\phone-bridge\INSTALL-WINDOWS-AUTOSTART.ps1
```

This starts only the local bridge; it does not automatically start Kaggle, open the Admin browser or override Android permissions.

## Validation and limits

Automated checks cover saved memory/security, category pitch, existing-site recognition, callback consent and preferred-time storage, search history, cancelled reply suppression, closing only after queued audio, and voice pronunciation. Frontend build, Worker dry-run and Python syntax checks pass. No live production deployment, Kaggle GPU, Android OEM, real SIM call, microphone or physical audio interface was tested here. Voice quality and speed depend on the configured speech/model provider, network and tested audio path.

Official Android references:
https://developer.android.com/tools/adb
https://developer.android.com/reference/android/media/MediaRecorder.AudioSource
