# PS ASSISTANT V1.5 — Talk, Teach, Voice and Deletion Security

## Update your existing live app

1. Extract this ZIP into a fresh folder.
2. Copy your existing `worker/.dev.vars` into the new `worker` folder. Keep the same `AUTH_SECRET` and `CONFIG_ENCRYPTION_KEY` if used; they decrypt your saved private API keys.
3. Keep your existing D1 database binding and Worker name in `worker/wrangler.jsonc`. Do not create a replacement database. Your existing domain should continue pointing at this same Worker.
4. From the extracted project folder, run:

```powershell
powershell -ExecutionPolicy Bypass -File .\LIVE_DEPLOY.ps1
```

The script installs dependencies, applies migration `0017_deletion_security.sql`, builds and deploys. Refresh the live Admin page after completion.

## Create the deletion password

Sign in to the existing owner Developer Console → System Control → Deletion security. Enter a private password with at least eight characters, or Generate PS password, then Save deletion password. Keep a copy privately before saving. Do not paste this password into chat.

Every data delete now needs this password: clients, imports, call transcripts, saved lessons, PDF sources, providers, queue clearing and operational reset. Authorization expires after two minutes, is bound to the exact route and panel role, and can be used only once. Five wrong passwords temporarily block deletion authorization for ten minutes. Until the owner creates the password, deletion is blocked. Changing it revokes outstanding delete authorizations.

## Voice on desktop — existing local option

1. Run `phone-bridge/SETUP-USB-PHONE-BRIDGE.ps1` once.
2. Run `phone-bridge/START-USB-PHONE-BRIDGE.ps1` and keep the window open.
3. System Control: Voice engine → Neural Female Voice · Local Bridge.
4. Endpoint `http://127.0.0.1:8765/tts`, voice `hi-IN-SwaraNeural`, rate `+10%`, pitch `+4Hz` are the starter settings. Save and test voice.

The bridge uses edge-tts; it needs a working internet connection to its upstream speech service. It is not a clone of a ChatGPT voice and there is no uptime guarantee for that upstream service. Avoid excessive pitch and speed changes, which make speech less natural.

## Voice on Android and other phones — optional cloud option

A phone's `127.0.0.1` refers to the phone, not your office PC. Mobile therefore needs a reachable speech service for consistent neural playback. Browser voice fallback depends on installed device voices and may sound different.

System Control → Voice engine → Cloud neural voice · OpenAI compatible:

| Field | Example for the official OpenAI speech API |
|---|---|
| Speech API endpoint | `https://api.openai.com/v1/audio/speech` |
| Speech API key | Your own supported speech API key |
| Speech model | `gpt-4o-mini-tts` |
| Cloud voice | `coral` (you can test supported alternatives) |
| Voice expression | Warm, clear feminine voice; natural Hindi, expressive but calm |

Click Save & test voice. A text-only gateway key is insufficient unless that gateway also supports the audio speech endpoint. Your ChatGPT subscription does not configure this app's speech API. The selected service's billing and quotas apply.

ElevenLabs option: use your own key, `eleven_flash_v2_5` speech model and the complete `https://api.elevenlabs.io/v1/text-to-speech/YOUR_VOICE_ID` endpoint. Replace `VOICE_ID` with a voice you have access to. Select and preview a suitable feminine Hindi-capable voice in that service. The cloud key stays encrypted in D1 and is never sent to the browser. Speech text is sent to your selected speech provider.

Cloud expression controls depend on the model. Local/device voices cannot reproduce every emotional cue, and no voice quality comparison with ChatGPT Sol is guaranteed.

## Talk and Teach

- Normal conversation answers your latest question. Company call scripts do not override classroom small talk.
- Type your message, press Enter or Send. Shift+Enter inserts a line break. Input nodes stay stable while state updates, so focus should no longer be lost after one character.
- Start conversation turns on live listening. Speak during a reply to stop the current audio and cancel its pending answer. Speaker-echo suppression helps prevent the AI from replying to its own audio. Use a headset or a clean echo-cancelled audio path for reliable interruption; microphone behavior varies by browser and device. Stop & listen is available if recognition misses an interruption.
- Fast speech mode uses the browser transcript directly. Accurate mode optionally checks a captured segment through the server speech endpoint; a slow or unavailable check falls back to the browser transcript.
- Say `Yaad rakho hamari company ka naam ... hai` or click Teach this to save an approved fact. A confirmation states what was saved. Standalone numbers and questions without answers need more context before they can become saved facts.
- PDF and website sources remain in the Training Center. Their readable text is retrieved when relevant. Scanned PDFs need OCR first.
- Customer conversations produce persistent per-client memory and learning-inbox notes after analysis. Admin approval is required to turn customer notes into shared company knowledge. This is persistent knowledge retrieval and conversation memory, not automatic neural-weight retraining.
- Old incomplete lessons shown in your screenshot can be removed from Saved lessons after creating the deletion password. Teach a complete replacement such as `Software development ki starting price 12299 rupaye hai` if that is the approved company price.

## Automatic web search

System Control → Brave web search API key: enter your own key. Set Automatic web search to On, then Save All System Controls. Fresh questions (today/latest/news/weather/current scores) trigger lookup, as do general factual classroom questions with no relevant saved reference. Explicit `web par ...` searches are also supported.

Search results are reference snippets, not guaranteed verified company terms. Classroom replies show source links. They are not automatically saved as company facts. If search is unavailable, the assistant must not claim a successful live lookup. Search-service quotas apply separately from your text-model provider. Kaggle handles inference and optional speech recognition, not this search API.

## Android USB calling

Enable Android Developer options → USB debugging. Connect the phone to the office PC, unlock it and accept its USB debugging prompt. Run the local bridge, then click Connect USB. Successful connection sends one notification; offline health checks remain quiet.

USB data controls dial/hangup/status. Stock Android does not normally expose raw cellular call audio through the USB data cable. Use a compatible phone↔PC wired audio interface for a customer SIM call to hear the assistant and for the PC microphone input to receive customer speech. Browser phone-AI mode can be tested with a headset independently of SIM audio.

Historical Android call records no longer override current idle state. If an old AI session remains marked active, Admin → Live Calls → End session clears that session; hang up the physical phone too if needed. Active/dialing clients stay protected from deletion until the call ends.

## Validation and limits

Production frontend build and Worker dry run passed. Local Miniflare/D1 tests verify authentication, password protection, single-use grants, bulk deletion with active-call protection, memory save/delete, classroom small talk, settings secrecy and the cloud speech proxy with a mocked upstream. Voice tests verify echo suppression, interrupt cancellation and rejection of stale replies. Python bridge syntax and Android call-state parsing checks passed.

Your live provider credentials, Android hardware/audio wiring and real voice-service latency must still be checked in your own deployment. Browser visual QA could not connect to the local test server in this environment. No claim is made that all devices or third-party services are error-free or instantly responsive. Kaggle retains its existing session and persistence limits; this update does not make it always-on.
