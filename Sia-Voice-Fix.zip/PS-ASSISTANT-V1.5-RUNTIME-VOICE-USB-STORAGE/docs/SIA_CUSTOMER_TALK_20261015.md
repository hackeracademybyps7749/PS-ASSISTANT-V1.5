# Sia customer talk and voice update

After deploying this ZIP to the same Cloudflare Worker and D1 database, open **Admin → Settings → Sia call opening**. The editor controls the short opening, private service guidance, company pronunciation, and ending. The opening says Sia's name and the company name once; the profile Introduction and attached script are reference knowledge and are no longer read as the greeting. Use **Customer Talk** to test before a real call. It is a practice conversation and does not dial a number.

The new migration adds the user-provided GENZ TECH SOLUTION website, Lucknow office address, hours, contact information, and service categories to company knowledge where fields were empty. It preserves Admin-edited facts. The website itself returned HTTP 403 from this workspace; the migration uses the user's supplied details and does not claim to have scraped the site.

Neural Hindi speech uses normal rate/pitch for the earlier Swara preset. The browser now suspends recognition while Sia speaks to prevent Sia's own voice becoming a customer turn. Use **Stop & listen** to interrupt. Cloud speech uses fewer, longer audio segments and retains more quiet audio at clip edges, reducing chopped syllables. Voice quality still depends on the selected speech provider and the connection. If the screen says **Device voice fallback**, check Developer voice settings, the Kaggle session and the saved voice endpoint; that fallback is not the neural voice.

For existing deployed data, keep the existing D1 database ID and encryption key. `LIVE_DEPLOY.ps1` applies migration `0022_sia_company_call_defaults.sql`, builds the app, then deploys to the configured Worker. Cloudflare account login and production secrets are required on the deploying computer. Real cellular calls also need a working phone/audio bridge; Kaggle and Cloudflare alone do not supply cellular audio.

## Faster answers, listening and learning

The Worker now loads independent company data in parallel and sends only the most relevant saved services, FAQs, rules and lessons with a spoken turn. Current facts still need a working web lookup; no model can guarantee every answer. Sia answers the newest question first, asks one question at a time, adapts to busy or dissatisfied customers, and avoids restarting the sales greeting.

On a mobile browser without built-in speech recognition, Sia automatically records speech and tries the configured server transcription endpoint. Keep Kaggle Whisper enabled for this path. Its recognition vocabulary now names Sia and GENZ TECH SOLUTION instead of the developer. During spoken playback the mic is paused to prevent echo loops; use Stop & listen to interrupt.

Teach Me can automatically save clear company statements beginning with natural phrases such as “हम…” when Auto learn is selected. Real calls keep client-specific conversation notes in D1, avoid repeated notes, and create suggestions for Admin review. Customer Talk practice does not change company knowledge. Model weights are not retrained during a call.

The Kaggle speech endpoint retains the natural Hindi female Swara voice for Hindi and uses female Indian-English Neerja for predominantly English replies. The voice is still synthesized; quality depends on Edge speech availability and the customer's network. An external premium voice provider can be selected in Developer settings if a supported API key is available.
