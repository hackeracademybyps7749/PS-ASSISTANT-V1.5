# Sia voice recognition fix and setup

The web app first uses the browser's speech recognizer. When that API is missing (common in mobile Safari and some embedded browsers), **Accurate** mode now records speech locally, detects pauses, and sends each utterance to the configured speech transcription provider. The microphone closes while Sia replies, then reopens for the next turn. Interim recognizer updates are treated as revisions, which prevents repeated words from being appended to the final transcript. iOS `audio/mp4` recordings are supported as well as WebM and Ogg.

## Enable it

1. Start a Kaggle session from `kaggle/PS_ASSISTANT_KAGGLE_ADVANCED_20261015.ipynb` with GPU T4 x2 and Internet enabled. Keep the session running while using Sia. Wait for the health check and final HTTPS tunnel check to pass.
2. In Developer → AI Providers, save and enable the printed OpenAI-compatible endpoint, model ID and key. The provider must expose `/v1/audio/transcriptions`; this notebook does when Whisper is enabled. Keep the endpoint on `/v1`.
3. In Developer → System Control, choose **Accurate · server transcription + browser fallback**, then save. This mode is slower because it waits for transcription. Fast mode remains lower latency on browsers with working speech recognition.
4. Open the assistant on the phone over HTTPS, grant microphone access, and press Start conversation. Use a headset or quiet room. In Accurate mode, Sia listens for a short pause before sending the utterance.
5. For outgoing phone calls, connect the supported phone bridge and compatible phone-to-computer call audio. USB debugging permits dial/status control; it does not carry cellular call audio by itself.

If the provider rejects transcription or the Kaggle session is stopped, the status/reply shows the error; retry after restoring the provider or session. In Fast mode, unsupported browsers show a message directing the operator to Accurate mode. Server transcription depends on the selected provider, network, microphone permission, browser codec support and (for Kaggle) available GPU/session time.

## Sia's customer script

The original customer-supplied script is preserved in [`SIA_CALLING_AGENT_SCRIPT.txt`](SIA_CALLING_AGENT_SCRIPT.txt). It is reference text; attaching it does not automatically change a live database. In Admin → Talk & Teach, configure the greeting, farewell and service guide, and in Admin → Company Profile set the company facts, services, hours and contact details. Use only approved prices and facts. The service guide field has a 4,000-character limit, so keep the full script in this file and enter a concise operating guide. Saved lessons/documents persist in the Worker database; model weights are not automatically trained.

## Mobile debugging

- Use HTTPS; browsers normally block microphone access from plain HTTP pages.
- Confirm the browser's microphone permission and select the intended input device.
- In Accurate mode confirm the transcription provider is enabled, the Kaggle health response says `speech_ready: true`, and the HTTPS transcription route is reachable through the Worker.
- If Sia hears itself, use headphones and confirm the microphone closes during playback. If a transcript is empty, move closer to the mic, reduce background noise, then retry.
- The USB Phone Bridge is installed on the Windows computer connected to the phone. Keep the Admin browser tab and bridge open. USB debugging does not enable automatic calling without the configured bridge, queued client records, consent/compliant calling practices, and working audio routing.

The app was built and exercised with simulated browser recognition and provider fixtures here. A real phone, live Kaggle GPU, provider credentials, cellular audio route and remote deployment were unavailable for end-to-end validation.
