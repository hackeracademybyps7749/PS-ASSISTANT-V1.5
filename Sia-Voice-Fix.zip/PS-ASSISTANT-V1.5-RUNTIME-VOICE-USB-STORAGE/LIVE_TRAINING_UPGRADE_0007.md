# PS ASSISTANT V1.5 — Live Training Upgrade 0007

- Live Admin Classroom replaces the old voice-test-only flow.
- Explicit Admin teaching is permanently stored in Cloudflare D1 and injected into future AI conversations.
- Speech correction memory lets Admin fix misheard brand names once and reuse the correction later.
- Added seeded correction for “jaldi tech solution” / “gen z tech solution” → “Genz Tech Solution”.
- Better browser Hindi female voice selection with slower, warmer delivery.
- Customer calls create learning suggestions after analysis. These are NOT treated as company facts until Admin approves them in the classroom.
- Existing Knowledge Base and Unanswered Questions learning remain supported.
