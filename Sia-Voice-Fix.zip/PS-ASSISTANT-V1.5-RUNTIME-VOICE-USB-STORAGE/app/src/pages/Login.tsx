import { useState } from 'react';
import ThreeBackground from '../components/ThreeBackground';
import { api, authStore } from '../lib/api';

export default function Login(){
  const[code,setCode]=useState('');
  const[err,setErr]=useState('');
  const[busy,setBusy]=useState(false);
  async function go(){
    setErr(''); setBusy(true);
    try{
      const r=await api<any>('/api/auth/login',{method:'POST',body:JSON.stringify({panel:'admin',code})});
      authStore.setRole(r.role);
      location.href='/admin';
    }catch(e:any){setErr(e.message)}finally{setBusy(false)}
  }
  return <div className="login-page"><ThreeBackground/><div className="login-card">
    <div className="logo-big">〽</div><h1>PS ASSISTANT V1.5</h1><p>AI Voice Calling Platform</p>
    <input value={code} onChange={e=>setCode(e.target.value)} onKeyDown={e=>e.key==='Enter'&&go()} placeholder="Admin access code" type="password" autoComplete="current-password"/>
    <button className="primary" onClick={go} disabled={busy}>{busy?'Checking…':'Enter Admin Panel'}</button>
    {err&&<div className="error">{err}</div>}
  </div></div>
}
