import {secureFetch} from './api';
export async function streamVoiceTurn(path:string,body:any,signal:AbortSignal,onDelta:(chunk:string)=>void,onReset:()=>void,onProgress?:(text:string)=>void){
 const turnId=crypto.randomUUID();body={...body,turn_id:turnId};
 const cancel=()=>{if(body.call_id)void secureFetch(`/api/calls/${body.call_id}/voice-cancel`,{method:'POST',body:JSON.stringify({turn_id:turnId}),signal:AbortSignal.timeout(2500)}).catch(()=>{});};
 signal.addEventListener('abort',cancel,{once:true});if(signal.aborted){cancel();signal.removeEventListener('abort',cancel);throw new DOMException('Cancelled','AbortError');}
 try{const response=await secureFetch(path,{method:'POST',body:JSON.stringify(body),signal});
 if(!response.ok){const d=await response.json().catch(()=>({}));throw new Error(d.error||`Assistant HTTP ${response.status}`)}
 if(!response.headers.get('content-type')?.includes('text/event-stream'))return response.json();
 if(!response.body)throw new Error('AI response body is unavailable');
 const reader=response.body.getReader(),decoder=new TextDecoder();let buffer='',result:any=null,error='';
 const block=(text:string)=>{if(signal.aborted)return;let event='',data='';for(const line of text.split(/\r?\n/)){if(line.startsWith('event:'))event=line.slice(6).trim();if(line.startsWith('data:'))data+=line.slice(5).trim();}if(!data)return;let d:any;try{d=JSON.parse(data)}catch{return;}if(event==='delta')onDelta(String(d.text||''));else if(event==='progress')onProgress?.(String(d.text||''));else if(event==='reset')onReset();else if(event==='done')result=d;else if(event==='error')error=String(d.message||'AI request failed');};
 try{while(true){const r=await reader.read();if(r.done)break;buffer+=decoder.decode(r.value,{stream:true});const parts=buffer.split(/\r?\n\r?\n/);buffer=parts.pop()||'';parts.forEach(block);}buffer+=decoder.decode();if(buffer.trim())block(buffer);}finally{if(signal.aborted)await reader.cancel().catch(()=>{});reader.releaseLock();}
 if(error)throw new Error(error);if(!result)throw new Error('AI reply stopped before completion. Please try again.');return result;}finally{signal.removeEventListener('abort',cancel);}
}
export function normalizedVoice(text:string){return text.toLocaleLowerCase().replace(/[^\p{L}\p{M}\p{N}\s]/gu,' ').replace(/\s+/g,' ').trim();}
// Some recognizers revise a cumulative transcript instead of sending a new fragment.
export function mergeRecognizedSpeech(base:string,next:string){const a=base.trim().replace(/\s+/g,' '),b=next.trim().replace(/\s+/g,' ');if(!a)return b;if(!b)return a;const na=normalizedVoice(a),nb=normalizedVoice(b);if(na===nb||na.endsWith(' '+nb))return a;if(nb.startsWith(na+' '))return b;const x=a.split(' '),y=b.split(' ');for(let n=Math.min(x.length,y.length);n>0;n--)if(normalizedVoice(x.slice(-n).join(' '))===normalizedVoice(y.slice(0,n).join(' ')))return [...x,...y.slice(n)].join(' ');return a+' '+b;}
export function likelyVoiceEcho(heard:string,spoken:string){const a=normalizedVoice(heard),b=normalizedVoice(spoken);if(!a||!b)return false;if(/^(हाँ|हां|जी|नहीं|yes|no|okay|ok)$/.test(a))return false;if(a.length<3)return false;if(b.includes(a))return true;const words=a.split(' ').filter(Boolean),known=new Set(b.split(' '));return words.length>=2&&words.filter(w=>known.has(w)).length/words.length>=.8;}
