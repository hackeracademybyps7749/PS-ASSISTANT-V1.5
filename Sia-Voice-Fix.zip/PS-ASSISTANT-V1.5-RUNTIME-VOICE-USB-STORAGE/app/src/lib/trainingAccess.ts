let pending:Promise<void>|null=null;
export const trainingDialogPending=()=>pending!==null;
export function unlockTraining():Promise<void>{
 if(pending)return pending;
 pending=new Promise<void>((resolve,reject)=>{
  window.dispatchEvent(new Event('ps-training-password-open'));
  const backdrop=document.createElement('div');backdrop.className='modal-back';
  const form=document.createElement('form');form.className='voice-modal';
  const title=document.createElement('h2');title.textContent='Training Centre · Unlock';
  const detail=document.createElement('p');detail.textContent='Training dene ke liye alag training password enter karein. Session ek ghante tak unlock rahega.';
  const input=document.createElement('input');input.type='password';input.autocomplete='current-password';input.placeholder='Training password';input.required=true;input.maxLength=128;input.setAttribute('aria-label','Training password');
  const status=document.createElement('p');status.setAttribute('role','status');
  const actions=document.createElement('div');actions.className='voice-actions';
  const submit=document.createElement('button');submit.type='submit';submit.className='primary';submit.textContent='Unlock';
  const cancel=document.createElement('button');cancel.type='button';cancel.textContent='Cancel';
  const cleanup=()=>{document.removeEventListener('keydown',escape);backdrop.remove();previous?.focus();};
  const previous=document.activeElement as HTMLElement|null;const escape=(e:KeyboardEvent)=>{if(e.key==='Escape'){cleanup();reject(new Error('Training unlock cancelled'));}};
  cancel.onclick=()=>{cleanup();reject(new Error('Training unlock cancelled'));};
  form.onsubmit=async e=>{e.preventDefault();submit.disabled=true;status.textContent='Checking…';try{const response=await fetch('/api/training/access/unlock',{method:'POST',credentials:'include',headers:{'content-type':'application/json','x-psa-role':'admin'},body:JSON.stringify({password:input.value})});input.value='';const result=await response.json();if(!response.ok)throw new Error(result.error||'Unlock failed');cleanup();resolve();}catch(e:any){status.textContent=e.message;}finally{submit.disabled=false;}};
  actions.append(submit,cancel);form.append(title,detail,input,status,actions);backdrop.append(form);document.body.append(backdrop);document.addEventListener('keydown',escape);input.focus();
 }).finally(()=>{pending=null;});return pending;
}
export async function ensureTrainingAccess(){const response=await fetch('/api/training/access',{credentials:'include',headers:{'x-psa-role':'admin'},cache:'no-store'}),status=await response.json();if(!response.ok)throw new Error(status.error||'Training access unavailable');if(!status.configured)throw new Error('Training password is not configured yet. Contact the owner.');if(!status.unlocked)await unlockTraining();}
