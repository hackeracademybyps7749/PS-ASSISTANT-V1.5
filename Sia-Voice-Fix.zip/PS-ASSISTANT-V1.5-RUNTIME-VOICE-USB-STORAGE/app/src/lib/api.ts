import {unlockTraining} from './trainingAccess';
import {deletionToken,destructiveRequest} from './deletion';
export type Role = 'admin'|'developer';
const ROLE_KEY='psa_v15_role';

export const authStore={
  role:()=>sessionStorage.getItem(ROLE_KEY) as Role|null,
  setRole:(r:Role)=>sessionStorage.setItem(ROLE_KEY,r),
  clear:()=>sessionStorage.removeItem(ROLE_KEY)
};

export async function secureFetch(path:string,init:RequestInit={}):Promise<Response>{
  const h=new Headers(init.headers||{});const method=(init.method||'GET').toUpperCase();const url=new URL(path,location.href);const role=url.pathname==='/api/auth/me'?url.searchParams.get('role'):authStore.role();if(role==='admin'||role==='developer')h.set('x-psa-role',role);
  if(init.body&&!(init.body instanceof FormData)&&!h.has('content-type'))h.set('content-type','application/json');
  if(destructiveRequest(url.pathname,method)&&!h.has('x-delete-token'))h.set('x-delete-token',await deletionToken(url.pathname,method));
  const send=()=>fetch(path,{...init,headers:h,credentials:'include',cache:'no-store'});
  let r:Response;try{r=await send()}catch(e:any){if(e?.name==='AbortError'||e?.name==='TimeoutError')throw e;throw new Error('Server se connection nahi hua. Internet aur live app connection check karein.');}
  if(r.status===403){const d=await r.clone().json().catch(()=>({}));if(d.training_password_required){await unlockTraining();r=await send();}}
  if(r.status===403&&!h.has('x-delete-token')){const d=await r.clone().json().catch(()=>({}));if(d.delete_password_required){h.set('x-delete-token',await deletionToken(url.pathname,method));r=await send();}}
  return r;
}
export async function api<T=any>(path:string,init:RequestInit={}):Promise<T>{
  const r=await secureFetch(path,init);const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||`HTTP ${r.status}`);return d;
}

export function applyUiConfig(c:any){
  if(!c)return;const root=document.documentElement;
  const map:Record<string,string>={theme_cyan:'--cyan',theme_green:'--green',theme_amber:'--amber',theme_pink:'--pink',theme_violet:'--violet'};
  for(const [k,v] of Object.entries(map)){
    if(c[k]) root.style.setProperty(v,String(c[k]));
  }
  root.dataset.motion=String(c.ui_motion||'reduced');
  root.dataset.sound=String(c.ui_sound_enabled??'1');
  root.dataset.soundVolume=String(c.ui_sound_volume??'0.055');
}

export async function logout(role?:Role){
  const r=role||authStore.role()||'admin';
  try{await api(`/api/auth/logout?role=${r}`,{method:'POST'});}catch{}
  authStore.clear();
  location.href=r==='developer'?'/developer':'/';
}

let interactionFxInstalled=false;
let fxContext:AudioContext|null=null;
type UiCue='click'|'call_start'|'call_end'|'call_failed';
export function playUiCue(cue:UiCue){
  if(document.documentElement.dataset.sound==='0')return;
  try{
    fxContext??=new (window.AudioContext||(window as any).webkitAudioContext)();
    const ctx=fxContext;void ctx.resume();
    const volume=Math.max(0,Math.min(.16,Number(document.documentElement.dataset.soundVolume||.055)));
    const notes:Record<UiCue,number[]>={click:[440],call_start:[523,659],call_end:[659,523],call_failed:[330,262]};
    const gap=cue==='click'?.0:.12;
    notes[cue].forEach((frequency,index)=>{
      const start=ctx.currentTime+index*gap;
      const osc=ctx.createOscillator(),gain=ctx.createGain();
      osc.type='sine';osc.frequency.setValueAtTime(frequency,start);
      gain.gain.setValueAtTime(.0001,start);gain.gain.exponentialRampToValueAtTime(volume,start+.012);
      gain.gain.exponentialRampToValueAtTime(.0001,start+(cue==='click'?.055:.16));
      osc.connect(gain);gain.connect(ctx.destination);osc.start(start);osc.stop(start+(cue==='click'?.06:.17));
    });
  }catch{}
}
export function installInteractionFx(){
  if(interactionFxInstalled)return; interactionFxInstalled=true;
  document.addEventListener('pointerdown',(ev)=>{
    const el=(ev.target as HTMLElement|null)?.closest('button,.nav,label.drop,[role="button"]') as HTMLElement|null;
    if(!el||el.matches(':disabled,[aria-disabled="true"]'))return;
    el.classList.remove('press-pop'); void el.offsetWidth; el.classList.add('press-pop');
    playUiCue('click');
  },{capture:true});
  document.addEventListener('keydown',(ev)=>{
    if(ev.key!=='Enter'&&ev.key!==' ')return;
    const el=(ev.target as HTMLElement|null)?.closest('button,.nav,label.drop,[role="button"]') as HTMLElement|null;
    if(!el||el.matches(':disabled,[aria-disabled="true"]'))return;
    playUiCue('click');
  },{capture:true});
}
