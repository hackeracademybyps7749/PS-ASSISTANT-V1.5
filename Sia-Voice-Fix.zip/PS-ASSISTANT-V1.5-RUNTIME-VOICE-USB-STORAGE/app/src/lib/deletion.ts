export type DeletionRequest={path:string;method:string;resolve:(token:string)=>void;reject:(error:Error)=>void};
let pendingDialogs=0;
export function deletionDialogPending(){return pendingDialogs>0;}
export function deletionToken(path:string,method:string){pendingDialogs++;return new Promise<string>((resolve,reject)=>{window.dispatchEvent(new CustomEvent<DeletionRequest>('ps-request-delete-password',{detail:{path,method,resolve,reject}}));}).finally(()=>{pendingDialogs--;});}
export function destructiveRequest(path:string,method:string){return method==='DELETE'||method==='POST'&&(/\/(?:bulk-delete|queue-clear)$/.test(path)||(/^\/api\/dev\/reset-/.test(path)||path==='/api/training/reset'||path==='/api/dev/training-recover'));}
