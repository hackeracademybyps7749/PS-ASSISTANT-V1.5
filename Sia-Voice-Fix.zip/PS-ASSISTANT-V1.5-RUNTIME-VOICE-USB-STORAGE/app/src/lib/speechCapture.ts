type Capture={stop:()=>Promise<Blob|null>};
function recorderMime(){return ['audio/webm;codecs=opus','audio/webm','audio/mp4','audio/ogg;codecs=opus'].find(type=>MediaRecorder.isTypeSupported(type))||'';}

export async function startVoiceActivityCapture(onSpeech:(blob:Blob)=>void):Promise<Capture|null>{
  if(!navigator.mediaDevices?.getUserMedia||typeof MediaRecorder==='undefined')return null;
  let stream:MediaStream|undefined,context:AudioContext|undefined,raf=0,recorder:MediaRecorder|undefined;
  let chunks:BlobPart[]=[],lastVoice=0,speechStart=0,closed=false;
  try{
    stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
    context=new AudioContext();const analyser=context.createAnalyser();analyser.fftSize=512;context.createMediaStreamSource(stream).connect(analyser);
    const samples=new Float32Array(analyser.fftSize);
    const mime=recorderMime();
    const finish=()=>{if(!recorder||recorder.state==='inactive')return;const current=recorder;recorder=undefined;current.onstop=()=>{const blob=new Blob(chunks,{type:current.mimeType||mime});chunks=[];if(!closed&&blob.size>1200)onSpeech(blob);};try{current.stop()}catch{}};
    const begin=()=>{chunks=[];recorder=new MediaRecorder(stream!,mime?{mimeType:mime}:undefined);recorder.ondataavailable=e=>{if(e.data?.size)chunks.push(e.data)};recorder.start(200);speechStart=performance.now();};
    const tick=()=>{if(closed)return;analyser.getFloatTimeDomainData(samples);let energy=0;for(const sample of samples)energy+=sample*sample;const rms=Math.sqrt(energy/samples.length),now=performance.now();
      if(rms>0.018){lastVoice=now;if(!recorder)begin();}
      if(recorder&&(now-lastVoice>850||now-speechStart>12000))finish();
      raf=requestAnimationFrame(tick);
    };
    raf=requestAnimationFrame(tick);
    return {stop:async()=>{closed=true;cancelAnimationFrame(raf);if(recorder){const current=recorder;recorder=undefined;current.onstop=null;try{current.stop()}catch{}}stream?.getTracks().forEach(t=>t.stop());await context?.close().catch(()=>{});return null}};
  }catch{closed=true;cancelAnimationFrame(raf);stream?.getTracks().forEach(t=>t.stop());await context?.close().catch(()=>{});return null;}
}

export async function startMicCapture():Promise<Capture|null>{
  if(!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder==='undefined')return null;
  try{
    const stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
    const chunks:BlobPart[]=[];
    const type=recorderMime();
    const rec=new MediaRecorder(stream,type?{mimeType:type}:undefined);
    rec.ondataavailable=e=>{if(e.data?.size)chunks.push(e.data)};
    rec.start(180);
    return {stop:()=>new Promise(resolve=>{
      const finish=()=>{stream.getTracks().forEach(t=>t.stop());resolve(chunks.length?new Blob(chunks,{type:rec.mimeType||'audio/webm'}):null)};
      if(rec.state==='inactive')return finish();
      rec.onstop=finish;try{rec.stop()}catch{finish()}
    })};
  }catch{return null}
}

export async function serverTranscribe(blob:Blob,prompt='PS ASSISTANT V1.5, Genz Tech Solution, Priyanshu Sharma',language='',signal?:AbortSignal):Promise<string>{
  const fd=new FormData(),type=blob.type.toLowerCase();fd.append('file',blob,type.includes('mp4')?'speech.mp4':type.includes('ogg')?'speech.ogg':'speech.webm');if(language)fd.append('language',language);fd.append('prompt',prompt);
  const r=await fetch('/api/speech/transcribe',{method:'POST',body:fd,credentials:'include',signal:signal?AbortSignal.any([signal,AbortSignal.timeout(20000)]):AbortSignal.timeout(20000)});
  const d=await r.json().catch(()=>({}));
  if(!r.ok)throw new Error(d.error||`Speech HTTP ${r.status}`);
  return String(d.text||'').trim();
}
