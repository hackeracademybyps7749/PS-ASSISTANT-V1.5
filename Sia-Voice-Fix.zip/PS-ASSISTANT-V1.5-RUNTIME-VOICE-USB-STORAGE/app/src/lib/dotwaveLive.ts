export type DotwaveSession={client_secret:string;live_url:string;expires_at?:number;provider:string;model:string};
type Callbacks={onState?:(state:string)=>void;onInput?:(text:string)=>void;onOutput?:(text:string)=>void;onTranscript?:(speaker:'customer'|'sia',text:string)=>void;onError?:(message:string)=>void;onClosed?:(reason:string)=>void};

const MODEL='nemotron-voicechat';
const INPUT_RATE=24000;
const CHUNK_SAMPLES=1920; // 80 ms of mono PCM16 at 24 kHz (3,840 bytes)

export class DotwaveLiveClient{
 private ws:WebSocket|null=null;
 private stream:MediaStream|null=null;
 private ctx:AudioContext|null=null;
 private source:MediaStreamAudioSourceNode|null=null;
 private processor:ScriptProcessorNode|null=null;
 private muteGain:GainNode|null=null;
 private sendTimer:number|undefined;
 private pendingSamples:number[]=[];
 private audioQueue:Uint8Array[]=[];
 private resamplePhase=0;
 private resampleSum=0;
 private resampleCount=0;
 private playbackAt=0;
 private playing=new Set<AudioBufferSourceNode>();
 private inputText='';
 private outputText='';
 private closed=false;
 private callbacks:Callbacks={};

 async connect(session:DotwaveSession,callbacks:Callbacks={}){
  this.callbacks=callbacks;
  if(!navigator.mediaDevices?.getUserMedia)throw new Error('Microphone capture needs HTTPS and a supported browser.');
  if(!window.isSecureContext)throw new Error('Open the deployed HTTPS site to use Dotwave Live microphone access.');
  this.callbacks.onState?.('Requesting microphone…');
  this.stream=await navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
  this.ctx=new AudioContext();await this.ctx.resume();
  if(this.ctx.state!=='running')throw new Error('Browser audio is paused. Click Start Live again and allow audio.');
  this.source=this.ctx.createMediaStreamSource(this.stream);
  this.processor=this.ctx.createScriptProcessor(4096,1,1);
  this.muteGain=this.ctx.createGain();this.muteGain.gain.value=0;
  this.processor.onaudioprocess=e=>this.capture(e.inputBuffer.getChannelData(0));
  this.source.connect(this.processor);this.processor.connect(this.muteGain);this.muteGain.connect(this.ctx.destination);
  this.callbacks.onState?.('Connecting to Dotwave…');
  const url=new URL(session.live_url);url.searchParams.set('token',session.client_secret);
  this.ws=new WebSocket(url.toString());
  await new Promise<void>((resolve,reject)=>{
   let done=false;const timeout=window.setTimeout(()=>finish(new Error('Dotwave connection timed out. Check the key, balance, and network.')),12000);
   const finish=(error?:Error)=>{if(done)return;done=true;window.clearTimeout(timeout);if(error)reject(error);else resolve();};
   this.ws!.onopen=()=>{this.ws!.send(JSON.stringify({type:'session.start',session:{model:MODEL,audio:{input:{format:{type:'audio/pcm',rate:INPUT_RATE}},output:{format:{type:'audio/pcm',rate:INPUT_RATE},encoding:'base64',voice:'aria'}}}}));this.callbacks.onState?.('Starting live voice…');};
   this.ws!.onerror=()=>finish(new Error('Dotwave WebSocket could not connect. Verify the API key and try again.'));
   this.ws!.onclose=e=>{if(!done&&!this.closed)finish(new Error(`Dotwave closed the connection (${e.code}).`));if(!this.closed){this.callbacks.onClosed?.(e.reason||`Connection closed (${e.code})`);void this.dispose(false);}};
   this.ws!.onmessage=e=>{void this.handleMessage(String(e.data),finish);};
  });
  this.callbacks.onState?.('Listening · Dotwave Live (English)');
  this.scheduleAudioSend();
 }

 private async handleMessage(raw:string,finish:(error?:Error)=>void){
  let event:any;try{event=JSON.parse(raw)}catch{return;}
  const kind=String(event?.type||'');
  if(kind==='session.started'){finish();return;}
  if(kind==='error'){const message=String(event?.error?.message||'Dotwave rejected the live session.');finish(new Error(message));this.callbacks.onError?.(message);try{this.ws?.close(1011,'provider error')}catch{}return;}
  if(kind==='session.input_transcript.delta'){
   this.inputText+=String(event.delta||'');this.callbacks.onInput?.(this.inputText);
   if(event.done){const final=String(event.transcript||this.inputText).trim();if(final)this.callbacks.onTranscript?.('customer',final);this.inputText='';this.callbacks.onInput?.('');}
  }else if(kind==='session.output_transcript.delta'){
   this.outputText+=String(event.delta||'');this.callbacks.onOutput?.(this.outputText);
   if(event.done){const final=this.outputText.trim();if(final)this.callbacks.onTranscript?.('sia',final);this.outputText='';this.callbacks.onOutput?.('');}
  }else if(kind==='session.output_audio.delta'&&event.delta){this.playAudio(String(event.delta));}
  else if(kind==='session.turn.event'&&Array.isArray(event.reasons)&&event.reasons.includes('assistant_interrupted'))this.stopPlayback();
  else if(kind==='session.closed'){const reason=String(event.reason||event.detail||'closed');this.callbacks.onClosed?.(reason);void this.dispose(false);}
 }

 private capture(input:Float32Array){
  if(this.closed||!this.ws||this.ws.readyState!==WebSocket.OPEN)return;
  const rate=this.ctx?.sampleRate||48000;
  for(let i=0;i<input.length;i++){
   this.resampleSum+=input[i];this.resampleCount++;this.resamplePhase+=INPUT_RATE;
   if(this.resamplePhase>=rate){let value=this.resampleSum/Math.max(1,this.resampleCount);value=Math.max(-1,Math.min(1,value));this.pendingSamples.push(value<0?Math.round(value*32768):Math.round(value*32767));this.resamplePhase-=rate;this.resampleSum=0;this.resampleCount=0;}
  }
  while(this.pendingSamples.length>=CHUNK_SAMPLES){const samples=this.pendingSamples.splice(0,CHUNK_SAMPLES);const bytes=new Uint8Array(CHUNK_SAMPLES*2);const view=new DataView(bytes.buffer);for(let i=0;i<samples.length;i++)view.setInt16(i*2,samples[i],true);this.audioQueue.push(bytes);}
  // Bound buffering if the network stalls: discard stale mic audio instead of sending it late.
  if(this.audioQueue.length>8)this.audioQueue.splice(0,this.audioQueue.length-4);
 }

 private scheduleAudioSend(){
  const tick=()=>{
   if(this.closed)return;
   const ws=this.ws;
   if(ws?.readyState===WebSocket.OPEN&&this.audioQueue.length&&ws.bufferedAmount<96000){const chunk=this.audioQueue.shift()!;let binary='';for(let i=0;i<chunk.length;i++)binary+=String.fromCharCode(chunk[i]);ws.send(JSON.stringify({type:'session.input_audio.append',audio:btoa(binary)}));}
   this.sendTimer=window.setTimeout(tick,80);
  };
  tick();
 }

 private playAudio(base64:string){
  const ctx=this.ctx;if(!ctx||ctx.state!=='running')return;
  try{
   const raw=atob(base64),frames=Math.floor(raw.length/2);if(!frames)return;
   const pcm=new DataView(new ArrayBuffer(frames*2));for(let i=0;i<frames;i++)pcm.setInt16(i*2,(raw.charCodeAt(i*2)|(raw.charCodeAt(i*2+1)<<8))<<16>>16,true);
   const audio=ctx.createBuffer(1,frames,INPUT_RATE),channel=audio.getChannelData(0);
   for(let i=0;i<frames;i++)channel[i]=pcm.getInt16(i*2,true)/32768;
   const source=ctx.createBufferSource();source.buffer=audio;source.connect(ctx.destination);
   const start=Math.max(ctx.currentTime+.025,this.playbackAt);this.playbackAt=start+audio.duration;this.playing.add(source);source.onended=()=>{this.playing.delete(source);try{source.disconnect()}catch{}};source.start(start);
  }catch(e:any){this.callbacks.onError?.(e?.message||'Dotwave audio playback failed.');}
 }

 private stopPlayback(){for(const source of this.playing){try{source.stop()}catch{}try{source.disconnect()}catch{}}this.playing.clear();this.playbackAt=this.ctx?.currentTime||0;}

 setMuted(muted:boolean){if(this.ws?.readyState===WebSocket.OPEN)this.ws.send(JSON.stringify({type:muted?'session.input_audio.mute':'session.input_audio.unmute'}));}

 async close(){if(this.ws?.readyState===WebSocket.OPEN){try{this.ws.send(JSON.stringify({type:'session.close'}))}catch{}}await this.dispose(true);}

 private async dispose(closeSocket:boolean){
  if(this.closed)return;this.closed=true;if(this.sendTimer)window.clearTimeout(this.sendTimer);this.sendTimer=undefined;
  this.stopPlayback();if(this.processor){this.processor.onaudioprocess=null;try{this.processor.disconnect()}catch{}}try{this.source?.disconnect()}catch{}try{this.muteGain?.disconnect()}catch{}this.stream?.getTracks().forEach(track=>track.stop());if(closeSocket&&this.ws&&this.ws.readyState<2){try{this.ws.close(1000,'client close')}catch{}}this.ws=null;this.stream=null;this.processor=null;this.source=null;this.muteGain=null;try{await this.ctx?.close()}catch{}this.ctx=null;
 }
}
