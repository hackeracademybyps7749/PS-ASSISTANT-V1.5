import { api,secureFetch } from './api';

type VoiceConfig={
  engine?:string;
  endpoint?:string;
  language?:string;
  gender?:string;
  sampleRate?:number;
  browserFallback?:boolean;
  voiceName?:string;
  rate?:string;
  pitch?:string;
  chunkChars?:number;
  usbBridgeUrl?:string;
  cloudConfigured?:boolean;
  bargeIn?:boolean;
  companyName?:string;
  companySpokenName?:string;
};

let currentAudio:HTMLAudioElement|null=null;
let currentUrl:string|null=null;
let settleCurrentAudio:(()=>void)|null=null;
let cancelCurrentBrowser:(()=>void)|null=null;
let configCache:{at:number;value:VoiceConfig}|null=null;
let configPending:Promise<VoiceConfig>|null=null;
let configRevision=0;
let voiceStopToken=0;
let playbackContext:AudioContext|null=null;
let scheduledUntil=0;
const scheduledSources=new Set<AudioBufferSourceNode>();
const pendingVoiceRequests=new Set<AbortController>();
export function invalidateVoiceConfig(){configRevision++;configCache=null;configPending=null;}

export function primeSiaVoice(){try{playbackContext??=new AudioContext();void playbackContext.resume()}catch{}}

function cleanupAudio(){
  for(const source of scheduledSources){try{source.stop()}catch{}try{source.disconnect()}catch{}}
  scheduledSources.clear();scheduledUntil=playbackContext?.currentTime||0;
  const audio=currentAudio,url=currentUrl,settle=settleCurrentAudio;
  currentAudio=null;currentUrl=null;settleCurrentAudio=null;
  if(audio){audio.onended=null;audio.onerror=null;audio.onabort=null;try{audio.pause();audio.removeAttribute('src');audio.load()}catch{}}
  if(url){try{URL.revokeObjectURL(url)}catch{}}
  settle?.();
}

export function stopSiaVoice(){
  voiceStopToken++;
  for(const request of pendingVoiceRequests)request.abort();pendingVoiceRequests.clear();
  cleanupAudio();
  cancelCurrentBrowser?.();
  try{window.speechSynthesis.cancel()}catch{}
}

async function getConfig():Promise<VoiceConfig>{
 if(configCache&&Date.now()-configCache.at<15000)return configCache.value;
 if(configPending)return configPending;const revision=configRevision;
 const pending=(async()=>{try{const s=await api<any>('/api/status',{signal:AbortSignal.timeout(3000)});const value:VoiceConfig=s?.voice||{};if(revision===configRevision)configCache={at:Date.now(),value};return value;}catch{return configCache?.value||{};}})();configPending=pending;
 try{return await pending;}finally{if(configPending===pending)configPending=null;}
}

async function bestHindiFemaleVoice(){
  const synth=window.speechSynthesis;
  let voices=synth.getVoices();
  if(!voices.length)voices=await new Promise<SpeechSynthesisVoice[]>(resolve=>{
    let doneOnce=false;
    const done=()=>{if(doneOnce)return;doneOnce=true;synth.removeEventListener('voiceschanged',done);resolve(synth.getVoices())};
    synth.addEventListener('voiceschanged',done);window.setTimeout(done,700);
  });
  const femaleHints=['swara','neerja','heera','kalpana','priya','aditi','female','google हिन्दी','google hindi'];
  const naturalHints=['natural','neural','online','microsoft','google'];
  const scored=voices.map(v=>{
    const n=v.name.toLowerCase(),l=v.lang.toLowerCase();let score=0;
    if(l==='hi-in')score+=30;else if(l.startsWith('hi'))score+=22;else if(l==='en-in')score+=12;
    if(femaleHints.some(x=>n.includes(x)))score+=18;
    if(naturalHints.some(x=>n.includes(x)))score+=6;
    if(/\bmale\b/.test(n))score-=10;
    return {v,score};
  }).sort((a,b)=>b.score-a.score);
  return scored[0]?.score>0?scored[0].v:null;
}

function speechChunks(text:string,maxChars=120){
  const clean=text.replace(/\s+/g,' ').replace(/([.!?।])\1+/g,'$1').trim();
  if(!clean)return [];
  const rough=clean.split(/(?<=[.!?।,:;])\s+/);
  const out:string[]=[];
  let buf='';
  for(const piece of rough){
    if(!piece)continue;
    if((buf+' '+piece).trim().length<=maxChars){buf=(buf+' '+piece).trim();continue;}
    if(buf)out.push(buf);
    if(piece.length<=maxChars){buf=piece;continue;}
    const words=piece.split(/\s+/);buf='';
    for(const w of words){if((buf+' '+w).trim().length>maxChars){if(buf)out.push(buf);buf=w}else buf=(buf+' '+w).trim();}
  }
  if(buf)out.push(buf);
  return out.filter(Boolean);
}

export function spokenText(input:string,cfg?:VoiceConfig){
  if(cfg?.companyName&&cfg.companySpokenName)input=input.replace(new RegExp(cfg.companyName.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'gi'),cfg.companySpokenName);
  if(!cfg?.companySpokenName||/GEN\s*Z\s+TECH\s+SOLUTIONS?/i.test(cfg.companySpokenName))input=input.replace(/\bGEN\s*Z\s+TECH\s+SOLUTIONS?\b/gi,'जेन ज़ी टेक सॉल्यूशन');
  input=input.replace(/\bVijay\s+Singh(?:\s+Sir)?\b/gi,'विजय सिंह सर');
  const hindi=/[\u0900-\u097f]/.test(input);
  const name=hindi?'सिया':'Sia';
  return input
    .replace(/[\p{Extended_Pictographic}\p{Regional_Indicator}\uFE0F\u200D\u20E3]/gu,'')
    .replace(/```[\s\S]*?```/g,' कोड स्क्रीन पर दिखाया है। ')
    .replace(/`([^`]+)`/g,'$1')
    .replace(/\[([^\]]+)\]\(https?:\/\/[^)]+\)/g,'$1')
    .replace(/https?:\/\/\S+/gi,' लिंक ')
    .replace(/\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b/g,' ईमेल पता ')
    .replace(/\[\[NEEDS_ADMIN_ANSWER\]\]/g,'')
    .replace(/\bPS\s+V1\.5\b/gi,hindi?'पी एस वन पॉइंट फाइव':'PS one point five')
    .replace(/\bPS[\s_-]*ASSISTANT(?:\s+V(?:ERSION)?\s*)?\s*1(?:\s*\.\s*5)\b/gi,name)
    .replace(/\bPS[\s_-]*ASSISTANT\b/gi,name)
    .replace(/\b(?:V|VERSION)\s*1\s*\.\s*5\b/gi,'')
    .replace(/\bAPI\b/gi,hindi?'एपीआई':'API')
    .replace(/\bAI\b/gi,hindi?'एआई':'AI')
    .replace(/\bUSB\b/gi,hindi?'यूएसबी':'USB')
    .replace(/\bURL\b/gi,hindi?'यूआरएल':'URL')
    .replace(/\bUI\b/gi,hindi?'यूआई':'UI')
    .replace(/\bQR\b/gi,hindi?'क्यूआर':'QR')
    .replace(/\bTTS\b/gi,hindi?'वॉइस':'TTS')
    .replace(/^\s{0,3}#{1,6}\s*/gm,'')
    .replace(/^\s*(?:[-*•]|\d+[.)])\s+/gm,'')
    .replace(/[>*_~]/g,'')
    .replace(/[;:]/g,',')
    .replace(/\.{2,}/g,'…')
    .replace(/\s+/g,' ')
    .trim();
}

function browserSpeak(text:string,token:number):Promise<void>{
  return new Promise(async(resolve,reject)=>{
    let settled=false,timer:number|undefined;
    const finish=(error?:Error)=>{if(settled)return;settled=true;window.clearTimeout(timer);if(cancelCurrentBrowser===cancel)cancelCurrentBrowser=null;error?reject(error):resolve()};
    const cancel=()=>finish();cancelCurrentBrowser=cancel;
    try{
      if(token!==voiceStopToken)return finish();
      const voice=await bestHindiFemaleVoice();
      if(token!==voiceStopToken)return finish();
      const chunks=speechChunks(text,210);
      let i=0;
      const next=()=>{
        if(token!==voiceStopToken)return finish();
        if(i>=chunks.length)return finish();
        const chunk=chunks[i++];
        const u=new SpeechSynthesisUtterance(chunk);
        u.lang=/[\u0900-\u097f]/.test(text)?'hi-IN':'en-IN';u.rate=1.08;u.pitch=1.05;u.volume=1;if(voice)u.voice=voice;
        timer=window.setTimeout(()=>finish(new Error('Browser voice playback timed out')),Math.min(60000,Math.max(8000,chunk.length*70)));
        u.onend=()=>{window.clearTimeout(timer);timer=undefined;next()};u.onerror=()=>token!==voiceStopToken?finish():finish(new Error('Browser voice playback failed'));
        window.speechSynthesis.speak(u);
      };
      next();
    }catch(e:any){finish(e instanceof Error?e:new Error(String(e)))}
  });
}

function b64ToBlob(b64:string,type='audio/wav'){
  const clean=b64.includes(',')?b64.split(',').pop()||'':b64;
  const raw=atob(clean);const bytes=new Uint8Array(raw.length);
  for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);
  return new Blob([bytes],{type});
}

async function decodeVoiceBlob(blob:Blob){playbackContext??=new AudioContext();if(playbackContext.state==='suspended')await playbackContext.resume();return playbackContext.decodeAudioData(await blob.arrayBuffer())}

function scheduleVoiceBuffer(buffer:AudioBuffer,token:number){
 return new Promise<void>((resolve,reject)=>{
  if(token!==voiceStopToken)return resolve();
  const ctx=playbackContext;if(!ctx)return reject(new Error('Web Audio playback is unavailable'));
  const source=ctx.createBufferSource();source.buffer=buffer;source.connect(ctx.destination);
  // Remove only measured near-silent encoder padding, leaving a natural edge pause.
  let offset=0,duration=buffer.duration;
  if(typeof buffer.getChannelData==='function'&&buffer.length&&buffer.sampleRate){
    const channels=Array.from({length:buffer.numberOfChannels},(_,i)=>buffer.getChannelData(i));
    const silent=(i:number)=>channels.every(samples=>Math.abs(samples[i])<0.0008);
    let first=0,last=buffer.length-1;
    while(first<Math.min(buffer.length-1,buffer.sampleRate*.25)&&silent(first))first++;
    while(last>Math.max(first,buffer.length-1-buffer.sampleRate*.45)&&silent(last))last--;
    const pad=Math.round(buffer.sampleRate*.035);first=Math.max(0,first-pad);last=Math.min(buffer.length-1,last+pad);
    offset=first/buffer.sampleRate;duration=(last-first+1)/buffer.sampleRate;
  }
  const at=Math.max(ctx.currentTime+.012,scheduledUntil);scheduledUntil=at+duration;scheduledSources.add(source);
  source.onended=()=>{scheduledSources.delete(source);try{source.disconnect()}catch{}resolve()};
  try{source.start(at,offset,duration)}catch(e:any){scheduledSources.delete(source);try{source.disconnect()}catch{}reject(e)}
 });
}

async function legacyPlayBlob(blob:Blob,token:number){
  cleanupAudio();currentUrl=URL.createObjectURL(blob);currentAudio=new Audio(currentUrl);const audio=currentAudio;audio.preload='auto';
  await new Promise<void>((resolve,reject)=>{let settled=false;const finish=(error?:Error)=>{if(settled)return;settled=true;if(settleCurrentAudio===cancel)settleCurrentAudio=null;if(currentAudio===audio){currentAudio=null;audio.onended=null;audio.onerror=null;audio.onabort=null;const url=currentUrl;currentUrl=null;if(url)try{URL.revokeObjectURL(url)}catch{}}error?reject(error):resolve()};const cancel=()=>finish();settleCurrentAudio=cancel;audio.onended=()=>finish();audio.onerror=()=>finish(new Error('Neural voice playback failed'));audio.onabort=()=>token===voiceStopToken?finish(new Error('Neural voice playback stopped unexpectedly')):finish();audio.play().catch(()=>finish(new Error('Audio playback was blocked by the browser')));});
}

async function playBlob(blob:Blob,token:number){
  if(token!==voiceStopToken)return;
  try{const buffer=await decodeVoiceBlob(blob);await scheduleVoiceBuffer(buffer,token)}catch(e){if(token!==voiceStopToken)return;await legacyPlayBlob(blob,token)}
}

async function neuralBlob(endpoint:string,text:string,cfg:VoiceConfig){
  const cloud=cfg.engine==='cloud_tts'||cfg.engine==='elevenlabs';
  if(!cloud&&/Android|iPhone|iPad/i.test(navigator.userAgent)&&/^http:\/\/(?:127\.0\.0\.1|localhost)(?::|\/)/.test(endpoint))throw new Error('PC voice bridge is not reachable from this phone. Use a cloud voice or open the app on the office PC.');
  const controller=new AbortController();pendingVoiceRequests.add(controller);const timer=window.setTimeout(()=>controller.abort(),cloud?14000:8000);
  try{const init={method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({text,voice:cfg.voiceName||'hi-IN-SwaraNeural',rate:cfg.rate||'+10%',pitch:cfg.pitch||'+4Hz'}),signal:controller.signal};const r=cloud?await secureFetch('/api/voice/speech',init):await fetch(endpoint,init);
  if(!r.ok){const d=await r.json().catch(()=>({}));throw new Error(d?.detail||d?.error||`Voice HTTP ${r.status}`)}return await r.blob();}finally{window.clearTimeout(timer);pendingVoiceRequests.delete(controller);}
}

async function neuralLocalSpeak(text:string,cfg:VoiceConfig,token:number,allowBrowserFallback:boolean,first?:Promise<{buffer:AudioBuffer}|{error:any}>){
  const endpoint=(cfg.endpoint||`${cfg.usbBridgeUrl||'http://127.0.0.1:8765'}/tts`).replace(/\s+/g,'');
  const preferred=Math.max(160,Math.min(800,Number(cfg.chunkChars||320)));
  const chunks=speechChunks(text,preferred);
  if(!chunks.length)return;
  const prepare=(chunk:string)=>neuralBlob(endpoint,chunk,cfg).then(decodeVoiceBlob).then(buffer=>({buffer}),error=>({error}));
  let next:Promise<{buffer:AudioBuffer}|{error:any}>|null=first||prepare(chunks[0]);
  let playback:Promise<void>|null=null;
  let startedChunks=0;
  for(let i=0;i<chunks.length;i++){
    if(token!==voiceStopToken||!next)return;
    const result=await next;if('error'in result){if(!startedChunks)throw result.error;if(playback)await playback;const remainder=chunks.slice(i).join(' ');if(allowBrowserFallback&&remainder){await browserSpeak(remainder,token);return 'browser' as const;}throw result.error;}
    next=i+1<chunks.length?prepare(chunks[i+1]):null;
    playback=scheduleVoiceBuffer(result.buffer,token);
    startedChunks++;
  }
  if(playback)await playback;
  return 'neural' as const;
}

async function indicSpeak(text:string,cfg:VoiceConfig,token:number){
  const endpoint=(cfg.endpoint||'http://127.0.0.1:5050/').replace(/\s+/g,'');
  const r=await fetch(endpoint,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({input:[{source:text}],config:{language:{sourceLanguage:cfg.language||'hi'},gender:cfg.gender||'female',samplingRate:Number(cfg.sampleRate||48000)}}),signal:AbortSignal.timeout(20000)});
  if(!r.ok)throw new Error(`IndicTTS HTTP ${r.status}`);
  const d=await r.json();if(d?.status==='ERROR')throw new Error(d?.status_text||'IndicTTS returned an error');
  const audioContent=d?.audio?.[0]?.audioContent;if(!audioContent)throw new Error('IndicTTS returned no audio');
  if(token===voiceStopToken)await playBlob(b64ToBlob(audioContent,'audio/wav'),token);
}

export async function prepareSiaVoice(text:string){
 const token=voiceStopToken,cfg=await getConfig(),clean=spokenText(text,cfg);
 const engine=cfg.engine||'neural_local',fallback=cfg.browserFallback!==false;
 const neural=['neural_local','cloud_tts','elevenlabs'].includes(engine);
 const endpoint=(cfg.endpoint||`${cfg.usbBridgeUrl||'http://127.0.0.1:8765'}/tts`).replace(/\s+/g,'');
 const firstText=speechChunks(clean,Math.max(160,Math.min(800,Number(cfg.chunkChars||320))))[0];
 const first=neural&&firstText&&token===voiceStopToken?neuralBlob(endpoint,firstText,cfg).then(decodeVoiceBlob).then(buffer=>({buffer}),error=>({error})):undefined;
 return {spoken:clean,play:async():Promise<'neural'|'indictts'|'browser'|'cancelled'>=>{
  if(!clean||token!==voiceStopToken)return 'cancelled';
  try{
   if(neural){const r=await neuralLocalSpeak(clean,cfg,token,fallback,first);return token===voiceStopToken?(r==='browser'?'browser':'neural'):'cancelled';}
   if(engine==='indictts_local')await indicSpeak(clean,cfg,token);else await browserSpeak(clean,token);
   return token===voiceStopToken?(engine==='indictts_local'?'indictts':'browser'):'cancelled';
  }catch(e){if(token!==voiceStopToken)return 'cancelled';cleanupAudio();if(fallback){await browserSpeak(clean,token);return token===voiceStopToken?'browser':'cancelled';}throw e;}
 }};
}
export async function speakSiaVoice(text:string):Promise<'neural'|'indictts'|'browser'|'cancelled'>{
 stopSiaVoice();const prepared=await prepareSiaVoice(text);return prepared.play();
}
