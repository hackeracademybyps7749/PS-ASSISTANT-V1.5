export type LocalPhoneInfo={
  ok:boolean;connected:boolean;serial?:string|null;model?:string|null;manufacturer?:string|null;android?:string|null;battery?:number|null;call_state?:string;neural_tts?:boolean;voice?:string;devices?:Array<{serial:string;state:string}>;
};

export const DEFAULT_USB_BRIDGE='http://127.0.0.1:8765';

async function localFetch<T=any>(path:string,init:RequestInit={},base=DEFAULT_USB_BRIDGE):Promise<T>{
  let r:Response;try{r=await fetch(`${base}${path}`,{...init,headers:{...(init.body?{'content-type':'application/json'}:{}),...(init.headers||{})},cache:'no-store',signal:init.signal||AbortSignal.timeout(path==='/health'?6000:12000)});}catch{throw new Error('Office PC USB bridge se connection nahi hua. Bridge start karein, phone unlock karein aur USB debugging allow karein.');}
  const d=await r.json().catch(()=>({}));
  if(!r.ok)throw new Error(d.detail||d.error||`USB bridge HTTP ${r.status}`);
  return d;
}

export const usbPhone={
  health:(base=DEFAULT_USB_BRIDGE)=>localFetch<LocalPhoneInfo>('/health',{},base),
  connect:(base=DEFAULT_USB_BRIDGE)=>localFetch<LocalPhoneInfo>('/connect',{method:'POST'},base),
  dial:(phone:string,base=DEFAULT_USB_BRIDGE)=>localFetch('/dial',{method:'POST',body:JSON.stringify({phone})},base),
  hangup:(base=DEFAULT_USB_BRIDGE)=>localFetch('/hangup',{method:'POST'},base),
  callState:(base=DEFAULT_USB_BRIDGE)=>localFetch<{ok:boolean;state:string;battery?:number}>('/call-state',{},base),
};
