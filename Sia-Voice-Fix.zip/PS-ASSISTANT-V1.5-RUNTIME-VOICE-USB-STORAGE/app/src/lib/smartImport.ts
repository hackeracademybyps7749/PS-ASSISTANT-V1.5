import * as XLSX from 'xlsx';

export type ClientImportRow={business_name:string;contact_number:string;address:string;category:string};
export type SmartImportResult={rows:ClientImportRow[];invalid:number;mapping:Record<string,string>;sheet:string;total:number};

const normalize=(v:string)=>String(v||'').toLowerCase().replace(/[^a-z0-9]+/g,'');
const aliases={
  business_name:['businessname','companyname','shopname','storename','organisationname','organizationname','firmname','clinicname','restaurantname','establishmentname','business','company','shop','store','organisation','organization','firm','name'],
  contact_number:['contactnumber','mobilenumber','phonenumber','whatsappnumber','telephone','mobile','phone','contact','whatsapp','tel','cell','number'],
  address:['fulladdress','businessaddress','streetaddress','postaladdress','address','location','locality','area'],
  category:['businesscategory','businesstype','industrytype','servicecategory','category','industry','sector','type','service']
};

function directMatch(headers:string[], list:string[]){
  const norm=headers.map(h=>({h,n:normalize(h)}));
  for(const a of list){const exact=norm.find(x=>x.n===a);if(exact)return exact.h;}
  for(const a of list){const partial=norm.find(x=>x.n.includes(a)||a.includes(x.n));if(partial&&partial.n.length>2)return partial.h;}
  return '';
}
function phoneScore(values:any[]){let ok=0;for(const v of values.slice(0,40)){const digits=String(v??'').replace(/\D/g,'');if(digits.length>=8&&digits.length<=18)ok++;}return ok;}
function avgLen(values:any[]){const s=values.slice(0,40).map(v=>String(v??'').trim()).filter(Boolean);return s.length?s.reduce((a,b)=>a+b.length,0)/s.length:0;}
function uniqueRatio(values:any[]){const s=values.slice(0,80).map(v=>String(v??'').trim()).filter(Boolean);return s.length?new Set(s).size/s.length:1;}
function addressScore(values:any[]){let score=0;for(const raw of values.slice(0,40)){const v=String(raw??'').toLowerCase();score+=Math.min(2,v.length/35);if(/road|rd\b|street|st\b|nagar|colony|market|near|opposite|district|sector|lane|mohalla|chowk|city|state|pin|pincode|uttar|pradesh/i.test(v))score+=2;}return score;}
function firstPhone(value:any){const raw=String(value??'').trim();const parts=raw.match(/\+?\d[\d\s().-]{7,}\d/g)||[];const candidate=parts[0]||raw;const hasPlus=candidate.trim().startsWith('+');const digits=candidate.replace(/\D/g,'');if(digits.length<8)return '';return `${hasPlus?'+':''}${digits}`;}

function detect(headers:string[], objects:any[]){
  const map:Record<string,string>={};
  map.business_name=directMatch(headers,aliases.business_name);
  map.contact_number=directMatch(headers,aliases.contact_number);
  map.address=directMatch(headers,aliases.address);
  map.category=directMatch(headers,aliases.category);
  const cols=headers.map(h=>({h,values:objects.map(r=>r[h])}));
  const used=()=>new Set(Object.values(map).filter(Boolean));
  if(!map.contact_number){map.contact_number=[...cols].sort((a,b)=>phoneScore(b.values)-phoneScore(a.values))[0]?.h||'';}
  if(!map.address){map.address=[...cols].filter(c=>!used().has(c.h)).sort((a,b)=>addressScore(b.values)-addressScore(a.values))[0]?.h||'';}
  if(!map.business_name){map.business_name=[...cols].filter(c=>!used().has(c.h)).sort((a,b)=>{
    const as=uniqueRatio(a.values)*3+Math.min(avgLen(a.values),35)/20;
    const bs=uniqueRatio(b.values)*3+Math.min(avgLen(b.values),35)/20;
    return bs-as;
  })[0]?.h||'';}
  if(!map.category){map.category=[...cols].filter(c=>!used().has(c.h)).sort((a,b)=>{
    const as=(1-uniqueRatio(a.values))*2+(avgLen(a.values)>2&&avgLen(a.values)<35?1:0);
    const bs=(1-uniqueRatio(b.values))*2+(avgLen(b.values)>2&&avgLen(b.values)<35?1:0);
    return bs-as;
  })[0]?.h||'';}
  return map;
}

export async function smartReadClients(file:File):Promise<SmartImportResult>{
  const buf=await file.arrayBuffer();
  const wb=XLSX.read(buf,{type:'array'});
  if(!wb.SheetNames.length)throw new Error('No worksheet found in this file.');
  let best:{sheet:string;objects:any[];headers:string[]}|null=null;
  for(const sheet of wb.SheetNames){
    const ws=wb.Sheets[sheet];
    const objects=XLSX.utils.sheet_to_json<any>(ws,{defval:'',raw:false});
    if(!objects.length)continue;
    const headers:string[]=Array.from(new Set<string>(objects.flatMap((r:any)=>Object.keys(r))));
    if(!best||objects.length>best.objects.length)best={sheet,objects,headers};
  }
  if(!best)throw new Error('The workbook does not contain readable rows.');
  const mapping=detect(best.headers,best.objects);
  if(!mapping.business_name||!mapping.contact_number)throw new Error('Could not detect business-name and phone columns. Rename those two columns or use the template.');
  let invalid=0;
  const rows:ClientImportRow[]=[];
  for(const r of best.objects){
    const business=String(r[mapping.business_name]??'').trim();
    const phone=firstPhone(r[mapping.contact_number]);
    const address=mapping.address?String(r[mapping.address]??'').trim():'';
    const category=mapping.category?String(r[mapping.category]??'').trim():'';
    if(!business||!phone){invalid++;continue;}
    rows.push({business_name:business,contact_number:phone,address,category});
  }
  return {rows,invalid,mapping,sheet:best.sheet,total:best.objects.length};
}
