import { lazy, Suspense, useEffect, useState, type ReactNode } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { api, authStore, type Role } from './lib/api';
import Login from './pages/Login';
import DeletionGate from './components/DeletionGate';
import AdminDashboard from './pages/AdminDashboard';

const DeveloperLogin=lazy(()=>import('./pages/DeveloperLogin'));
const DeveloperConsole=lazy(()=>import('./pages/DeveloperConsole'));

function Guard({role,children}:{role:Role,children:ReactNode}){
  const[state,setState]=useState<'loading'|'ok'|'no'>('loading');
  useEffect(()=>{api<{role:Role}>(`/api/auth/me?role=${role}`).then(r=>{authStore.setRole(r.role);setState(r.role===role?'ok':'no')}).catch(()=>setState('no'))},[role]);
  if(state==='loading') return <div className="boot-screen">PS ASSISTANT V1.5</div>;
  if(state==='no') return <Navigate to={role==='developer'?'/developer':'/'} replace/>;
  return <>{children}</>;
}

export default function App(){return <Suspense fallback={<div className="boot-screen">Loading…</div>}><DeletionGate/><Routes>
  <Route path="/" element={<Login/>}/>
  <Route path="/admin" element={<Guard role="admin"><AdminDashboard/></Guard>}/>
  <Route path="/developer" element={<DeveloperLogin/>}/>
  <Route path="/developer/console" element={<Guard role="developer"><DeveloperConsole/></Guard>}/>
  <Route path="/system-core-91f7" element={<DeveloperLogin/>}/>
  <Route path="/system-core-91f7/console" element={<Guard role="developer"><DeveloperConsole/></Guard>}/>
  <Route path="*" element={<Navigate to="/" replace/>}/>
</Routes></Suspense>}
