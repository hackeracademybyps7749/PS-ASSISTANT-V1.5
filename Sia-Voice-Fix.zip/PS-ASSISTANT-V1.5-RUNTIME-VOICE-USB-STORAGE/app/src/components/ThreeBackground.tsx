import { useEffect, useRef } from 'react';
import * as THREE from 'three';
export default function ThreeBackground(){
  const ref=useRef<HTMLDivElement>(null);
  useEffect(()=>{
    const el=ref.current;if(!el)return;
    const scene=new THREE.Scene();
    const cam=new THREE.PerspectiveCamera(55,innerWidth/innerHeight,.1,100);cam.position.z=5;
    const renderer=new THREE.WebGLRenderer({alpha:true,antialias:false,powerPreference:'low-power'});
    renderer.setPixelRatio(Math.min(devicePixelRatio,1.15));renderer.setSize(innerWidth,innerHeight);renderer.domElement.style.display='block';el.appendChild(renderer.domElement);
    const group=new THREE.Group();scene.add(group);
    const geo=new THREE.BufferGeometry();const pts=650;const pos=new Float32Array(pts*3);
    for(let i=0;i<pts;i++){const r=2.1+Math.random()*2.6,a=Math.random()*Math.PI*2,b=(Math.random()-.5)*Math.PI;pos[i*3]=Math.cos(a)*Math.cos(b)*r;pos[i*3+1]=Math.sin(b)*r;pos[i*3+2]=Math.sin(a)*Math.cos(b)*r;}
    geo.setAttribute('position',new THREE.BufferAttribute(pos,3));
    const mat=new THREE.PointsMaterial({size:.013,transparent:true,opacity:.42});group.add(new THREE.Points(geo,mat));
    const wire=new THREE.Mesh(new THREE.SphereGeometry(1.55,22,22),new THREE.MeshBasicMaterial({wireframe:true,transparent:true,opacity:.075}));wire.position.set(2.5,1.2,-1.2);scene.add(wire);
    let raf=0,last=0,visible=true;
    const run=(ts:number)=>{if(visible&&ts-last>33){group.rotation.y+=.0009;wire.rotation.y-=.0018;renderer.render(scene,cam);last=ts}raf=requestAnimationFrame(run)};raf=requestAnimationFrame(run);
    const resize=()=>{cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)};
    const visibility=()=>{visible=!document.hidden};
    addEventListener('resize',resize);document.addEventListener('visibilitychange',visibility);
    return()=>{cancelAnimationFrame(raf);removeEventListener('resize',resize);document.removeEventListener('visibilitychange',visibility);geo.dispose();mat.dispose();renderer.dispose();el.innerHTML=''};
  },[]);
  return <div className="three-bg" ref={ref}/>;
}
