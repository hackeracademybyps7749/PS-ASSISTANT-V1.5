import { useEffect, useRef, useState } from 'react';
import { Cable, Mic, PhoneCall, Power, RefreshCw, Volume2 } from 'lucide-react';
import { api, playUiCue } from '../lib/api';
import { DEFAULT_USB_BRIDGE, usbPhone, type LocalPhoneInfo } from '../lib/localPhoneBridge';
import { primeSiaVoice, speakSiaVoice, stopSiaVoice } from '../lib/indicTts';
import {useVoiceConversation} from '../hooks/useVoiceConversation';
import {streamVoiceTurn} from '../lib/voiceTurn';

declare global { interface Window { webkitSpeechRecognition?: any; SpeechRecognition?: any } }

type Props={compact?:boolean;onNotice?:(s:string)=>void};
type CloudCall={id:number;call_ref:string;business_name?:string;contact_number?:string;started_at?:string|null};
type ConversationMessage={role:'user'|'assistant';content:string};

export default function UsbPhoneBridge({compact=false,onNotice}:Props){
  const[info,setInfo]=useState<LocalPhoneInfo|null>(null),[busy,setBusy]=useState(false),[autoDial,setAutoDial]=useState(()=>localStorage.getItem('ps_usb_auto_dial')==='1'),[runtime,setRuntime]=useState<any>(null),[lastState,setLastState]=useState(''),[lastError,setLastError]=useState(''),[aiState,setAiState]=useState('AI idle'),[lastHeard,setLastHeard]=useState(''),[lastReply,setLastReply]=useState(''),[base,setBase]=useState(DEFAULT_USB_BRIDGE);
  const activeRef=useRef<CloudCall|null>(null),sawCallState=useRef(false),cloudConnected=useRef(false),activeStarted=useRef(0),pollBusy=useRef(false);
  const conversationCallId=useRef<number|null>(null),historyRef=useRef<ConversationMessage[]>([]),connectedRef=useRef<boolean|null>(null),healthBusy=useRef(false),greeting=useRef('नमस्ते, मैं एआई सहायक सिया हूँ। क्या अभी थोड़ी बात कर सकती हूँ?');
  const voice=useVoiceConversation({onTurnFinished:async(result)=>{if(result.end_call&&conversationCallId.current){if(result.voice_playback_ok===false){notice('Closing audio unavailable. Please end the phone call manually.');return;}voice.pause();try{await usbPhone.hangup(base)}catch(e:any){notice('Closing line spoken. Hang up the phone manually: '+e.message)}}},onHeard:setLastHeard,onReply:setLastReply,respond:async(text,ctx)=>{const callId=conversationCallId.current;if(!callId)throw new Error('No active call');const history=[...historyRef.current,{role:'user' as const,content:text}].slice(-10);const r=await streamVoiceTurn('/api/assistant/respond/stream',{call_id:callId,message:text,messages:history},ctx.signal,ctx.onDelta,ctx.onReset,ctx.onProgress);if(!ctx.signal.aborted)historyRef.current=[...history,{role:'assistant',content:r.text}].slice(-10) as ConversationMessage[];return r;}});
  const notice=(s:string)=>{setLastError(s);onNotice?.(s)};
  async function refresh(){if(healthBusy.current)return null;healthBusy.current=true;try{const d=await usbPhone.health(base);if(d.connected&&connectedRef.current===false)onNotice?.(`USB phone connected · ${d.model||'Android'}`);connectedRef.current=d.connected;setInfo(d);setLastError('');return d}catch{connectedRef.current=false;setInfo(null);setLastError('Office PC bridge offline. Start the bridge on the PC and connect Android USB.');return null}finally{healthBusy.current=false}}
  async function connect(){setBusy(true);try{const d=await usbPhone.connect(base);connectedRef.current=d.connected;setInfo(d);if(d.connected)notice(`USB phone connected · ${d.model||'Android'}`);else setLastError('Phone not connected. Unlock Android and allow USB debugging.')}catch(e:any){setLastError(e.message||'USB connection unavailable')}finally{setBusy(false)}}
  async function testVoice(){primeSiaVoice();try{const health=await usbPhone.health(base);if(!health.neural_tts){notice('Local bridge is running, but neural TTS is unavailable. Install edge-tts and restart the bridge.');return}const used=await speakSiaVoice('नमस्ते, मैं पी एस असिस्टेंट हूँ। अब मेरी आवाज़ साफ़ सुनाई देनी चाहिए।');notice(used==='neural'?'Neural Hindi voice is working.':`Voice used ${used}. Check the local TTS endpoint in the configured voice settings.`)}catch(e:any){notice(`Local voice bridge is unreachable: ${e?.message||'Check START-USB-PHONE-BRIDGE.ps1'}`)}}
  async function askMicPermission(){try{const s=await navigator.mediaDevices?.getUserMedia?.({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});s?.getTracks().forEach(t=>t.stop());return true}catch{notice('Microphone permission allow karo, phir Auto Dial ON karo.');return false}}
  async function toggleAuto(){const v=!autoDial;if(v&&!await askMicPermission())return;setAutoDial(v);localStorage.setItem('ps_usb_auto_dial',v?'1':'0');window.dispatchEvent(new CustomEvent('ps:usb-auto-dial',{detail:v}));if(!v)stopConversation();notice(v?'USB Auto Dial + Live AI ON':'USB Auto Dial paused')}

  function stopConversation(){voice.pause();conversationCallId.current=null;historyRef.current=[];setAiState('AI idle');}
  async function startConversation(call:CloudCall){if(conversationCallId.current===call.id)return;voice.pause();conversationCallId.current=call.id;historyRef.current=[{role:'assistant',content:greeting.current}];setLastHeard('');setLastReply('');try{const opening=await api<any>(`/api/calls/${call.id}/greeting`);if(conversationCallId.current!==call.id)return;greeting.current=opening.greeting;historyRef.current=[{role:'assistant',content:greeting.current}];await voice.start(greeting.current);}catch(e:any){setLastError(e.message);}}
  useEffect(()=>{if(compact){setAiState(voice.status);window.dispatchEvent(new CustomEvent('ps:usb-voice-status',{detail:{state:voice.status,heard:lastHeard,reply:lastReply}}))}},[voice.status,lastHeard,lastReply]);
  useEffect(()=>{if(compact)return;const sync=(event:Event)=>{const d=(event as CustomEvent).detail;setAiState(d.state);setLastHeard(d.heard);setLastReply(d.reply)};window.addEventListener('ps:usb-voice-status',sync);return()=>window.removeEventListener('ps:usb-voice-status',sync)},[compact]);
  useEffect(()=>{const sync=(event:Event)=>setAutoDial(Boolean((event as CustomEvent).detail));window.addEventListener('ps:usb-auto-dial',sync);return()=>window.removeEventListener('ps:usb-auto-dial',sync)},[]);

  useEffect(()=>{api<any>('/api/status').then(s=>{greeting.current=s.voice?.greeting||greeting.current;voice.setBargeIn(s.voice?.bargeIn!==false);voice.setSpeechMode(s.voice?.speechMode||'fast');const b=String(s?.voice?.usbBridgeUrl||DEFAULT_USB_BRIDGE).trim();if(b)setBase(b.replace(/\/$/,''))}).catch(()=>{});},[]);
  useEffect(()=>{refresh();const t=window.setInterval(refresh,15000);return()=>{clearInterval(t);stopConversation()}},[base]);
  useEffect(()=>{activeRef.current=runtime?.activeCall||null},[runtime]);

  useEffect(()=>{
    if(!compact||!autoDial||!info?.connected)return;
    let stopped=false;
    const tick=async()=>{
      if(stopped||pollBusy.current)return;pollBusy.current=true;
      try{
        const rt:any=await api('/api/usb/runtime');setRuntime(rt);
        const active:CloudCall|null=rt.activeCall||null;
        if(active){
          activeRef.current=active;
          const st=await usbPhone.callState(base);const state=String(st.state||'UNKNOWN').toUpperCase();setLastState(state);
          if(['DIALING','RINGING','OFFHOOK','ACTIVE'].includes(state))sawCallState.current=true;
          if(state==='ACTIVE'){
            if(!cloudConnected.current){await api('/api/usb/call-state',{method:'POST',body:JSON.stringify({call_id:active.id,state:'connected'})});cloudConnected.current=true;activeStarted.current=Date.now();playUiCue('call_start');}
            startConversation(active);
          }
          if(state==='IDLE'&&sawCallState.current){
            stopConversation();
            if(cloudConnected.current){
              playUiCue('call_end');
              const duration=activeStarted.current?Math.max(1,Math.floor((Date.now()-activeStarted.current)/1000)):0;
              await api('/api/usb/call-state',{method:'POST',body:JSON.stringify({call_id:active.id,state:'ended',duration_seconds:duration,outcome:'completed'})});
              notice(`Call completed · ${active.call_ref}`);
            }else{
              playUiCue('call_failed');
              await api('/api/usb/call-state',{method:'POST',body:JSON.stringify({call_id:active.id,state:'no_answer'})});
              notice(`No answer · retry scheduled · ${active.call_ref}`);
            }
            activeRef.current=null;sawCallState.current=false;cloudConnected.current=false;activeStarted.current=0;setRuntime(null);
          }
          return;
        }
        stopConversation();sawCallState.current=false;cloudConnected.current=false;activeStarted.current=0;
        const next:any=await api('/api/usb/next-call',{method:'POST'});
        if(!next?.call)return;
        const c:CloudCall=next.call;activeRef.current=c;
        try{
          await usbPhone.dial(String(c.contact_number||''),base);
          setLastState('DIALING');notice(`Dialing ${c.business_name||c.contact_number||c.call_ref}`);
        }catch(e:any){
          playUiCue('call_failed');
          await api('/api/usb/call-state',{method:'POST',body:JSON.stringify({call_id:c.id,state:'failed'})}).catch(()=>{});
          activeRef.current=null;notice(`USB dial failed: ${e.message}`);
        }
      }catch(e:any){setLastError(e.message||'USB scheduler error')}finally{pollBusy.current=false}
    };
    tick();const t=window.setInterval(tick,2500);return()=>{stopped=true;clearInterval(t);stopConversation()};
  },[compact,autoDial,info?.connected]);

  if(compact)return <div className="usb-compact"><span className={info?.connected?'usb-dot on':'usb-dot'}/><b>{info?.connected?`${info.model||'Android'} USB`:'USB Phone Offline'}</b><span className="usb-ai-mini">{conversationCallId.current?`AI: ${aiState}`:''}</span><button onClick={info?.connected?refresh:connect} disabled={busy}><Cable size={13}/>{info?.connected?'Refresh':'Connect USB'}</button><button className={autoDial?'usb-auto on':'usb-auto'} onClick={toggleAuto} disabled={!info?.connected}><Power size={13}/>{autoDial?'Auto Dial + AI ON':'Auto Dial OFF'}</button></div>;

  return <div className="panel usb-phone-panel"><div className="panel-head"><div><h2>Office Android USB Phone</h2><p>Normal SIM auto-dial + live PS ASSISTANT voice runtime on this office PC.</p></div><span className={`tag ${info?.connected?'calling':'retry'}`}>{info?.connected?'CONNECTED':'OFFLINE'}</span></div><div className="usb-device-grid"><span>Device<b>{info?.model||'-'}</b></span><span>Android<b>{info?.android||'-'}</b></span><span>Battery<b>{info?.battery!=null?`${info.battery}%`:'-'}</b></span><span>Call state<b>{lastState||info?.call_state||'-'}</b></span><span>Neural voice<b>{info?.neural_tts?'READY':'FALLBACK'}</b></span><span>Voice<b>{info?.voice||'hi-IN-SwaraNeural'}</b></span></div><div className="usb-live-ai"><Mic size={16}/><span><b>{aiState}</b><small>{lastHeard?`Customer: ${lastHeard}`:'Waiting for scheduled call'}</small>{lastReply&&<small>PS: {lastReply}</small>}</span></div><div className="actions"><button className="primary" onClick={connect} disabled={busy}><Cable size={14}/>Connect USB Phone</button><button onClick={refresh}><RefreshCw size={14}/>Refresh</button><button onClick={testVoice}><Volume2 size={14}/>Test Female Voice</button><button className={autoDial?'primary':''} onClick={toggleAuto} disabled={!info?.connected}><PhoneCall size={14}/>{autoDial?'Auto Dial + AI ON':'Start Auto Dial + AI'}</button></div>{lastError&&<p className="usb-note">{lastError}</p>}<p className="usb-note">For scheduled hands-free calls keep this Admin page + local bridge open. USB controls normal-SIM dialing/status. For clean two-way cellular audio, set the phone↔PC wired audio interface as the PC input/output; stock Android does not expose raw call audio over the USB data cable.</p></div>
}
