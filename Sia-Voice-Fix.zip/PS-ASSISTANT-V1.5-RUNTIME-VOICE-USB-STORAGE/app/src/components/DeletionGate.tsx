import {useEffect,useRef,useState} from 'react';
import {LockKeyhole,X} from 'lucide-react';
import {api} from '../lib/api';
import type {DeletionRequest} from '../lib/deletion';
export default function DeletionGate(){
 const [request,setRequest]=useState<DeletionRequest|null>(null),[password,setPassword]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 const pending=useRef<DeletionRequest|null>(null);
 useEffect(()=>{const handle=(e:Event)=>{const next=(e as CustomEvent<DeletionRequest>).detail;if(pending.current){next.reject(new Error('Finish the current deletion first.'));return;}pending.current=next;setPassword('');setError('');setRequest(next);window.dispatchEvent(new Event('ps-password-dialog-open'));};window.addEventListener('ps-request-delete-password',handle);return()=>{window.removeEventListener('ps-request-delete-password',handle);pending.current?.reject(new Error('Deletion cancelled'));}},[]);
 function close(){pending.current?.reject(new Error('Deletion cancelled'));pending.current=null;setRequest(null);setPassword('');}
 async function verify(){if(!request||busy)return;setBusy(true);setError('');try{const r=await api<{token:string}>('/api/security/delete-authorize',{method:'POST',body:JSON.stringify({password,path:request.path,method:request.method})});request.resolve(r.token);pending.current=null;setRequest(null);setPassword('');}catch(e:any){setError(e.message)}finally{setBusy(false)}}
 if(!request)return null;
 return <div className="modal-back deletion-back"><form className="deletion-modal" role="dialog" aria-modal="true" aria-label="Confirm deletion" onSubmit={e=>{e.preventDefault();void verify()}}><button type="button" className="modal-x" onClick={close} aria-label="Cancel"><X size={18}/></button><LockKeyhole size={32}/><h2>Delete password</h2><p>Data delete karne ke liye owner ka set kiya hua password daaliye.</p><label>Password<input autoFocus type="password" autoComplete="off" value={password} onChange={e=>setPassword(e.target.value)} required/></label>{error&&<p className="bad" role="alert">{error}</p>}<div className="actions"><button type="button" onClick={close}>Cancel</button><button className="danger" type="submit" disabled={busy||!password}>{busy?'Checking…':'Authorize delete'}</button></div></form></div>;
}
