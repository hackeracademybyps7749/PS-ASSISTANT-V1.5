import { useEffect, useState } from 'react';
import { FileText, Globe2, Search, Trash2, UploadCloud } from 'lucide-react';
import { api } from '../lib/api';
import {primeSiaVoice,prepareSiaVoice} from '../lib/indicTts';

type Source={id:number;title:string;kind:'pdf'|'website'|'web_search';source_url:string;chunk_count:number;created_at:string};
type SearchResult={title:string;url:string;description:string};

async function readPdf(file:File,onPage?:(page:number,total:number)=>void){
  if(file.size>15*1024*1024)throw new Error('PDF 15 MB se bada hai. Chhote parts mein upload karo.');
  const pdfjs=await import('../vendor/pdfjs/pdf.mjs');
  pdfjs.GlobalWorkerOptions.workerSrc=new URL('../vendor/pdfjs/pdf.worker.mjs',import.meta.url).toString();
  const task=pdfjs.getDocument({data:new Uint8Array(await file.arrayBuffer())});
  try{
    const pdf=await task.promise;
    if(pdf.numPages>120)throw new Error('PDF 120 pages se bada hai. Isko chhote parts mein upload karo.');
    const pages:string[]=[];
    for(let i=1;i<=pdf.numPages;i++){
      const page=await pdf.getPage(i),result=await page.getTextContent();
      const lines=result.items.map((item:any)=>String(item.str||'')).filter(Boolean).join(' ').trim();
      if(lines)pages.push(`Page ${i}: ${lines}`);
      page.cleanup();onPage?.(i,pdf.numPages);
    }
    const text=pages.join('\n\n');
    if(text.length<30)throw new Error('Is PDF mein selectable text nahi mila. Scanned photo PDF ko pehle OCR se text PDF banao.');
    if(text.length>190000)throw new Error('PDF ka text 190,000 characters se bada hai. Parts mein split karke upload karo.');
    return {text,pages:pdf.numPages};
  }finally{await task.destroy();}
}

type Props={onActivity?:()=>void;onSpeak?:(text:string)=>Promise<void>;};
export default function KnowledgeSources({onActivity,onSpeak}:Props={}){
  const[sources,setSources]=useState<Source[]>([]),[url,setUrl]=useState(''),[query,setQuery]=useState(''),[results,setResults]=useState<SearchResult[]>([]),[busy,setBusy]=useState(false),[status,setStatus]=useState(''),[selectedFile,setSelectedFile]=useState<File|null>(null),[inspection,setInspection]=useState<any>(null),[nextCursor,setNextCursor]=useState<number|null>(null);
  async function say(text:string){try{if(onSpeak)await onSpeak(text);else{primeSiaVoice();await (await prepareSiaVoice(text)).play();}}catch{/* Saved text remains visible if voice is unavailable. */}}
  function changed(){window.dispatchEvent(new Event('ps-knowledge-changed'));}
  async function refresh(before?:number){try{const r=await api<{sources:Source[];next_cursor:number|null}>('/api/training/sources'+(typeof before==='number'?`?before=${before}`:''));setSources(previous=>typeof before==='number'?[...previous,...r.sources]:r.sources||[]);setNextCursor(r.next_cursor)}catch(e:any){setStatus(e.message)}}
  useEffect(()=>{void refresh();const changed=()=>void refresh();window.addEventListener('ps-knowledge-changed',changed);return()=>window.removeEventListener('ps-knowledge-changed',changed);},[]);
  async function inspect(id:number,offset=0){setBusy(true);onActivity?.();try{const r=await api<any>(`/api/training/sources/${id}/inspect?offset=${offset}`);setInspection(r);setStatus(`“${r.source.title}” की सेव की हुई जानकारी दिखा रही हूँ।`);}catch(e:any){setStatus(e.message)}finally{setBusy(false)}}
  async function upload(){const file=selectedFile;if(!file)return;onActivity?.();setBusy(true);setStatus('PDF पढ़ रही हूँ…');void say('मैं यह पीडीएफ पढ़ रही हूँ। पढ़ने के बाद इसकी जानकारी सेव करूँगी।');try{
    if(!/\.pdf$/i.test(file.name)||file.type&&file.type!=='application/pdf')throw new Error('Sirf PDF file upload karo.');
    const {text,pages}=await readPdf(file,(page,total)=>setStatus(`PDF पढ़ रही हूँ: ${page}/${total} pages…`));
    setStatus(`${pages} pages की जानकारी सेव कर रही हूँ…`);
    const saved=await api<any>('/api/training/sources',{method:'POST',body:JSON.stringify({kind:'pdf',title:file.name,content:text})});
    const message=`मैंने ${file.name} की ${pages} pages की जानकारी सेव कर ली। अब इसके बारे में पूछ सकते हैं।`;
    setStatus(message);setSelectedFile(null);changed();await refresh();await inspect(saved.id);setStatus(message);void say(message);
  }catch(e:any){setStatus(e.message||'PDF save nahi hui')}finally{setBusy(false)}}
  async function website(){onActivity?.();setBusy(true);setStatus('Website पढ़ रही हूँ…');try{const saved=await api<any>('/api/training/sources/website',{method:'POST',body:JSON.stringify({url:url.trim()})});const message=`मैंने ${saved.title} वेबसाइट की जानकारी सेव कर ली।`;setStatus(message);setUrl('');changed();await refresh();void say(message)}catch(e:any){setStatus(e.message||'Website nahi padh payi')}finally{setBusy(false)}}
  async function search(){onActivity?.();setBusy(true);setStatus('Web par khoj rahi hoon…');try{const r=await api<{results:SearchResult[]}>('/api/training/web-search',{method:'POST',body:JSON.stringify({query:query.trim()})});setResults(r.results);setStatus(r.results.length?`${r.results.length} results mile. Jo sahi ho usko Save dabakar memory mein rakho.`:'Koi result nahi mila.')}catch(e:any){setStatus(e.message||'Search failed')}finally{setBusy(false)}}
  async function saveResult(r:SearchResult){onActivity?.();setBusy(true);try{const content=`Web search: ${query.trim()}\nTitle: ${r.title}\nSource: ${r.url}\nSummary: ${r.description}`;await api('/api/training/sources',{method:'POST',body:JSON.stringify({kind:'web_search',title:r.title,source_url:r.url,content})});setStatus(`मैंने “${r.title}” का search summary save किया। Source खोलकर verify भी करें।`);changed();await refresh()}catch(e:any){setStatus(e.message)}finally{setBusy(false)}}
  async function remove(id:number,title:string){onActivity?.();setBusy(true);try{await api(`/api/training/sources/${id}`,{method:'DELETE'});if(inspection?.source.id===id)setInspection(null);setStatus(`मैंने “${title}” की जानकारी memory से हटा दी।`);changed();await refresh()}catch(e:any){setStatus(e.message)}finally{setBusy(false)}}
  return <section className="panel full-span training-sources"><div className="panel-head"><div><h2>PDF, Website & Search · Training</h2><p>PDF चुनें, फिर Inspect & Save दबाएँ। Saved text को नीचे Inspect करके पढ़ सकते हैं।</p></div></div>
    <div className="training-source-grid"><div><h3><FileText size={16}/> Company plan PDF</h3><label className="source-file-label"><UploadCloud size={16}/> Choose PDF<input type="file" accept=".pdf,application/pdf" disabled={busy} onChange={e=>{setSelectedFile(e.target.files?.[0]||null);e.target.value=''}}/></label>{selectedFile&&<p>{selectedFile.name}</p>}<button disabled={busy||!selectedFile} onClick={()=>void upload()}>Inspect & Save PDF</button><small>Searchable PDF: up to 15 MB / 120 pages. Scanned image PDF needs OCR.</small></div>
    <div><h3><Globe2 size={16}/> Learn a website page</h3><input type="url" placeholder="https://your-company.com/plans" value={url} onFocus={onActivity} onChange={e=>setUrl(e.target.value)}/><button disabled={busy||!url.trim()} onClick={()=>void website()}>Read & Save Page</button><small>Public HTTPS page का readable text सेव होगा।</small></div>
    <div><h3><Search size={16}/> Web & Maps search</h3><input value={query} placeholder="Topic or business + city" onFocus={onActivity} onChange={e=>setQuery(e.target.value)}/><button disabled={busy||query.trim().length<3} onClick={()=>void search()}>Search Web</button>{query.trim()&&<a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query.trim())}`} target="_blank" rel="noopener noreferrer">Open Google Maps ↗</a>}<small>Full web search needs a search key. Without a key, general topics use Wikipedia references. Maps opens Google Maps; it does not import verified business data.</small></div></div>
    {status&&<p role="status" className="source-status">{status}</p>}
    {!!results.length&&<div className="training-source-list"><h3>Search results</h3>{results.map((r,i)=><div className="training-source-row" key={`${r.url}-${i}`}><span><b>{r.title}</b><small>{r.description}</small><a href={r.url} target="_blank" rel="noopener noreferrer">Source ↗</a></span><button disabled={busy} onClick={()=>void saveResult(r)}>Save Summary</button></div>)}</div>}
    <div className="training-source-list"><h3>Saved sources · {sources.length}</h3>{sources.length?sources.map(x=><div className="training-source-row" key={x.id}><span><b>{x.title}</b><small>{x.kind} · {x.chunk_count} saved parts · {x.created_at}</small>{x.source_url&&<a href={x.source_url} target="_blank" rel="noopener noreferrer">Source ↗</a>}</span><div className="actions"><button disabled={busy} onClick={()=>void inspect(x.id)}>Inspect</button><button className="danger" disabled={busy} onClick={()=>void remove(x.id,x.title)} title="Delete all knowledge from this source"><Trash2 size={14}/> Delete</button></div></div>):<small>Abhi koi PDF ya website save nahi hai.</small>}{nextCursor!==null&&<button disabled={busy} onClick={()=>void refresh(nextCursor)}>Load more saved sources</button>}</div>
    {inspection&&<section className="source-inspector"><div className="panel-head"><h3>Saved text: {inspection.source.title}</h3><button onClick={()=>setInspection(null)}>Close</button></div><p>{inspection.source.chunk_count} parts saved · showing {inspection.offset+1}–{inspection.offset+inspection.chunks.length}</p>{inspection.chunks.map((c:any)=><article key={c.position}><small>Part {c.position+1}</small><p>{c.content}</p></article>)}<div className="actions"><button disabled={busy||!inspection.offset} onClick={()=>void inspect(inspection.source.id,Math.max(0,inspection.offset-10))}>Previous</button><button disabled={busy||inspection.next_offset===null} onClick={()=>void inspect(inspection.source.id,inspection.next_offset)}>Next</button></div></section>}
  </section>;
}
