import {useEffect,useState,type ReactNode} from 'react';
import {ensureTrainingAccess} from '../lib/trainingAccess';
export default function TrainingGate({children,onClose}:{children:ReactNode;onClose?:()=>void}){
 const [ready,setReady]=useState(false),[error,setError]=useState('');
 async function unlock(){setError('');try{await ensureTrainingAccess();setReady(true)}catch(e:any){setError(e.message)}}
 useEffect(()=>{let live=true;ensureTrainingAccess().then(()=>{if(live)setReady(true)}).catch(e=>{if(live)setError(e.message)});return()=>{live=false}},[]);
 if(!ready)return <div className={onClose?'modal-back':''}><section className="panel"><h2>Training Centre locked</h2><p role="status">{error||'Checking access…'}</p><button className="primary" onClick={unlock}>Unlock Training Centre</button>{onClose&&<button onClick={onClose}>Close</button>}</section></div>;
 return <>{children}</>;
}
