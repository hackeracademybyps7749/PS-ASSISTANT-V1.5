import { BarChart3, BookOpen, CalendarClock, CircleHelp, CloudUpload, Database, Gauge, GraduationCap, LayoutDashboard, LogOut, PhoneCall, Settings, Users, FileDown, ListChecks, Archive, Activity, Coins, Cpu, FileText, HardDrive, Network, PlugZap, SlidersHorizontal, ShieldCheck, MessageSquare } from 'lucide-react';
import { logout } from '../lib/api';

export type AdminSection='Dashboard'|'Live Calls'|'Call Scheduler'|'Client Upload'|'Client Database'|'Call Queue'|'Leads'|'Follow-ups'|'Training Center'|'Knowledge Base'|'Unanswered Questions'|'Export Center'|'History Archive'|'SIA Settings';
export type DevSection='Overview'|'AI Providers'|'Call Chats'|'Call Cost Analytics'|'AI Usage'|'Model Usage'|'Credit Monitor'|'Queue Monitor'|'Latency & Errors'|'Logs'|'System Health'|'Storage'|'System Control'|'Settings';

const adminItems:[AdminSection,any][]=[['Dashboard',LayoutDashboard],['Live Calls',PhoneCall],['Call Scheduler',CalendarClock],['Client Upload',CloudUpload],['Client Database',Database],['Call Queue',ListChecks],['Leads',BarChart3],['Follow-ups',Users],['Training Center',GraduationCap],['Knowledge Base',BookOpen],['Unanswered Questions',CircleHelp],['Export Center',FileDown],['History Archive',Archive],['SIA Settings',Settings]];
const devItems:[DevSection,any][]=[['Overview',Gauge],['AI Providers',PlugZap],['Call Chats',MessageSquare],['Call Cost Analytics',Coins],['AI Usage',Activity],['Model Usage',Cpu],['Credit Monitor',Coins],['Queue Monitor',Network],['Latency & Errors',Activity],['Logs',FileText],['System Health',Activity],['Storage',HardDrive],['System Control',SlidersHorizontal],['Settings',Settings]];

type Props={mode:'admin'|'developer';active?:AdminSection|DevSection;onSelect?:(name:any)=>void;badges?:Record<string,number>;};

export default function Sidebar({mode,active,onSelect,badges={}}:Props){
  const items=mode==='admin'?adminItems:devItems;
  return <aside className="sidebar"><div className="brand"><div className="brand-orb">〽</div><div><b>PS ASSISTANT <span>V1.5</span></b><small>AI VOICE CALLING PLATFORM</small></div></div>
    <nav>{items.map(([n,I])=><button onClick={()=>onSelect?.(n)} className={active===n?'nav active':'nav'} key={n}><I size={18}/><span>{n}</span>{Number(badges[n]||0)>0&&<em className={n==='Unanswered Questions'?'red':''}>{badges[n]}</em>}</button>)}</nav>
    <div className="side-status"><span><ShieldCheck size={14}/></span><div><b>PS ASSISTANT V1.5</b><small>SECURE WORKSPACE</small></div><i/></div>
    <button className="nav logout" onClick={()=>logout(mode)}><LogOut size={18}/><span>Logout</span></button>
  </aside>
}
