import React from 'react';
import {createRoot} from 'react-dom/client';
import {BrowserRouter} from 'react-router-dom';
import AOS from 'aos';
import 'aos/dist/aos.css';
import './styles.css';
import App from './App';
import {installInteractionFx} from './lib/api';
installInteractionFx();
const root=document.getElementById('root')!;
createRoot(root).render(<React.StrictMode><BrowserRouter><App/></BrowserRouter></React.StrictMode>);
AOS.init({duration:460,once:true,offset:14,easing:'ease-out-cubic',disable:()=>window.matchMedia('(prefers-reduced-motion: reduce)').matches||document.documentElement.dataset.motion==='reduced'});
const addRevealTargets=()=>{
  let added=false;
  root.querySelectorAll<HTMLElement>('.main .panel:not([data-aos]),.main .metric:not([data-aos]),.voice-modal:not([data-aos])').forEach((el,index)=>{
    el.dataset.aos='fade-up';el.dataset.aosDelay=String(Math.min(index%6*35,175));added=true;
  });
  if(added)requestAnimationFrame(()=>AOS.refreshHard());
};
const revealObserver=new MutationObserver(addRevealTargets);
revealObserver.observe(root,{childList:true,subtree:true});
addRevealTargets();
