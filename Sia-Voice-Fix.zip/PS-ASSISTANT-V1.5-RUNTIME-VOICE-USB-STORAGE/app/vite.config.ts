import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  build: {
    sourcemap: false,
    minify: 'esbuild',
    cssMinify: true,
    reportCompressedSize: false,
    rollupOptions: {
      output: {
        manualChunks(id){
          if(id.includes('DeveloperConsole') || id.includes('DeveloperLogin')) return 'system-console';
          if(id.includes('three')) return 'visual-engine';
          if(id.includes('xlsx')) return 'sheet-engine';
        }
      }
    }
  },
  esbuild: {
    legalComments: 'none',
    drop: ['debugger']
  },
  server: {
    port: 5173,
    proxy: { '/api': 'http://127.0.0.1:8787' }
  }
});
