export type CallFlow={phase:string;website_status?:string;callback_consent?:'pending'|'accepted'|'declined';callback_question?:string;preferred_time?:string};
export function categoryBenefit(category:string){
 const c=category.toLowerCase();
 if(/restaurant|cafe|bakery|food|रेस्टोरेंट|कैफे/.test(c))return 'मेन्यू, लोकेशन और ग्राहकों की enquiries';
 if(/clinic|doctor|hospital|dent|क्लिनिक|डॉक्टर/.test(c))return 'सेवाओं की जानकारी और appointment enquiries';
 if(/salon|spa|beauty|सैलून/.test(c))return 'सेवाओं की जानकारी और booking enquiries';
 if(/school|coach|institute|education|academy|स्कूल|कोचिंग/.test(c))return 'courses और admission enquiries';
 if(/hotel|resort|travel|होटल/.test(c))return 'सुविधाओं की जानकारी और booking enquiries';
 if(/property|real estate|builder|प्रॉपर्टी/.test(c))return 'properties की जानकारी और enquiries';
 if(/shop|store|retail|garment|electric|दुकान/.test(c))return 'products और ग्राहकों की enquiries';
 return 'आपकी सेवाओं की जानकारी और ग्राहकों की enquiries';
}
export function consentAnswer(raw:string){
 const t=raw.trim().toLowerCase().replace(/[.,!?।]/g,' ').replace(/\s+/g,' ').trim();
 if(/^(?:(?:ji|जी|yes|haan|हाँ)\s+)?(?:no|nope|nah|nahi|nahin|नहीं|नही|ना)(?:\s|$)|मत\s*(?:कर|कीजिए)|don't\s+call|do\s+not\s+call|नहीं\s*चाहिए|नहीं\s*करना|nahi\s*chahiye/.test(t))return 'no';
 if(/^(?:yes|yeah|yep|sure|okay|ok|haan|han|ha|हाँ|हां|जी|बिलकुल|बिल्कुल|ज़रूर|जरूर)(?:\s|$)|(?:call\s*(?:back)?\s*(?:kar|kijiye)|कॉल\s*(?:कर|कीजिए))/.test(t)&&!/[?]|\b(?:why|what|kya|kaise)\b|क्या|क्यों|कैसे/.test(raw))return 'yes';
 return 'unclear';
}
export function localCallFlow(text:string,state:CallFlow,business:string,category:string,closing:string){
 const t=text.toLowerCase(),answer=consentAnswer(text);
 const result=(reply:string,next:CallFlow,end_call=false)=>({text:reply,call_flow:next,end_call});
 if(/stop calling|do not call|don't call|dobara.*call.*mat|दोबारा.*कॉल.*मत|कॉल\s*मत\s*कर/.test(t))return result('जी, मैं समझ गई। आपसे दोबारा कॉल की अनुमति नहीं है। '+closing,{...state,phase:'closed',callback_consent:'declined'},true);
 if(state.phase==='callback_permission'){
  if(answer==='no')return result('जी, कोई callback request नहीं रखूँगी। '+closing,{...state,phase:'closed',callback_consent:'declined'},true);
  if(answer==='yes')return result('जी, callback के लिए आपकी अनुमति मिल गई है। हमारी टीम से बात करने के लिए कौन-सा दिन और समय सुविधाजनक रहेगा?',{...state,phase:'callback_time',callback_consent:'accepted'});
  // An unrelated question is answered by the model; consent remains pending.
 }
 if(state.phase==='callback_time'){
  if(answer==='no')return result('जी, callback की अनुमति वापस ले ली है। '+closing,{...state,phase:'closed',callback_consent:'declined',preferred_time:''},true);
  if(/^(?:\d{1,2})(?::\d{2})?$/.test(text.trim()))return result('कृपया बताइए, सुबह या शाम?',{...state});
  if(/बजे|baje|\b(?:am|pm)\b|कल|आज|परसों|सुबह|शाम|दोपहर|सोमवार|मंगलवार|बुधवार|गुरुवार|शुक्रवार|शनिवार|रविवार|tomorrow|today|morning|evening|afternoon|monday|tuesday|wednesday|thursday|friday|saturday|sunday|kabhi bhi|anytime|कभी भी|baad|later/i.test(text)&&!/[?]|क्या|क्यों|कैसे|\b(?:what|why|kya|kaise)\b/i.test(text))return result('जी, आपकी पसंद का समय टीम के लिए नोट कर रही हूँ: '+text.trim()+'। टीम उपलब्धता देखकर संपर्क करेगी। '+closing,{...state,phase:'closed',preferred_time:text.trim().slice(0,250)},true);
 }
 const existing=((/(?:website|site|वेबसाइट|साइट)/i.test(t)&&(/(?:already|pehle|pahle|bani|ban chuki|have|ready|पहले|बनी|बन चुकी|मौजूद)/i.test(t)||/(?:website|site|वेबसाइट|साइट)\s+(?:toh\s+|तो\s+)?(?:hai|he|है)/i.test(t)))||(state.phase==='website_need'&&/(?:bani|ban chuki|बनी|बन चुकी)/i.test(t)))&&!/(?:nahi|nahin|नहीं|नही|not|don't)/i.test(t);
 if(existing&&state.website_status!=='existing')return result('जी, मैं समझ गई, '+(business?business+' की':'आपकी')+' वेबसाइट पहले से बनी हुई है। क्या आप उसकी speed, design या enquiries में कोई सुधार चाहते हैं?',{...state,phase:'website_upgrade',website_status:'existing'});
 if(state.phase==='website_upgrade'&&answer==='no')return result('जी, मैं समझ गई, अभी कोई बदलाव नहीं चाहिए। '+closing,{...state,phase:'closed',callback_consent:'declined'},true);
 if(state.phase==='website_upgrade'&&answer==='yes')return result('जी, किस चीज़ में सुधार चाहिए—design, speed या enquiries?',{...state,phase:'requirements'});
 if(state.phase==='opening'&&answer==='yes')return result((business?business+' के लिए':'आपके व्यवसाय के लिए')+' वेबसाइट से '+categoryBenefit(category)+' दिखा सकते हैं। क्या आपकी वेबसाइट पहले से है, या नई बनवाने की ज़रूरत है?',{...state,phase:'website_need'});
 if(state.phase==='opening'&&answer==='no')return result('जी, अभी बात नहीं करना चाहते, मैं समझ गई। '+closing,{...state,phase:'closed',callback_consent:'declined'},true);
 return null;
}
