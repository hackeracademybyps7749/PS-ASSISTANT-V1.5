-- Add safe default auth and provider settings if the D1 database is older.
INSERT INTO developer_settings(setting_key,setting_value,updated_at)
VALUES('speech_mode','fast',CURRENT_TIMESTAMP)
ON CONFLICT(setting_key) DO NOTHING;

-- Slightly brighter Swara pitch and a quicker pace, matching the new gapless player.
UPDATE developer_settings
SET setting_value='+10%', updated_at=CURRENT_TIMESTAMP
WHERE setting_key='tts_rate' AND setting_value IN ('+6%','+8%');

UPDATE developer_settings
SET setting_value='+4Hz', updated_at=CURRENT_TIMESTAMP
WHERE setting_key='tts_pitch' AND setting_value IN ('+0Hz','+2Hz');
