ALTER TABLE calls ADD COLUMN archived_at TEXT;
ALTER TABLE clients ADD COLUMN archived_at TEXT;
CREATE INDEX IF NOT EXISTS idx_calls_archived_at ON calls(archived_at);
CREATE INDEX IF NOT EXISTS idx_clients_archived_at ON clients(archived_at);
INSERT OR IGNORE INTO developer_settings(setting_key, setting_value) VALUES
  ('auto_archive_days','30'),
  ('smart_import_enabled','1'),
  ('keyboard_shortcuts_enabled','1'),
  ('personal_phone_mode_enabled','1');
