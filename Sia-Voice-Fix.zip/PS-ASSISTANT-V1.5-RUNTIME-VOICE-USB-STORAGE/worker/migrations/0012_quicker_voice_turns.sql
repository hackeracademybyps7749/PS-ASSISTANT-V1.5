-- Increase the neural voice rate after user feedback that speech was too slow.
UPDATE developer_settings
SET setting_value='+6%', updated_at=CURRENT_TIMESTAMP
WHERE setting_key='tts_rate' AND setting_value='-3%';
