-- Streaming-compatible provider adapters and faster voice defaults.
INSERT INTO developer_settings(setting_key,setting_value,updated_at)
VALUES('speech_mode','fast',CURRENT_TIMESTAMP)
ON CONFLICT(setting_key) DO NOTHING;
UPDATE developer_settings SET setting_value='240',updated_at=CURRENT_TIMESTAMP
WHERE setting_key='voice_response_max_tokens' AND setting_value='180';
UPDATE developer_settings SET setting_value='12000',updated_at=CURRENT_TIMESTAMP
WHERE setting_key='provider_timeout_ms' AND setting_value='25000';
UPDATE developer_settings SET setting_value='+8%',updated_at=CURRENT_TIMESTAMP
WHERE setting_key='tts_rate' AND setting_value IN ('+6%','-3%');
UPDATE developer_settings SET setting_value='+2Hz',updated_at=CURRENT_TIMESTAMP
WHERE setting_key='tts_pitch' AND setting_value IN ('+0Hz','0Hz');
