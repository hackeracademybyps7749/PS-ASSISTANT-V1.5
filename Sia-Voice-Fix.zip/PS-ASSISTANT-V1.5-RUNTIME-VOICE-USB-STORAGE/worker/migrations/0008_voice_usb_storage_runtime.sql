PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS client_memory (
  client_id INTEGER PRIMARY KEY,
  memory_text TEXT NOT NULL DEFAULT '',
  last_call_id INTEGER,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE CASCADE,
  FOREIGN KEY(last_call_id) REFERENCES calls(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_client_memory_updated ON client_memory(updated_at);

INSERT OR IGNORE INTO speech_corrections(heard_text, corrected_text, normalized_heard) VALUES
  ('jaldi tech solution','Genz Tech Solution','jaldi tech solution'),
  ('gen z tech solution','Genz Tech Solution','gen z tech solution'),
  ('gen zee tech solution','Genz Tech Solution','gen zee tech solution'),
  ('genzi tech solution','Genz Tech Solution','genzi tech solution'),
  ('gens tech solution','Genz Tech Solution','gens tech solution'),
  ('जेन जेड टेक सॉल्यूशन','Genz Tech Solution','जेन जेड टेक सॉल्यूशन'),
  ('जेनजी टेक सॉल्यूशन','Genz Tech Solution','जेनजी टेक सॉल्यूशन'),
  ('जल्दी टेक सॉल्यूशन','Genz Tech Solution','जल्दी टेक सॉल्यूशन');

INSERT OR IGNORE INTO developer_settings(setting_key, setting_value) VALUES
  ('tts_engine','neural_local'),
  ('tts_endpoint','http://127.0.0.1:8765/tts'),
  ('tts_voice','hi-IN-SwaraNeural'),
  ('tts_rate','+4%'),
  ('tts_pitch','+2Hz'),
  ('voice_chunk_chars','360'),
  ('voice_response_max_tokens','180'),
  ('provider_timeout_ms','8000'),
  ('cloudflare_plan','free'),
  ('d1_db_limit_mb','500'),
  ('d1_account_limit_mb','5120'),
  ('usb_phone_bridge_url','http://127.0.0.1:8765'),
  ('customer_memory_enabled','1'),
  ('speech_server_enabled','1');

UPDATE developer_settings SET setting_value='neural_local'
WHERE setting_key='tts_engine' AND setting_value='indictts_local';
UPDATE developer_settings SET setting_value='http://127.0.0.1:8765/tts'
WHERE setting_key='tts_endpoint' AND (setting_value='' OR setting_value='http://127.0.0.1:5050/');

UPDATE developer_settings SET setting_value='360' WHERE setting_key='voice_chunk_chars' AND CAST(setting_value AS INTEGER)<240;
