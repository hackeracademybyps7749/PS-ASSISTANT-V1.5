-- User-supplied company details. Keep any existing Admin edits.
UPDATE company_profile SET
 company_name=CASE WHEN TRIM(company_name) IN ('','Your Company') THEN 'GENZ TECH SOLUTION' ELSE company_name END,
 intro=CASE WHEN TRIM(intro)='' OR LOWER(TRIM(intro)) LIKE 'you are sia%' THEN 'GENZ TECH SOLUTION provides website, mobile app, software and digital marketing services. Ask about the customer need before discussing a solution.' ELSE intro END,
 address=CASE WHEN TRIM(address)='' THEN '12, Matiyari Chauraha, Lucknow, Uttar Pradesh 226028, India' ELSE address END,
 website=CASE WHEN TRIM(website)='' THEN 'https://www.genztechsolution.com/' ELSE website END,
 working_hours=CASE WHEN TRIM(working_hours)='' THEN '10:00 AM to 6:00 PM IST' ELSE working_hours END,
 cofounder_name=CASE WHEN TRIM(cofounder_name)='' THEN 'Vijay Singh' ELSE cofounder_name END,
 updated_at=CURRENT_TIMESTAMP WHERE id=1;

INSERT INTO developer_settings(setting_key,setting_value) VALUES
 ('call_greeting','क्या अभी आपके पास एक मिनट बात करने का समय है?'),
 ('call_farewell','आपका समय देने के लिए धन्यवाद। आपका दिन शुभ हो।'),
 ('call_service_guide','ग्राहक की बात सुनें। केवल ज़रूरी सेवा समझाएँ और एक बार में एक सवाल पूछें। कीमत, समयसीमा या परिणाम का वादा बिना पुष्टि के न करें।'),
 ('company_spoken_name','जेन ज़ी टेक सॉल्यूशन')
ON CONFLICT(setting_key) DO NOTHING;

INSERT INTO services(name,description)
SELECT 'Website design and development','New websites and improvements to existing websites, based on project requirements.'
WHERE NOT EXISTS(SELECT 1 FROM services WHERE LOWER(name) LIKE '%website%');
INSERT INTO services(name,description)
SELECT 'Mobile application development','Android and iOS app development based on requirements.'
WHERE NOT EXISTS(SELECT 1 FROM services WHERE LOWER(name) LIKE '%app%');
INSERT INTO services(name,description)
SELECT 'Custom software and IT solutions','Software and IT solutions tailored to the customer workflow.'
WHERE NOT EXISTS(SELECT 1 FROM services WHERE LOWER(name) LIKE '%software%');
INSERT INTO services(name,description)
SELECT 'Digital marketing','SEO, social media marketing, PPC and content marketing subject to agreed scope.'
WHERE NOT EXISTS(SELECT 1 FROM services WHERE LOWER(name) LIKE '%marketing%');

INSERT INTO faqs(question,answer,category)
SELECT 'What is the official company website?','https://www.genztechsolution.com/','Company'
WHERE NOT EXISTS(SELECT 1 FROM faqs WHERE LOWER(question) LIKE '%official company website%');
INSERT INTO faqs(question,answer,category)
SELECT 'Where is the office?','12, Matiyari Chauraha, Lucknow, Uttar Pradesh 226028, India.','Company'
WHERE NOT EXISTS(SELECT 1 FROM faqs WHERE LOWER(question) LIKE '%where is the office%');
INSERT INTO faqs(question,answer,category)
SELECT 'What are the office hours?','10:00 AM to 6:00 PM IST.','Company'
WHERE NOT EXISTS(SELECT 1 FROM faqs WHERE LOWER(question) LIKE '%office hours%');
INSERT INTO faqs(question,answer,category)
SELECT 'How can a customer contact the company?','Phone: +91 8299395080. Email: info@genztechsolution.com.','Company'
WHERE NOT EXISTS(SELECT 1 FROM faqs WHERE LOWER(question) LIKE '%contact the company%');

-- Replace only old, overly long call openings that caused script recitation.
UPDATE developer_settings SET setting_value='क्या अभी आपके पास एक मिनट बात करने का समय है?',updated_at=CURRENT_TIMESTAMP
WHERE setting_key='call_greeting' AND (LENGTH(setting_value)>300 OR LOWER(TRIM(setting_value)) LIKE 'you are sia%');
-- Earlier default presets raised pace and pitch and return them to natural synthesis.
UPDATE developer_settings SET setting_value='+0%',updated_at=CURRENT_TIMESTAMP WHERE setting_key='tts_rate' AND setting_value='+10%';
UPDATE developer_settings SET setting_value='+0Hz',updated_at=CURRENT_TIMESTAMP WHERE setting_key='tts_pitch' AND setting_value='+4Hz';
