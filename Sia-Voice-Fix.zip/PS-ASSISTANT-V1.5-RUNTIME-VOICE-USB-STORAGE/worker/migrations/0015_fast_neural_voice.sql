-- Existing installs used a 1200 character utterance which delayed first audio and could stall.
UPDATE developer_settings SET setting_value='320',updated_at=CURRENT_TIMESTAMP WHERE setting_key='voice_chunk_chars' AND (CAST(setting_value AS INTEGER)>=1000 OR CAST(setting_value AS INTEGER)<160);
