ALTER TABLE company_profile ADD COLUMN cofounder_name TEXT NOT NULL DEFAULT '';
UPDATE company_profile SET cofounder_name='Vijay Singh Sir' WHERE UPPER(TRIM(company_name))='GENZ TECH SOLUTION' AND cofounder_name='';
