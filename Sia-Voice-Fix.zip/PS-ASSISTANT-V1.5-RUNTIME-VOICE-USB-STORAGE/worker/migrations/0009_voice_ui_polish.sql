-- Enable the requested subtle reveal motion by default. A Developer can still
-- switch to Reduced motion, and the browser's OS accessibility setting wins.
UPDATE developer_settings
SET setting_value='full', updated_at=CURRENT_TIMESTAMP
WHERE setting_key='ui_motion' AND setting_value='reduced';

INSERT OR IGNORE INTO developer_settings(setting_key,setting_value)
VALUES('ui_motion','full');
