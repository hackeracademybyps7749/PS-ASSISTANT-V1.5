CREATE TABLE training_access_grants(token_hash TEXT PRIMARY KEY, session_hash TEXT NOT NULL, expires_at INTEGER NOT NULL);
CREATE TABLE training_access_attempts(attempt_key TEXT PRIMARY KEY, failures INTEGER NOT NULL DEFAULT 0, window_start INTEGER NOT NULL);
CREATE TABLE training_reset_backups(id TEXT PRIMARY KEY, payload TEXT NOT NULL CHECK(json_valid(payload)), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE training_operation_guard(id INTEGER PRIMARY KEY CHECK(id=1),active_calls INTEGER NOT NULL CHECK(active_calls=0));
