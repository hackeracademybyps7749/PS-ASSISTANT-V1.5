-- Use one longer neural speech segment for normal replies and a calm Swara pace.
UPDATE developer_settings
SET setting_value='1200', updated_at=CURRENT_TIMESTAMP
WHERE setting_key='voice_chunk_chars'
  AND CAST(setting_value AS INTEGER)<=700;

UPDATE developer_settings
SET setting_value='-3%', updated_at=CURRENT_TIMESTAMP
WHERE setting_key='tts_rate' AND setting_value IN ('+0%','+4%');

UPDATE developer_settings
SET setting_value='+0Hz', updated_at=CURRENT_TIMESTAMP
WHERE setting_key='tts_pitch' AND setting_value='+2Hz';
