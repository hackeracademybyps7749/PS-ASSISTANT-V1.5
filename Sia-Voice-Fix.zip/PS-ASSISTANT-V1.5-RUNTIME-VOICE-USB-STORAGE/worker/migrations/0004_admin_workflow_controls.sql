ALTER TABLE clients ADD COLUMN source_import_id INTEGER;
CREATE INDEX IF NOT EXISTS idx_clients_source_import ON clients(source_import_id);
INSERT OR IGNORE INTO developer_settings(setting_key, setting_value) VALUES
  ('ui_sound_enabled','1'),
  ('ui_sound_volume','0.06'),
  ('auto_analyze_on_call_end','1'),
  ('analysis_fallback_enabled','1');
-- Safe backfill for installations that had exactly one Excel import before batch linking was introduced.
UPDATE clients
SET source_import_id = (SELECT MAX(id) FROM client_imports)
WHERE source_import_id IS NULL
  AND (SELECT COUNT(*) FROM client_imports) = 1;
