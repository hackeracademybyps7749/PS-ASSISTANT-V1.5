CREATE TABLE IF NOT EXISTS ai_providers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  provider_type TEXT NOT NULL DEFAULT 'openai_compatible',
  base_url TEXT NOT NULL,
  model_id TEXT NOT NULL,
  region TEXT NOT NULL DEFAULT '',
  auth_mode TEXT NOT NULL DEFAULT 'bearer',
  api_key_encrypted TEXT NOT NULL DEFAULT '',
  api_key_hint TEXT NOT NULL DEFAULT '',
  input_cost_per_million REAL NOT NULL DEFAULT 0,
  output_cost_per_million REAL NOT NULL DEFAULT 0,
  enabled INTEGER NOT NULL DEFAULT 1,
  is_primary INTEGER NOT NULL DEFAULT 0,
  priority INTEGER NOT NULL DEFAULT 100,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS developer_settings (
  setting_key TEXT PRIMARY KEY,
  setting_value TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS developer_change_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  action TEXT NOT NULL,
  target TEXT NOT NULL,
  details TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT OR IGNORE INTO developer_settings(setting_key, setting_value) VALUES
  ('assistant_extra_prompt',''),
  ('default_language','hi-IN'),
  ('temperature','0.25'),
  ('max_tokens','400'),
  ('ui_motion','reduced'),
  ('credit_total_usd','0'),
  ('call_bridge_url',''),
  ('call_bridge_token_encrypted',''),
  ('call_bridge_mode','custom_http');

ALTER TABLE ai_usage ADD COLUMN provider_name TEXT NOT NULL DEFAULT '';

CREATE INDEX IF NOT EXISTS idx_ai_providers_primary ON ai_providers(is_primary, enabled, priority);
CREATE INDEX IF NOT EXISTS idx_dev_change_log_created_at ON developer_change_log(created_at);
INSERT OR IGNORE INTO developer_settings(setting_key, setting_value) VALUES
  ('theme_cyan','#23d8ff'),
  ('theme_green','#1dffb0'),
  ('theme_amber','#ffb62e'),
  ('theme_pink','#ff4fb9'),
  ('theme_violet','#8f62ff');
INSERT OR IGNORE INTO developer_settings(setting_key, setting_value) VALUES
  ('scheduler_enabled','1'),
  ('timezone_offset_minutes','330'),
  ('last_scheduler_at','0');
