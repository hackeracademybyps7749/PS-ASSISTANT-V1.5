CREATE TABLE IF NOT EXISTS call_conversation_state (
 call_id INTEGER PRIMARY KEY,
 state_json TEXT NOT NULL DEFAULT '{}',
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(call_id) REFERENCES calls(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS call_search_history (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 call_id INTEGER NOT NULL,
 turn_id TEXT NOT NULL,
 question TEXT NOT NULL,
 results_json TEXT NOT NULL DEFAULT '[]',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(call_id) REFERENCES calls(id) ON DELETE CASCADE,
 UNIQUE(call_id,turn_id)
);
CREATE INDEX IF NOT EXISTS idx_call_search_history_call ON call_search_history(call_id,id);
