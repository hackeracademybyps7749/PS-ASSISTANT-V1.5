-- Let Kaggle Qwen finish normal generations, and reduce choppy TTS chunk boundaries.
UPDATE developer_settings
SET setting_value='25000', updated_at=CURRENT_TIMESTAMP
WHERE setting_key='provider_timeout_ms'
  AND CAST(setting_value AS INTEGER)<25000;

UPDATE developer_settings
SET setting_value='650', updated_at=CURRENT_TIMESTAMP
WHERE setting_key='voice_chunk_chars'
  AND CAST(setting_value AS INTEGER)<500;

UPDATE developer_settings
SET setting_value='+0%', updated_at=CURRENT_TIMESTAMP
WHERE setting_key='tts_rate' AND setting_value='+4%';
