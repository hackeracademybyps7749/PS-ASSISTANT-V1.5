CREATE TABLE IF NOT EXISTS deletion_grants (
 token_hash TEXT PRIMARY KEY,
 panel_role TEXT NOT NULL,
 request_path TEXT NOT NULL,
 request_method TEXT NOT NULL,
 expires_at INTEGER NOT NULL,
 used INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS deletion_auth_attempts (
 attempt_key TEXT PRIMARY KEY,
 failures INTEGER NOT NULL DEFAULT 0,
 window_start INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_deletion_grants_expiry ON deletion_grants(expires_at);
INSERT OR IGNORE INTO developer_settings(setting_key,setting_value) VALUES ('voice_barge_in_enabled','1'),('auto_web_search_enabled','1');
