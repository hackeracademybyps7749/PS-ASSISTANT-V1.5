INSERT OR IGNORE INTO developer_settings(setting_key, setting_value) VALUES
  ('tts_engine','indictts_local'),
  ('tts_endpoint','http://127.0.0.1:5050/'),
  ('tts_language','hi'),
  ('tts_gender','female'),
  ('tts_sample_rate','48000'),
  ('tts_browser_fallback','1');
