PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS admin_training_lessons (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lesson_text TEXT NOT NULL,
  normalized_key TEXT NOT NULL UNIQUE,
  source TEXT NOT NULL DEFAULT 'voice_admin',
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS speech_corrections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  heard_text TEXT NOT NULL,
  corrected_text TEXT NOT NULL,
  normalized_heard TEXT NOT NULL UNIQUE,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS learning_suggestions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  call_id INTEGER UNIQUE,
  suggestion_text TEXT NOT NULL,
  evidence TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reviewed_at TEXT,
  FOREIGN KEY(call_id) REFERENCES calls(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_training_lessons_active ON admin_training_lessons(active, id);
CREATE INDEX IF NOT EXISTS idx_learning_suggestions_status ON learning_suggestions(status, id);

INSERT OR IGNORE INTO speech_corrections(heard_text, corrected_text, normalized_heard) VALUES
  ('jaldi tech solution','Genz Tech Solution','jaldi tech solution'),
  ('gen z tech solution','Genz Tech Solution','gen z tech solution'),
  ('genz tech solution','Genz Tech Solution','genz tech solution');

INSERT OR IGNORE INTO developer_settings(setting_key, setting_value) VALUES
  ('admin_live_training_enabled','1'),
  ('customer_learning_suggestions','1'),
  ('voice_auto_resume','1'),
  ('voice_recognition_language','hi-IN');
