# PS ASSISTANT V1.5 — Full Control Update

## Fixed
- Developer login uses its own HttpOnly cookie and can stay logged in at the same time as Admin.
- Developer login works at `/developer` and the legacy owner route `/system-core-91f7`.
- Removed AOS card transitions that could make dashboard boxes flash/disappear.
- Reduced Three.js GPU load and paused rendering in background tabs.
- KPI cards show live-data wording instead of fake percentage growth.
- Production CORS now supports same-origin Cloudflare Worker deployment.

## Developer no-code controls
Developer Console → **AI Providers** lets the owner add/edit/test/enable/disable/reorder providers without source-code changes.

Supported presets:
- AWS Bedrock
- OpenAI
- Groq
- OpenRouter
- Together AI
- Mistral AI
- Google Gemini OpenAI-compatible endpoint
- Google Gemini Native GenerateContent + SSE streaming
- DeepSeek
- xAI
- Anthropic native Messages API
- Custom OpenAI-compatible endpoint

Separate live-voice option:
- Dotwave Nemotron VoiceChat over Live WebSocket; this is not sent through the text-model router.
- Dotwave sessions require browser microphone/speaker access and have provider-specific language, session, and billing limits. See `SETUP_AND_TROUBLESHOOTING.md`.

The primary provider is tried first. Other enabled providers are automatic fallbacks if the primary fails. This means an AWS daily quota error can fall back to another configured provider.

API keys saved from Developer Console are AES-GCM encrypted before D1 storage. They are never returned to the browser.

Developer Console → **System Control** changes:
- global assistant instruction
- language
- temperature
- max output tokens
- app-side credit total
- phone bridge URL/token/mode
- reset operational/demo data
- reset AI logs

## Real calling
Cloudflare cannot directly dial a SIM/PSTN number. The app sends queued call jobs to the configured authorized Phone Bridge. The bridge can be your own Android/SIM bridge, SIP adapter, GSM gateway service, or a telephony provider adapter.

Flow:
`Excel → D1 → Campaign Scheduler → Call Queue → Phone Bridge → Customer → STT/Voice layer → AI Router → TTS → Customer`

The project includes the bridge contract/hook; a real phone transport still needs an authorized telephony bridge or device.

## Update existing installation
1. Back up/copy your current `worker/.dev.vars` into this project for local testing.
2. Run:
   ```powershell
   cd worker
   npx wrangler d1 migrations apply DB --remote
   cd ../app
   npm install
   npm run build
   cd ../worker
   npx wrangler dev
   ```
3. Developer login: `http://127.0.0.1:8787/developer`
4. Add an alternate AI provider under **AI Providers** if AWS Bedrock is quota-limited.

## Cloudflare deploy
Run from project root:
```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\deploy-cloudflare.ps1
```
