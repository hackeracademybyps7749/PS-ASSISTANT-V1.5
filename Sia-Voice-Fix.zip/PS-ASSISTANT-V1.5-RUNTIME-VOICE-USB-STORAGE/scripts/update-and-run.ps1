$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
Write-Host "[1/4] Installing dependencies..." -ForegroundColor Cyan
npm install
Write-Host "[2/4] Applying D1 migrations..." -ForegroundColor Cyan
Set-Location "$root\worker"
npx wrangler d1 migrations apply DB --remote
Write-Host "[3/4] Building dashboard..." -ForegroundColor Cyan
Set-Location "$root\app"
npm run build
Write-Host "[4/4] Starting local Worker..." -ForegroundColor Cyan
Set-Location "$root\worker"
npx wrangler dev
