$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Write-Host "PS ASSISTANT V1.5 - Cloudflare Deployment" -ForegroundColor Cyan
Set-Location $root

Write-Host "[1/5] Installing dependencies..." -ForegroundColor Yellow
npm install

Write-Host "[2/5] Applying D1 migrations..." -ForegroundColor Yellow
Set-Location "$root\worker"
npx wrangler d1 migrations apply DB --remote

Write-Host "[3/5] Building frontend..." -ForegroundColor Yellow
Set-Location "$root\app"
npm run build

Write-Host "[4/5] Ensuring Cloudflare secrets..." -ForegroundColor Yellow
Set-Location "$root\worker"
$answer = Read-Host "Do you want to set/update production login/auth secrets now? (y/N)"
if ($answer -match '^[Yy]') {
  npx wrangler secret put ADMIN_ACCESS_CODE
  npx wrangler secret put DEV_ACCESS_CODE
  npx wrangler secret put AUTH_SECRET
  $aws = Read-Host "Set/update AWS_BEDROCK_API_KEY environment fallback? (y/N)"
  if ($aws -match '^[Yy]') { npx wrangler secret put AWS_BEDROCK_API_KEY }
  $enc = Read-Host "Set a separate CONFIG_ENCRYPTION_KEY? (recommended) (y/N)"
  if ($enc -match '^[Yy]') { npx wrangler secret put CONFIG_ENCRYPTION_KEY }
}

Write-Host "[5/5] Deploying Worker + Assets..." -ForegroundColor Yellow
npx wrangler deploy
Write-Host "Deployment complete. Admin: /  | Developer: /developer" -ForegroundColor Green
