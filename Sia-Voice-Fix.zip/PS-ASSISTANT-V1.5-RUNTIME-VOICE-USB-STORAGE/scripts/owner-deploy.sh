#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../app"
npm install
npm run build
cd ../worker
npm install
npx wrangler d1 migrations apply DB --remote
printf '\nSet/rotate the four production secrets if required:\n'
printf '  npx wrangler secret put AWS_BEDROCK_API_KEY\n'
printf '  npx wrangler secret put ADMIN_ACCESS_CODE\n'
printf '  npx wrangler secret put DEV_ACCESS_CODE\n'
printf '  npx wrangler secret put AUTH_SECRET\n\n'
npx wrangler deploy
