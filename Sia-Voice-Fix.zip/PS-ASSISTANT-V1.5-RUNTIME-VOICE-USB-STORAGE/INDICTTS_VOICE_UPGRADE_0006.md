# IndicTTS Voice Upgrade 0006

PS ASSISTANT V1.5 now defaults to AI4Bharat IndicTTS Hindi Female voice for:
- Admin Training Center voice replies
- Personal/phone AI voice replies
- Replay buttons

Developer controls:
- TTS engine
- local endpoint
- language
- gender
- sample rate
- browser fallback

D1 migration: `0006_indictts_voice.sql`.
