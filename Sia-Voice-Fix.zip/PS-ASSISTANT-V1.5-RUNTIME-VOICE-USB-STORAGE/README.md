Latest Sia call and voice update: read [`docs/SIA_CUSTOMER_TALK_20261015.md`](docs/SIA_CUSTOMER_TALK_20261015.md).

# PS ASSISTANT V1.5 — Owner Build

Premium Admin Panel + isolated Developer Console + Excel client import/export + call scheduling + transcripts + lead scoring + voice training + server-side AI adapter.

## Voice recognition and Sia setup

For the fixed repeated-transcript handling, mobile browser fallback, Kaggle notebook, and Sia's supplied call script, start with [`docs/VOICE_RECOGNITION_FIX_AND_SETUP.md`](docs/VOICE_RECOGNITION_FIX_AND_SETUP.md). The notebook is [`kaggle/PS_ASSISTANT_KAGGLE_ADVANCED_20261015.ipynb`](kaggle/PS_ASSISTANT_KAGGLE_ADVANCED_20261015.ipynb).

## Security model in this version

The deployed Admin Panel does not expose provider/model names, AWS configuration, API keys, AI token/cost data, technical logs, or any Developer Console link.

Sensitive operations stay in the Cloudflare Worker. Login sessions use an HttpOnly cookie, so the browser JavaScript cannot read the session token.

Production builds are minified and source maps are disabled. This makes the delivered frontend compact, but remember: browser UI code can never be made literally impossible to inspect. The actual protection is that secrets and proprietary backend logic never reach the browser.

**Do not give this source ZIP to an admin/client.** Give them only the deployed URL + Admin access code.

See `OWNER_SECURITY.md` and `ADMIN_HANDOFF.txt`.

## Architecture

Admin Browser → Cloudflare Worker → D1
                              → secure AI provider adapter (owner-only configuration)
                              → optional authorized telephony bridge

Developer Console is separately authenticated and receives technical usage/cost/model diagnostics. Admin responses intentionally omit those fields.

For the verified deployment order, daily Kaggle restart steps, phone setup, memory commands, sound settings, and troubleshooting, read `SETUP_AND_TROUBLESHOOTING.md`.

## Install

```bash
npm install
```

## Create D1

```bash
cd worker
npx wrangler d1 create ps-assistant-v15
```

Copy the returned database ID into `worker/wrangler.jsonc`, then:

```bash
cp .dev.vars.example .dev.vars
npx wrangler d1 migrations apply DB --local
```

## Owner-only AI configuration

Put the provider credential only in `worker/.dev.vars` for local development or a Cloudflare Worker secret in production.

```env
AWS_BEDROCK_API_KEY=...
ADMIN_ACCESS_CODE=...
DEV_ACCESS_CODE=...
AUTH_SECRET=use-a-long-random-secret
```

The React app never receives `AWS_BEDROCK_API_KEY`.

The Kaggle Qwen3 + Faster-Whisper V3 endpoint is configured in Developer → AI Providers after the notebook prints its temporary tunnel URL and API key. Do not replace the existing `AUTH_SECRET` when deploying over the current D1 database.

## Local run

Terminal 1:

```bash
cd worker
npm run dev
```

Terminal 2:

```bash
cd app
npm run dev
```

Open `http://localhost:5173` for Admin login.

The engineering login is intentionally not linked from the Admin interface. Owner-only route:

```text
/system-core-91f7
```

Knowing that route is not enough: the Worker still requires the independent Developer credential on every protected developer request.

## Cloudflare deployment

```bash
cd app
npm install
npm run build

cd ../worker
npm install
npx wrangler d1 migrations apply DB --remote
npx wrangler secret put AWS_BEDROCK_API_KEY
npx wrangler secret put ADMIN_ACCESS_CODE
npx wrangler secret put DEV_ACCESS_CODE
npx wrangler secret put AUTH_SECRET
npx wrangler deploy
```

After deployment, give admins only the deployed URL and Admin access code.

## AI request flow

Admin-facing code calls a generic endpoint:

```text
POST /api/assistant/respond
```

The Worker privately selects/configures the provider/model and stores technical usage in `ai_usage`. Admin responses return only business-relevant fields (`text`, `needsAdmin`). Technical usage is only available to Developer role endpoints.

## Phone calling

`phone-bridge/mock-server.py` is still only an integration mock. Real cellular/PSTN calling requires an authorized SIP/telephony provider or a compliant SIM bridge. Keep telemarketing/DND/consent requirements applicable to your deployment in mind.


## Workflow Upgrade 0004

See `WORKFLOW_UPGRADE_0004.md` for Excel batch deletion, queue controls, automatic call analysis, UI sounds and phone-bridge testing. For real phone connectivity, see `phone-bridge/PHONE_CONNECTION_GUIDE.md`.

## Productivity Upgrade 0005

After upgrading an existing installation, apply:

```powershell
cd worker
npx wrangler d1 migrations apply DB --remote
```

Expected new migration: `0005_productivity_archive.sql`.

New admin productivity features:
- smart drag-and-drop XLSX/XLS/CSV import with automatic column detection
- bulk select/delete and bulk queue
- History Archive with restore/export/delete
- automatic archival age controlled by Developer Console
- Personal Phone AI speakerphone companion using a normal SIM/number (no separate telephony provider fee)
- extensive keyboard shortcuts; PDF in `docs/PS-ASSISTANT-V1.5-SHORTCUT-KEYS.pdf`

See `phone-bridge/PERSONAL_PHONE_MODE.md` for the no-gateway normal-phone workflow and its OS limitations.

## Hindi female voice
Admin Training and phone voice default to local neural `hi-IN-SwaraNeural` via the office-PC TTS bridge; browser Hindi female speech is the automatic fallback. AI4Bharat IndicTTS is still available as an alternate local engine from Developer → System Control.

## AI provider protocols
The provider router supports OpenAI-compatible Chat Completions, OpenAI Responses, Anthropic Messages, and Google's native Gemini GenerateContent streaming API. Many commercial and hosted models work through OpenAI-compatible endpoints. A custom provider using a different protocol needs a dedicated adapter; no universal API key format works with every AI service. Provider keys remain server-side and are encrypted in D1.

Dotwave Nemotron VoiceChat is configured as the separate **Dotwave Live Voice · WebSocket** provider type. Its optional browser microphone/speaker session is distinct from the text model route and the Android SIM connection; see `SETUP_AND_TROUBLESHOOTING.md` for setup and limitations.


## Kaggle Free AI + accurate speech mode (Qwen3 4B + Whisper)
Use `kaggle/PS_ASSISTANT_QWEN3_VOICE_API_V3.ipynb`. It runs Qwen3 4B with PyTorch/Transformers and Faster-Whisper `large-v3-turbo`, serves OpenAI-compatible `/v1/chat/completions` plus `/v1/audio/transcriptions`, and prints the temporary endpoint + key for Developer → AI Providers.

Developer Panel → AI Providers → preset **Kaggle Qwen3 4B** → paste the printed `.../v1/chat/completions` URL and API key → Primary ON → Save → Test. Admin Panel then uses Kaggle automatically; provider secrets stay developer-only.

Kaggle notebook sessions and Quick Tunnel URLs are temporary, so rerun the V3 notebook and update the endpoint/key after a restart. See `SETUP_AND_TROUBLESHOOTING.md` for Kaggle session limits and the daily restart workflow.

## Voice reply and Admin session fix (2026-10-05)
Admin and Developer tabs can now select their own signed session cookie, so opening the Developer Console no longer makes Admin Classroom requests fail with “Admin access required”. Classroom ignores duplicate final speech events, removes fully duplicated transcript phrases, and the live Whisper request falls back sooner if the server is slow. The Admin Classroom close and Refresh buttons now use the app's dark themed controls. See the troubleshooting table for redeploy steps.

## Admin Q&A and voice stability fix (2026-10-05)
Admin Classroom now uses its own general-assistant instructions and sends recent conversation turns; customer-call fallback instructions no longer constrain Admin questions. Provider timeouts are raised for Kaggle Qwen, empty model answers are retried through configured providers, and an unavailable model returns a clear service error instead of a successful fixed reply. Neural speech is generated before playback so a failed later clip cannot restart the already-spoken answer. Audio cancellation settles cleanly, voice clips are longer and slower, and the text reply appears while speech plays. Migration `0010_admin_voice_reliability.sql` applies the safe defaults to existing D1 settings.
