// Local-only fixture for manual UI checks. It never connects to production D1.
import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {join,extname,resolve} from 'node:path';
const root=resolve('app/dist');
const fixture={
 '/api/dashboard':{clients:0,callsToday:0,questionsNeedAnswer:0,scheduledCalls:0,interestedLeads:0,callbacksPending:0,successRate:0},
 '/api/clients':[], '/api/calls':[], '/api/unanswered':[], '/api/imports':[],
 '/api/company/knowledge':{profile:{company_name:'UI Test Company'},services:[],faqs:[],rules:[]},
 '/api/status':{aiConfigured:true,voice:{engine:'browser',speechMode:'fast',bargeIn:true}},
 '/api/ui-config':{ui_motion:'reduced',ui_sound_enabled:'0'},
 '/api/training/state':{lessons:[],corrections:[],suggestions:[]},
 '/api/training/sources':{sources:[]}, '/api/dev/providers':{providers:[]},
 '/api/dev/settings':{tts_engine:'browser',ui_motion:'reduced',ui_sound_enabled:'0'},
 '/api/dev/metrics':{totals:{requests:0,cost:0,avg_latency:0},recent:[],events:[],imports:[],credit:{},storage:{tables:[]}}
};
http.createServer(async(req,res)=>{const u=new URL(req.url,'http://localhost');if(u.pathname.startsWith('/api/')){res.setHeader('Content-Type','application/json');res.end(JSON.stringify(u.pathname==='/api/auth/me'?{role:u.searchParams.get('role')||'admin',name:'Fixture User'}:fixture[u.pathname]||{}));return;}
 const path=u.pathname.startsWith('/assets/')?join(root,u.pathname):join(root,'index.html');try{const b=await readFile(path);res.setHeader('Content-Type',({'.js':'application/javascript','.css':'text/css','.html':'text/html','.mjs':'application/javascript'})[extname(path)]||'application/octet-stream');res.end(b);}catch{res.writeHead(404);res.end('not found');}
}).listen(8790,'127.0.0.1',()=>console.log('Local UI fixture at http://127.0.0.1:8790/admin'));
