import {build} from 'esbuild';
import assert from 'node:assert/strict';
import {writeFile,rm,mkdtemp} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';

const folder=await mkdtemp(join(tmpdir(),'ps-voice-capture-'));
let elapsed=0,nextFrame=0,closedContext=false,stoppedTrack=false,clips=[];
const frames=new Map();
globalThis.requestAnimationFrame=cb=>{const id=++nextFrame;const timer=setTimeout(()=>{elapsed+=100;cb(elapsed);},0);frames.set(id,timer);return id};
globalThis.cancelAnimationFrame=id=>{clearTimeout(frames.get(id));frames.delete(id)};
Object.defineProperty(globalThis,'performance',{value:{now:()=>elapsed},configurable:true});
Object.defineProperty(globalThis,'navigator',{value:{mediaDevices:{getUserMedia:async()=>({getTracks:()=>[{stop(){stoppedTrack=true}}]})}},configurable:true});
globalThis.AudioContext=class{createAnalyser(){return {fftSize:0,getFloatTimeDomainData(samples){samples.fill(elapsed>=300&&elapsed<700?.1:0)}}}createMediaStreamSource(){return {connect(){}}}async close(){closedContext=true}};
globalThis.MediaRecorder=class{static isTypeSupported(type){return type==='audio/webm;codecs=opus'}constructor(_stream,options){this.mimeType=options?.mimeType||'audio/webm';this.state='inactive'}start(){this.state='recording'}stop(){this.state='inactive';this.ondataavailable?.({data:new Blob([new Uint8Array(2400)],{type:this.mimeType})});this.onstop?.()}};
try{
 const built=await build({entryPoints:['app/src/lib/speechCapture.ts'],bundle:true,write:false,format:'esm',platform:'node'});
 const file=join(folder,'capture.mjs');await writeFile(file,built.outputFiles[0].text);const capture=await import(file);
 const listener=await capture.startVoiceActivityCapture(blob=>clips.push(blob));assert.ok(listener,'capture should request microphone access');
 for(let i=0;i<50&&clips.length===0;i++)await new Promise(resolve=>setTimeout(resolve,2));
 assert.equal(clips.length,1,'speech followed by 850ms of silence creates one clip');assert.equal(clips[0].type,'audio/webm;codecs=opus');
 await listener.stop();assert.ok(stoppedTrack,'stop releases microphone');assert.ok(closedContext,'stop closes audio context');
 console.log('PASS: audio-only speech pause detection, supported mobile recorder formats and microphone cleanup');
}finally{for(const timer of frames.values())clearTimeout(timer);await rm(folder,{recursive:true,force:true});}
