import {build} from 'esbuild';
import assert from 'node:assert/strict';
import {mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
const folder=await mkdtemp(join(tmpdir(),'sia-mobile-'));
const turns=[];
globalThis.__mobile={capture:null,transcriptions:0};
globalThis.window={setTimeout,clearTimeout,addEventListener(){},removeEventListener(){}};
Object.defineProperty(globalThis,'navigator',{value:{mediaDevices:{getUserMedia:async()=>({getTracks:()=>[{stop(){}}]})}},configurable:true});
try{
 const built=await build({entryPoints:['app/src/hooks/useVoiceConversation.ts'],bundle:true,write:false,format:'esm',platform:'node',plugins:[{name:'mocks',setup(b){
  b.onResolve({filter:/^react$/},()=>({path:'react',namespace:'mock'}));
  b.onResolve({filter:/indicTts$/},()=>({path:'tts',namespace:'mock'}));
  b.onResolve({filter:/speechCapture$/},()=>({path:'capture',namespace:'mock'}));
  b.onLoad({filter:/.*/,namespace:'mock'},args=>({contents:args.path==='react'
   ?'export const useRef=v=>({current:v});export const useState=v=>[v,()=>{}];export const useEffect=f=>f();'
   :args.path==='tts'
   ?"export const primeSiaVoice=()=>{};export const stopSiaVoice=()=>{};export const prepareSiaVoice=async text=>({spoken:text,play:async()=> 'neural'});"
   :"export const startMicCapture=async()=>null;export const startVoiceActivityCapture=async cb=>{globalThis.__mobile.capture=cb;return {stop:async()=>null}};export const serverTranscribe=async()=>{globalThis.__mobile.transcriptions++;return 'मुझे वेबसाइट चाहिए';};",loader:'js'}));
 }}]});
 const file=join(folder,'hook.mjs');await writeFile(file,built.outputFiles[0].text);const {useVoiceConversation}=await import(file);
 const voice=useVoiceConversation({onHeard(){},onReply(){},respond:async text=>{turns.push(text);return {text:'जी, वेबसाइट के लिए आपको किस तरह की सुविधा चाहिए?'}}});
 await voice.start();await new Promise(r=>setTimeout(r,0));assert.equal(typeof globalThis.__mobile.capture,'function','mobile browser starts server recognition without a setting change');
 globalThis.__mobile.capture(new Blob(['sample audio']));await new Promise(r=>setTimeout(r,30));
 assert.equal(globalThis.__mobile.transcriptions,1);assert.deepEqual(turns,['मुझे वेबसाइट चाहिए']);voice.pause();
 console.log('PASS: mobile browser automatically transcribes audio and sends the recognized customer question');
}finally{await rm(folder,{recursive:true,force:true});}
