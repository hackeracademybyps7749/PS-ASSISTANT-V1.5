import {build} from 'esbuild';
import {writeFile,mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import assert from 'node:assert/strict';
const folder=await mkdtemp(join(tmpdir(),'ps-voice-test-'));
const cleanups=[],played=[],audioWaiters=[],events=new Map(),recognizers=[];
globalThis.__voiceTest={cleanups,played,audioWaiters};
globalThis.window={setTimeout,clearTimeout,addEventListener:(n,f)=>events.set(n,f),removeEventListener:n=>events.delete(n)};
Object.defineProperty(globalThis,'navigator',{value:{mediaDevices:{getUserMedia:async()=>({getTracks:()=>[{stop(){}}]})}},configurable:true});
class Recognition{constructor(){recognizers.push(this)}start(){this.onstart?.()}abort(){this.onend?.()}}
window.SpeechRecognition=Recognition;
try{
 const result=await build({entryPoints:['app/src/hooks/useVoiceConversation.ts'],bundle:true,format:'esm',write:false,platform:'node',plugins:[{name:'voice-test-adapters',setup(build){build.onResolve({filter:/^react$/},()=>({path:'react',namespace:'test'}));build.onResolve({filter:/indicTts$/},()=>({path:'voice',namespace:'test'}));build.onLoad({filter:/.*/,namespace:'test'},args=>({contents:args.path==='react'?`export const useRef=v=>({current:v});export const useState=v=>[v,()=>{}];export const useEffect=f=>{const c=f();if(c)globalThis.__voiceTest.cleanups.push(c);};`:`export const primeSiaVoice=()=>{};export const prepareSiaVoice=async text=>({spoken:text,play:()=>speakSiaVoice(text)});export const speakSiaVoice=async text=>{globalThis.__voiceTest.played.push(text);await new Promise(r=>globalThis.__voiceTest.audioWaiters.push(r));return 'neural';};export const stopSiaVoice=()=>{for(const r of globalThis.__voiceTest.audioWaiters.splice(0))r();};`,loader:'js'}));}}]});
 const file=join(folder,'hook.mjs');await writeFile(file,result.outputFiles[0].text);const {useVoiceConversation}=await import(file);
 const turns=[],replies=[],finished=[];let finishFirst;
 const voice=useVoiceConversation({onTurnFinished:r=>finished.push(r),onHeard(){},onReply:t=>replies.push(t),respond:async(text,ctx)=>{turns.push({text,ctx});if(turns.length===1){ctx.onDelta('पहला जवाब। ');return new Promise(r=>finishFirst=r)}ctx.onProgress('लाइन पर बने रहिए, मैं चेक करके बताती हूँ।');ctx.onDelta('ठीक है, आपकी नई बात सुन रही हूँ। अगला पूरा वाक्य भी सुनिए। ');return {text:'ठीक है, आपकी नई बात सुन रही हूँ। अगला पूरा वाक्य भी सुनिए।',end_call:true};}});
 await voice.start();let rec=recognizers.at(-1);assert.equal(rec.continuous,true);
 function speech(text,final){rec.onresult({resultIndex:0,results:[Object.assign([{transcript:text}],{isFinal:final})]});}
 speech('पहला',false);speech('पहला सवाल',false);speech('पहला सवाल',true);speech('सवाल',true);speech('पहला सवाल',true);speech('पहला सवाल',true);await new Promise(r=>setTimeout(r,900));assert.equal(turns.length,1);assert.equal(turns[0].text,'पहला सवाल','interim revisions, final fragments and cumulative revisions should form one turn without duplication');assert.equal(played[0],'पहला जवाब।');speech('पहला सवाल',true);await new Promise(r=>setTimeout(r,900));assert.equal(turns.length,1,'duplicate final result is not a new user turn');
 speech('पहला जवाब',true);assert.equal(turns.length,1,'speaker echo must not become a new user turn');
 speech('रुको मेरी बात सुनो',false);assert.equal(turns[0].ctx.signal.aborted,false,'microphone stays suspended while Sia speaks');
 voice.interrupt();assert.equal(turns[0].ctx.signal.aborted,true,'Stop & listen cancels the old reply');rec=recognizers.at(-1);speech('रुको मेरी बात सुनो',true);await new Promise(r=>setTimeout(r,900));assert.equal(turns.length,2);
 finishFirst({text:'पहला जवाब। यह पुराना अतिरिक्त जवाब है।'});await new Promise(r=>setTimeout(r,0));assert.equal(played.some(x=>x.includes('पुराना अतिरिक्त')),false,'old reply cannot resume after interruption');
 assert.equal(finished.length,0,'call completion waits for all speech playback');
 for(let i=0;i<4;i++){for(const done of audioWaiters.splice(0))done();await new Promise(r=>setTimeout(r,0));}assert.equal(played.join(' ').split('अगला पूरा वाक्य भी सुनिए।').length-1,1,'remaining full sentence is played exactly once');assert.ok(played.some(t=>t.includes('लाइन पर बने रहिए')),'lookup progress must be spoken');assert.equal(finished.length,1,'cancelled old turn never completes a call');assert.equal(finished[0].end_call,true);voice.pause();for(const cleanup of cleanups)cleanup();
 console.log('PASS: continuous listening, speaker-echo suppression, manual speech interruption, request cancellation and stale-answer suppression');
}finally{await rm(folder,{recursive:true,force:true});}
