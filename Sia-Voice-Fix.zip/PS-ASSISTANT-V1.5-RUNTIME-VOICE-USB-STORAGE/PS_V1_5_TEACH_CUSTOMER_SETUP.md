# PS V1.5 · GENZ TECH SOLUTION

## Install this update
1. Extract the ZIP into a new folder. Keep your previous working folder as a backup.
2. Copy your existing Cloudflare configuration (worker/wrangler.toml and the same D1 binding) and worker/.dev.vars into this folder. Keep AUTH_SECRET and CONFIG_ENCRYPTION_KEY unchanged so saved provider keys remain readable. Never upload these secrets publicly.
3. In the extracted project root, run:

```powershell
powershell -ExecutionPolicy Bypass -File .\LIVE_DEPLOY.ps1
```

The script applies D1 migrations including 0019, builds the app, and deploys it. Use your existing Admin and Developer access codes.

## Company and training
- Admin > SIA Settings > Company Profile: verify GENZ TECH SOLUTION and Co-founder Vijay Singh Sir; save. Migration fills the co-founder only when this company was already configured and the field was empty.
- Developer voice pronunciation setting overrides the default. GENZ TECH SOLUTION defaults to जेन ज़ी टेक सॉल्यूशन, and Vijay Singh Sir is rendered as विजय सिंह सर for speech. Adjust your pronunciation override if your company pronounces GENZ differently.
- Admin > Training Center > Teach Me: ask normal questions; say “याद रखो हमारी कंपनी …” or use Teach this to save a complete approved fact. Saved lessons remain visible. Deletion still requires the configured password.
- Save the call opening, service guidance and closing here. Upload services, approved prices, FAQs and PDFs. The assistant must not invent missing company facts.
- Customer Talk: role-play as a customer. Start conversation speaks the same saved AI introduction and greeting used for calls. The agent answers service questions, asks one useful requirement/lead question, and follows approved guidance. This mode never dials a real number, saves a training lesson, deletes a record, or creates a real customer call. Switching modes stops speech and clears conversation history.
- Real dialing still uses Client Database / Queue / Scheduler and the existing USB Phone Bridge. Keep the Admin tab and bridge running. Android USB dialing requires the supported phone setup and call-audio path described in SETUP_AND_TROUBLESHOOTING.md.

## Kaggle and voice
Import kaggle/PS_ASSISTANT_KAGGLE_ADVANCED_20261015.ipynb, enable GPU and Internet, configure your private key and run all cells. The notebook contains a bounded 4.5-hour serving window, caches and recovery for exited local services. Kaggle platform shutdowns/quotas cannot be prevented by this app. After a Quick Tunnel URL changes, update the saved provider URL/key, then Developer > Use saved Kaggle neural voice > Save & test voice. Voice model is ps-swara-neural; chat model is ps-qwen3-4b in fast mode.

Fast recognition is the default. Use a headset to reduce speaker echo; Accurate mode adds a transcription round trip. The voice stream starts after the first complete sentence, groups later complete sentences, prepares speech ahead of playback, and trims only measured near-silent encoder padding. Interrupted requests and prefetched audio are cancelled. Text remains available when the speech provider fails.

## Verification and practical limits
App production build, Worker dry-run build, runtime security/memory/customer-policy tests, interruption tests, and audio preparation/pronunciation tests passed. Tests cover customer-practice mutation prevention, saved co-founder data, mode validation, cancellation, duplicate recognition suppression, and bounded silence trimming. They use mocked speech/audio services. Actual Kaggle GPU performance, live synthesized audio quality, Android USB call audio and phone/browser microphone behavior still require testing on your equipment. Response speed depends on network, model and TTS service; no universal API compatibility or zero-error/instant-response guarantee is made.
