# Productivity Upgrade 0005

- Smart spreadsheet import for XLSX/XLS/CSV with automatic column detection and phone cleanup.
- Drag & drop import.
- Bulk selection and Select All for Client Database, Call Queue/Calls, Import History, Unanswered Questions and History Archive.
- Bulk delete with active-call safety checks.
- Bulk queue selected clients.
- History Archive for completed/old calls, restore, export and permanent delete.
- Developer setting: automatic archive age (default 30 days).
- Personal Phone AI mode for a normal SIM phone on speaker, with live text transcript and post-call analysis.
- Keyboard shortcut system and in-app shortcut help.
- Shortcut PDF included in docs.
- Existing click sounds and tactile button animation retained.
