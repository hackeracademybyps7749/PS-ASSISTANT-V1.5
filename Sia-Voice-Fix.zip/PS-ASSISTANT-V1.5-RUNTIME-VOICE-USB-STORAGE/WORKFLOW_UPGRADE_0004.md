# PS ASSISTANT V1.5 — Workflow Upgrade 0004

This update adds:

- Excel import batch ownership (`source_import_id`)
- Admin can delete an uploaded Excel batch and its linked client data
- Active calls are protected from accidental batch/client deletion
- Per-item queue delete
- Clear entire queued/scheduled/retry queue with confirmation
- Duplicate queue protection
- AI-first call analysis with local evidence-based fallback if an AI provider is unavailable
- Optional automatic post-call analysis
- 5-second operational polling for call-start, call-end and needs-help sound alerts
- Global click sounds and press animation
- Developer controls for sound, analysis fallback and automatic post-call analysis
- Developer Phone Bridge test button
- Real phone connection guide

## Upgrade

Copy your existing `worker/.dev.vars` into this version, then run:

```powershell
cd D:\PS-ASSISTANT-V1.5-WORKFLOW-UPGRADE
npm install
cd worker
npx wrangler d1 migrations apply DB --remote
cd ../app
npm run build
cd ../worker
npx wrangler dev
```

Expected new migration:

```text
0004_admin_workflow_controls.sql  ✅
```

Or run the helper:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\update-and-run.ps1
```

## Deleting an Excel batch

Admin → Client Upload → Import History → Delete Batch.

For uploads made after migration 0004, linked clients are removed together with queued/retry call records. Active calls are protected and must be ended first.

If the installation had exactly one import before migration 0004, it is safely linked to the existing clients during migration. With multiple historical imports, old rows cannot always be mapped perfectly to their original spreadsheet, so only newly linked batches provide exact batch deletion.
