PS ASSISTANT V1.5 - CLOUDFLARE LIVE BUILD

THIS BUILD IS READY FOR WRANGLER DEPLOYMENT.

IMPORTANT BEFORE DEPLOY:
1) Copy your CURRENT WORKING file:
   old-project\worker\.dev.vars
   into:
   this-project\worker\.dev.vars

2) Do NOT generate a new AUTH_SECRET before first production deploy.
   The existing remote D1 AI-provider credential was encrypted with your current secret.
   This deploy script reuses the same secret so the saved Kaggle provider keeps working.

3) Open PowerShell in the project root and run:
   powershell -ExecutionPolicy Bypass -File .\LIVE_DEPLOY.ps1

The script automatically:
- checks Wrangler login
- npm installs
- applies all D1 migrations to the existing remote database
- builds the React frontend
- uploads Admin/Developer/Auth secrets to Cloudflare
- deploys Worker + assets

LIVE ROUTES:
Admin login:      https://<your-worker>.workers.dev/
Admin dashboard:  https://<your-worker>.workers.dev/admin
Developer login:  https://<your-worker>.workers.dev/developer

KAGGLE AI:
The AI provider configuration is stored in the same remote D1 DB.
If you already saved Kaggle Qwen3 through Developer Panel, you do not need to paste it again after deployment.
If the Kaggle notebook restarts, Quick Tunnel URL/key can change; update the provider in Developer Panel and press Test.

IDENTITY BUILT IN:
Name question -> Main PS ASSISTANT V1.5 hoon.
Developer/creator question -> Mere developer Priyanshu Sharma hain.

PHONE NOTE:
This package includes phone-bridge\SETUP-USB-PHONE-BRIDGE.ps1 and phone-bridge\START-USB-PHONE-BRIDGE.ps1 for local Android USB dialing/status. The office PC and Admin page must remain on during scheduled calls. A normal USB data cable does not carry Android cellular call audio to the browser; two-way spoken AI calls need a compatible phone/headset-to-PC audio interface. See SETUP_AND_TROUBLESHOOTING.md.
