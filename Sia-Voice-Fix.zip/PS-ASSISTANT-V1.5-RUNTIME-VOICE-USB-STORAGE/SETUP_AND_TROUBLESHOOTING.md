# Latest calling update

Read CALLING_CATEGORY_CALLBACK_USB_SETUP.md for category-based conversation, callback consent, search activity and Android USB setup.

# Latest update

For general customer questions and verified market timings, read GENERAL_ANSWERS_MARKET_SEARCH_SETUP.md. Existing voice settings are preserved.

Latest update: [Protected training, reset/recovery and voice setup](PS_V1_5_TRAINING_PASSWORD_RESET_SETUP.md).

Latest update: see [PS V1.5 Teach Me / Customer Talk setup](PS_V1_5_TEACH_CUSTOMER_SETUP.md).

Latest update: see **ADMIN_TRAINING_CLIENT_VOICE_FIX_20261010.md**. Use only **kaggle/PS_ASSISTANT_KAGGLE_ADVANCED_20261015.ipynb** from this package.

Latest update: read `VIDEO_ERROR_FIX_20261010.md` first.

Latest calling flow update: read `CALLING_AGENT_FIX_20261009.md` first.

# PS ASSISTANT V1.5 — Setup and daily use

This package contains the Cloudflare Admin/Developer app, D1 migrations, the Kaggle Qwen3 + Whisper V3 notebook, and the office Android USB bridge.

## 1. Deploy the app to your existing Cloudflare project

1. Extract this ZIP into a new folder on the office PC.
2. Copy the existing working `worker/.dev.vars` from your current PS ASSISTANT project into this folder's `worker/.dev.vars`. Keep the current `AUTH_SECRET`; the saved AI-provider keys in D1 were encrypted with it. If that secret is lost, enter the provider API key again in Developer → AI Providers after deployment.
3. Install Node.js LTS if `node --version` and `npm --version` do not work.
4. Open PowerShell in the extracted project root and run:

   ```powershell
   powershell -ExecutionPolicy Bypass -File .\LIVE_DEPLOY.ps1
   ```

5. The script checks Wrangler login, installs dependencies, applies the included D1 migrations, builds the UI, syncs the existing secrets from `worker/.dev.vars`, and deploys the Worker and app. Save the Workers URL printed at the end.

Never send `worker/.dev.vars`, provider keys, or either access code in screenshots or chat.


## Add an AI API in Developer Console

The router supports **OpenAI-compatible Chat Completions**, **OpenAI Responses**, **Anthropic Messages**, and **Google Gemini Native GenerateContent**. This covers many providers that offer those protocols, including Groq, OpenRouter, DeepSeek, Mistral, Together AI, and Gemini's OpenAI-compatible endpoint. It cannot guarantee compatibility with every AI service: providers using an unrelated/custom protocol need their own adapter. It also supports Bearer, `x-api-key`, Azure-style `api-key`, Google `x-goog-api-key`, and `?key=` authentication. For most OpenAI-compatible services, enter the base URL ending in `/v1`; the app builds the endpoint from the selected protocol. Choose the API's exact model ID, auth method, and key, then select **Enabled**, **Primary**, **Save**, and **Test**. Keep working secondary text providers enabled so requests can fall back after a provider error. Gemini Native uses the Google API root `https://generativelanguage.googleapis.com/v1beta`, the exact model ID, and `x-goog-api-key`.

The app streams compatible responses so the first complete sentence can be spoken while the rest is generated. It normalizes common OpenAI, Responses, Gemini-compatible, and Anthropic response formats, and continues once if a provider explicitly reports that the answer was cut off. Provider speed, quota, API compatibility, and answer quality still depend on the provider/model and network; no app can make a slow or rate-limited API instant. Use the lowest-latency model your provider offers. Default provider timeout is 12 seconds.

Set **Speech recognition mode** to **Fast** for the browser's Hindi speech transcript, or **Accurate** to run a second server-side Whisper check before asking the AI. Fast is the default so every spoken turn does not wait for a second transcription request. If the browser keeps mishearing a name, select Accurate and keep **Server speech API** enabled.

### Dotwave Nemotron Live Voice

1. In Developer → **AI Providers**, choose preset **Dotwave Nemotron VoiceChat (Live)**.
2. Keep Provider type **Dotwave Live Voice · WebSocket**, URL `wss://api.dotwave.ai/v1/live/sessions`, model `nemotron-voicechat`, and Auth **Bearer**. Paste the private Dotwave API key, leave **Make primary** off, select **Enabled**, then **Save** and **Test**.
3. The Test button checks the key against Dotwave's model endpoint. To test audio, open an Admin call's **Phone AI** panel and press **Dotwave Live · English**; allow browser microphone access. The app creates a one-use temporary client secret on the server immediately before opening the WebSocket. The main API key is encrypted in D1 and is not sent to the browser.

Dotwave documents `nemotron-voicechat` as English (`en-US`) only, with a fixed `aria` voice, no custom instructions/training/tools/text input, and a 120-second session maximum. Its published introductory price is `$0.005/minute` while the session is open; check Dotwave's current billing page before use. This is browser microphone/speaker audio and does not route audio through the Android SIM/USB bridge. It is an optional live demo, not the Hindi Admin assistant. See [Dotwave model docs](https://dotwave.ai/docs/models/nvidia/nemotron-voicechat-11b/) and [Live API](https://dotwave.ai/docs/live/).

## 2. Start the Kaggle voice model

1. In Kaggle, open `kaggle/PS_ASSISTANT_QWEN3_VOICE_API_V3.ipynb` (also supplied separately).
2. Open Notebook settings and select a T4 GPU (T4x2 when available); enable Internet.
3. Use the included V3 notebook and run all cells from top to bottom. The dependency cell pins PyAV below version 19 and runs a generated-audio decoder smoke test. Wait for the final **Tunnel test: 200** and **OK** output. Copy the printed Base URL and newly generated API key privately.
4. On the deployed site, open `/developer` → **AI Providers**. Add or edit the Kaggle provider with the printed Base URL, model `ps-qwen3-4b`, and API key. Set Enabled and Primary, keep both cost values at `0`, then Save and Test Provider.
5. The same endpoint also supplies Faster-Whisper at `/v1/audio/transcriptions`. V3 is needed for the more accurate Hindi/Hinglish speech path.

The Kaggle model and Quick Tunnel are temporary. If the notebook stops, the health check fails, or Kaggle restarts, run all notebook cells again and replace the URL/key in Developer → AI Providers. The Developer Console now has **Guided Self-Diagnostics** to check D1, the Kaggle tunnel and the reported PyAV decoder version; use **Test** beside a provider to test model authentication. If Whisper reports an audio decoder mismatch, restart using this updated notebook. The app returns a spoken retry message when the provider is down; it cannot produce full model answers while Kaggle is offline. Kaggle enforces its own session and weekly GPU limits; no app-side setting can guarantee that a session remains open for four hours or extend Kaggle's limits. Four hours per day is 28 GPU hours per week, near its usual 30-hour quota; availability and the quota can vary.

If you pasted a Kaggle API key into a support message, stop that old notebook session, start a fresh session from the updated V3 notebook, and replace the provider URL/key. The new session generates a different key; do not share it in screenshots or chat.

## 3. Set up the office phone and voice

Do this on the Windows PC physically connected to the office Android phone:

1. On Android, enable Developer Options → USB debugging.
2. Connect the phone with a data-capable USB cable and run `phone-bridge\SETUP-USB-PHONE-BRIDGE.ps1` once. Accept the Android “Always allow from this computer” prompt.
3. Run `phone-bridge\START-USB-PHONE-BRIDGE.ps1` each workday, or optionally run `phone-bridge\INSTALL-WINDOWS-AUTOSTART.ps1` once to start the bridge with Windows.
4. Open the Admin site → Dashboard → Connect USB Phone. Allow microphone access, then switch **Auto Dial + AI** on.
5. In Developer → System Control, keep click sounds enabled and choose a low sound volume. Button clicks use a soft tick; connected calls play an ascending cue, completed calls a descending cue, and failed/no-answer calls a separate cue.
6. In Developer → System Control, set UI Motion to **Full** for the AOS.js reveal animations and Three.js background. The app still honors Windows/browser reduced-motion accessibility preference.
7. Test with the **Test Female Voice** button before a real call. Default neural Hindi voice is `hi-IN-SwaraNeural`; browser Hindi female voice is the fallback.

The voice polish in this build uses short Devanagari Hindi replies, streamed first-sentence playback, preloaded neural clips, and scheduled Web Audio playback to reduce gaps between clips. The default Swara rate/pitch is slightly faster and brighter (`+10%`, `+4Hz`). Audio says “Sia” instead of spelling the product version. Teach This stops the active microphone before saving; the complete saved text stays visible, with a short spoken confirmation. For the neural female voice, keep the office bridge running. The Admin UI says “Neural Hindi Female · Swara” when it is active; “Best available Hindi female browser voice” means it has fallen back to the browser. This update changes the app/provider router and D1 defaults. It does not require changing a Kaggle notebook or a healthy provider URL/key.

USB data controls dialing and call state. It does not carry ordinary cellular call audio from stock Android to a web page. Two-way spoken AI calls need a compatible phone/headset-to-PC audio interface, selected as the office PC's microphone and speaker.

## 4. Admin teaching and memory

- Admin Classroom is a private general assistant: it answers the Admin's question using the latest turns and approved company knowledge. Customer-call instructions no longer limit Admin's questions. If the AI provider is offline, the app reports that instead of pretending the same fallback is an answer.
- Ordinary questions and statements are answered without saving them to permanent memory. Voice memory is saved only after an explicit phrase such as **“Yaad rakho …”**, **“Isko yaad rakhna …”**, or **“Remember this …”**. After a successful save, Sia repeats what was saved aloud and shows it in the reply.
- **Teach This** is also an explicit save action; check the recognized text first. It saves the text shown in the Admin Classroom box.
- To remove one lesson by voice, say **“delete memory about [specific fact]”** or **“bhool jao [specific fact]”**. If more than one lesson matches, the assistant asks for a narrower phrase instead of deleting multiple entries.
- To clear every Admin lesson, say exactly **“confirm delete all admin lessons”**. This is limited to Admin training lessons; it does not erase call transcripts, FAQs, customer records, or speech corrections.
- Customer-derived suggestions stay in Customer Learning Inbox until an Admin approves them.
- If Whisper hears a name incorrectly, edit the recognized text and choose **Save Correction**. Later speech is corrected using that saved phrase.
- In Developer → **Call Chats**, delete a finished call's transcript and linked learning notes. Active/dialing calls are protected; the call/client operational record remains.

## 5. Fast troubleshooting

| Symptom | What to check |
| --- | --- |
| “Too many tokens per day” | The selected provider reached its quota. In Developer → AI Providers, make the running Kaggle Qwen3 provider Primary and use Test Provider. Short greetings now use an immediate local reply; longer questions still need a live provider. |
| Admin Classroom says “Admin access required” after Admin login | Deploy this ZIP with `LIVE_DEPLOY.ps1`, then hard-refresh the Admin page. Admin streaming requests now explicitly select the Admin cookie even if a Developer tab is also signed in. If it persists, sign out and back in to the Admin panel. |
| Admin keeps giving the same generic reply or says AI is not responding | Deploy this ZIP so migration `0010_admin_voice_reliability.sql` raises the Kaggle model timeout, then check Developer → AI Providers → Test and Guided Diagnostics. Restart Kaggle and save its new URL/key if its tunnel changed. The generic message is now an actual visible error instead of a fake successful AI answer. |
| Hindi voice breaks, repeats, or the screen stays on “thinking” | Deploy this ZIP and start the office PC voice bridge with `phone-bridge\START-USB-PHONE-BRIDGE.ps1`. It preloads neural clips and schedules audio continuously; the browser Hindi voice remains the fallback. |
| Dotwave key tests but live voice will not start | Confirm you chose the **Dotwave Live Voice · WebSocket** type and exact model `nemotron-voicechat`; launch Dotwave from Admin → Phone AI on the deployed HTTPS site, allow microphone access, and check Dotwave balance/capacity. Each Live session ends at 120 seconds. |
| Voice repeats a short phrase or sends the same turn twice | Reload after deployment. The Classroom now ignores repeated final recognition events and collapses a fully duplicated transcript before sending it. |
| Classroom reply area is blank or speech is choppy | Check Developer → AI Providers → Test and Guided Self-Diagnostics first. If Kaggle is offline, restart the V3 notebook and replace its temporary URL/key; the browser speech fallback should still work for the reply. |
| Test Provider fails after Kaggle restart | Rerun the V3 notebook and update the temporary Base URL and API key. |
| No Whisper transcript | Confirm V3 reached the final tunnel test, Server Speech Recognition is enabled, and the browser microphone permission is allowed. For a faster turn, use Fast speech recognition; selecting Accurate asks the configured speech endpoint to transcribe again and can add several seconds. If no AI text provider responds, the system reports the provider error; browser speech recognition only transcribes the user and cannot generate the AI answer. |
| Buttons make no sound | Click once inside the Admin page to unlock browser audio, then confirm click sounds are enabled and the volume is above zero in Developer → System Control. |
| Auto Dial will not start | Keep the Admin tab open, connect the USB phone, allow microphone access, check call hours and the active campaign, and leave the local bridge running. |
| AI speaks but cannot hear the caller | Check the PC's selected microphone and wired phone/headset audio interface. USB debugging alone does not route cellular audio. |
| Build/deploy fails | Read the first PowerShell error. Confirm Wrangler login, the current `worker/.dev.vars`, and network access for `npm install`; do not replace the existing D1 ID or `AUTH_SECRET` for an update deployment. |

## 2026-10-09: Agent Router / any OpenAI-compatible API and voice checks

1. Deploy this updated project with `powershell -ExecutionPolicy Bypass -File .\LIVE_DEPLOY.ps1` from its extracted root. Keep the existing Cloudflare D1 ID and `AUTH_SECRET` so stored credentials remain decryptable. The deployment applies migration `0015_fast_neural_voice.sql` to replace the old 1200-character speech chunks with 320-character segments.
2. In Developer → AI Providers choose **Agent Router**. Its preset fills `https://agentrouter.org/v1` into **API endpoint**. Put the exact model ID available for your key in **Model ID**, the token only in **API key**, **Bearer** in Auth, and leave **Region** empty. Enable and make it Primary, then Save Provider. The provider account may use a different host or model catalog; consult the dashboard's API docs if the preset endpoint does not match your account.
3. After saving, use **List Models** to read the provider's model IDs (some gateways do not offer this endpoint). Choose an actual available model ID, Save, then **Test**. The result or exact HTTP error stays visible underneath that provider. HTTP 401/403 means token or permissions, 404 usually endpoint/model, 429 quota or rate limit. A public promotional token or a `$1` quota is not a guarantee of unlimited access. For other providers choose the matching protocol and enter their documented URL, exact model, authentication type and private key. A WebSocket live speech endpoint is a different protocol from Chat Completions.
4. On the **same Windows PC and browser** used for Admin Classroom, run `phone-bridge\SETUP-USB-PHONE-BRIDGE.ps1` once and `phone-bridge\START-USB-PHONE-BRIDGE.ps1` each session. Check `http://127.0.0.1:8765/health` in that browser: `neural_tts` should be `true`. Developer → System Control should have **Neural Female Voice · Local Bridge**, endpoint `http://127.0.0.1:8765/tts`, voice `hi-IN-SwaraNeural`, chunk chars `320`. In Admin → USB Phone use **Test Female Voice**; it now reports whether neural audio actually played or whether a fallback/error occurred. A browser-only voice cannot be guaranteed to sound like a premium neural voice.
5. Admin Classroom → Start Live Training → ask a new question. Its text should stream, followed by neural speech. Use Developer → AI Providers → Test to diagnose errors, then correct the provider URL, key, or model. If Test passes but voice falls back, diagnose the local bridge separately. Streaming failover restarts the answer with the next enabled provider rather than stitching two models' responses together.

**Security:** The earlier gateway token posted in chat should be revoked and replaced before production use. Do not put tokens in source files or share screenshots showing them. Provider response time, quota and uptime depend on the external service; Kaggle runtime availability cannot be guaranteed by this deployment.

## 2026-10-09: Training Centre PDF, website, web search

Deploy this complete ZIP with the existing `worker/.dev.vars` and `powershell -ExecutionPolicy Bypass -File .\LIVE_DEPLOY.ps1`. Migration `0016_training_documents.sql` creates durable D1 tables for source documents and text chunks. Preserve the existing D1 database ID and `AUTH_SECRET`.

In Admin → Training Center, upload a searchable company plan PDF or paste the HTTPS URL of one public website page and click **Read & Save Page**. Text is extracted, split, and stored in D1. A scanned/image-only PDF must first be OCR'd into selectable text. PDF limits: 15 MB, 120 pages, up to 190,000 extracted characters; longer documents need splitting. Dynamic JavaScript-only websites and blocked pages cannot be extracted automatically. Saved sources can be deleted in the same panel, including all associated chunks.

For live web search, Developer → System Control → **Brave web search API key**, paste your own private key and Save. Admin → Training Center → **Search Web** shows snippets and source links. Admin reviews a result and clicks **Save Summary** to retain it in D1. Admin Classroom can say `search web for ...` to get fresh snippets for a question; they are not silently stored. Search service quotas and charges depend on your account.

The assistant retrieves relevant imported chunks for new questions and call turns. PDF/website contents are treated as reference material, not commands. Admin `Yaad rakho ...` / Teach This saves a durable lesson and confirms it aloud; `delete source <name>` removes one exactly matched source, and lesson deletion remains in the Classroom. Customer call insights still enter a review inbox and only become shared company facts after Admin approval. This is retrieval and saved memory, not an automatic change to Kaggle model weights.

Kaggle cannot be made always-on by an app or notebook. The included reusable Kaggle notebook caches build/model assets when Kaggle Files persistence works. Configure a second enabled AI provider for fallback; a stable tunnel URL does not keep a stopped model running.


## 2026-10-09 Client delete and automatic web search fix

- Admin → Client Database → Select All → Delete now deletes the selected clients in set-based D1 batches. Active/dialing calls are skipped. The UI verifies the server's remaining IDs and shows errors instead of claiming success.
- To remove a skipped client, end its call and delete again. Admin → Client Upload → Delete Batch removes its linked rows; deleting a client does not remove the import-history entry.
- Developer → System Control → Brave web search API key: paste your **own** key, set Automatic web search to On, and Save All System Controls. Current news, weather, scores, and other time-sensitive questions trigger search automatically in Admin training and customer replies. Explicit “web par …” searches still work. Web results are shown to the model as untrusted, time-sensitive snippets; they are not saved as approved company knowledge. If automatic search fails, the AI continues without web snippets; it should say it cannot verify current facts.
- The Kaggle notebook is the AI inference endpoint, not the web search service. Leave its configuration as before. The search key belongs only in the Developer panel.
- Extract this ZIP in a fresh folder, copy your existing `worker\.dev.vars` into the new folder, keep the same D1 binding in `worker\wrangler.jsonc`, then run `powershell -ExecutionPolicy Bypass -File .\LIVE_DEPLOY.ps1`. Do not create a new D1 database or overwrite the encryption secret. After deployment reload the Admin tab and check the live URL.


## Advanced conversation update
See `ADVANCED_RUNTIME_SETUP_20261009.md` for deletion password creation, mobile cloud voice, interruption, USB audio setup and verification details. Apply migration 0017 through LIVE_DEPLOY.ps1 before using this version.
