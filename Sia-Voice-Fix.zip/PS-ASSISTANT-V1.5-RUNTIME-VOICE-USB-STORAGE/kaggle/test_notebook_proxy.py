"""Offline regression tests; no GPU downloads or real provider calls."""
import ast, asyncio, json, math, pathlib, secrets, types, unittest, sys
from unittest.mock import patch

class HTTPException(Exception):
    def __init__(self,status_code,detail):self.status_code=status_code;self.detail=detail
class JSONResponse:
    def __init__(self,content,status_code=200):self.content=content;self.status_code=status_code
class StreamingResponse:
    def __init__(self,content,**kwargs):self.body_iterator=content
class App:
    def post(self,*args):return lambda f:f
class Request:
    def __init__(self,payload,invalid=False):self.payload=payload;self.invalid=invalid
    async def body(self):return b'{}'
    async def json(self):
        if self.invalid:raise ValueError('invalid JSON')
        return self.payload
class HTTPError(Exception):pass

nb=json.loads((pathlib.Path(__file__).parent/'PS_ASSISTANT_KAGGLE_ADVANCED_20261015.ipynb').read_text())
source=''.join(nb['cells'][6]['source'])
tree=ast.parse(source)
nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in ('finite_number','prepare_chat','require_key','chat','synthesize')]
policy=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='BASE_POLICY' for t in n.targets))
g={'HTTPException':HTTPException,'JSONResponse':JSONResponse,'StreamingResponse':StreamingResponse,
   'Response':lambda data,**kwargs:types.SimpleNamespace(body=data,**kwargs),'ENABLE_NEURAL_VOICE':True,'app':App(),'Request':Request,'Header':lambda x:x,'Optional':__import__('typing').Optional,
   'secrets':secrets,'API_KEY':'private-test-key','MODEL_ALIAS':'ps-qwen3-4b','math':math,'asyncio':asyncio,
   'LOCAL':'http://model.local','json':json}
exec(compile(ast.Module(body=[policy,*nodes],type_ignores=[]),'proxy-functions','exec'),g)
def body(**kwargs):return dict(model='ps-qwen3-4b',messages=[{'role':'system','content':'Use approved company facts.'},{'role':'user','content':'Aur batao kaise ho?'}],**kwargs)

class PrepareTests(unittest.TestCase):
    def test_context_preserved_and_defaults(self):
        raw=body();out=g['prepare_chat'](raw)
        self.assertEqual(out['messages'][1:],raw['messages']);self.assertEqual(len(raw['messages']),2)
        self.assertEqual(out['repeat_penalty'],1.12);self.assertFalse(out['chat_template_kwargs']['enable_thinking'])
    def test_no_old_600_token_cap(self):
        self.assertEqual(g['prepare_chat'](body(max_tokens=1400))['max_tokens'],1400)
        self.assertEqual(g['prepare_chat'](body(max_completion_tokens=9999))['max_tokens'],2048)
    def test_invalid_inputs_are_400(self):
        for raw in [[],body(max_tokens='oops'),body(temperature=float('nan')),body(stream='false'),{'model':'ps-qwen3-4b','messages':[{'role':'user','content':[]}]}]:
            with self.assertRaises(HTTPException) as c:g['prepare_chat'](raw)
            self.assertEqual(c.exception.status_code,400)
    def test_wrong_model_and_auth(self):
        raw=body();raw['model']='unknown'
        with self.assertRaises(HTTPException) as c:g['prepare_chat'](raw)
        self.assertEqual(c.exception.status_code,404)
        with self.assertRaises(HTTPException) as c:g['require_key']('Bearer wrong')
        self.assertEqual(c.exception.status_code,401)

class ProxyTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.closed=[];self.mode='ok';self.sem=asyncio.Semaphore(2);g['CHAT_SEM']=self.sem;g['TTS_SEM']=asyncio.Semaphore(2)
        owner=self
        class Upstream:
            status_code=200
            async def aread(self):
                if owner.mode=='read-error':raise HTTPError('disconnected')
                return b'{"choices":[{"message":{"content":"Namaste"},"finish_reason":"stop"}]}'
            async def aclose(self):owner.closed.append('upstream')
            async def aiter_bytes(self):
                yield b'data: {"choices":[{"delta":{"content":"Namaste"}}]}\n\n'
                if owner.mode=='stream-error':raise HTTPError('disconnected')
                yield b'data: [DONE]\n\n'
        class Client:
            def __init__(self,**kwargs):pass
            def build_request(self,*args,**kwargs):return kwargs
            async def send(self,*args,**kwargs):
                if owner.mode=='connect-error':raise HTTPError('connect')
                return Upstream()
            async def aclose(self):owner.closed.append('client')
        g['httpx']=types.SimpleNamespace(AsyncClient=Client,Timeout=lambda *a,**k:None,HTTPError=HTTPError)
    async def call(self,**kwargs):return await g['chat'](Request(body(**kwargs)),'Bearer private-test-key')
    async def test_nonstream_cleanup(self):
        r=await self.call();self.assertEqual(r.content['choices'][0]['message']['content'],'Namaste')
        self.assertEqual(self.sem._value,2);self.assertEqual(self.closed,['upstream','client'])
    async def test_errors_do_not_leak_slots(self):
        for mode in ['connect-error','read-error']:
            self.mode=mode
            with self.assertRaises(HTTPException) as c:await self.call()
            self.assertEqual(c.exception.status_code,503);self.assertEqual(self.sem._value,2)
    async def test_stream_disconnect_closes_upstream(self):
        r=await self.call(stream=True);self.assertEqual(self.sem._value,1)
        await anext(r.body_iterator);await r.body_iterator.aclose()
        self.assertEqual(self.sem._value,2);self.assertEqual(self.closed,['upstream','client'])
    async def test_stream_error_cleanup(self):
        self.mode='stream-error';r=await self.call(stream=True)
        with self.assertRaises(HTTPError):
            async for chunk in r.body_iterator:pass
        self.assertEqual(self.sem._value,2);self.assertEqual(self.closed,['upstream','client'])
    async def test_neural_voice_auth_and_cleanup(self):
        class Communicate:
            def __init__(self,*args,**kwargs):self.kwargs=kwargs
            async def stream(self):yield {'type':'audio','data':b'ID3mock-neural-audio'}
        with patch.dict(sys.modules,{'edge_tts':types.SimpleNamespace(Communicate=Communicate)}):
            r=await g['synthesize'](Request({'input':'नमस्ते','voice':'hi-IN-SwaraNeural','rate':'+10%','pitch':'+4Hz'}),'Bearer private-test-key')
            self.assertEqual(r.body,b'ID3mock-neural-audio');self.assertEqual(r.media_type,'audio/mpeg');self.assertEqual(g['TTS_SEM']._value,2)
    async def test_failed_neural_voice_releases_slot(self):
        class Communicate:
            def __init__(self,*args,**kwargs):pass
            async def stream(self):
                raise RuntimeError('upstream voice disconnected')
                yield
        with patch.dict(sys.modules,{'edge_tts':types.SimpleNamespace(Communicate=Communicate)}):
            with self.assertRaises(HTTPException) as c:await g['synthesize'](Request({'input':'नमस्ते'}),'Bearer private-test-key')
            self.assertEqual(c.exception.status_code,503);self.assertEqual(g['TTS_SEM']._value,2)
    async def test_neural_voice_input_validation(self):
        with self.assertRaises(HTTPException) as c:await g['synthesize'](Request({'input':'hi','rate':'too fast'}),'Bearer private-test-key')
        self.assertEqual(c.exception.status_code,400);self.assertEqual(g['TTS_SEM']._value,2)
        with self.assertRaises(HTTPException) as c:await g['synthesize'](Request({'input':'hi'}),'Bearer wrong')
        self.assertEqual(c.exception.status_code,401)
    async def test_invalid_json_does_not_acquire_slot(self):
        with self.assertRaises(HTTPException) as c:await g['chat'](Request(None,True),'Bearer private-test-key')
        self.assertEqual(c.exception.status_code,400);self.assertEqual(self.sem._value,2)

if __name__=='__main__':
    for i,c in enumerate(nb['cells']):
        if c['cell_type']=='code':compile(''.join(c['source']),f'cell-{i}','exec')
    unittest.main()
