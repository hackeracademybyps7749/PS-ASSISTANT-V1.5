# Kaggle voice runtime

Use [`PS_ASSISTANT_KAGGLE_ADVANCED_20261015.ipynb`](PS_ASSISTANT_KAGGLE_ADVANCED_20261015.ipynb). It is based on the user's uploaded notebook and repairs cached llama.cpp startup after Kaggle persistence restores file permissions or shared-library paths. Whisper transcription is enabled by default so the app can use Accurate speech mode on mobile browsers without built-in speech recognition.

Choose Kaggle Settings → GPU T4 x2, enable Internet, then Run All. Wait for the model/API health check and the final HTTPS tunnel check. Configure the printed `/v1` endpoint, model ID, and key in Developer → AI Providers. In Developer → System Control choose **Accurate · server transcription + browser fallback**. This mode downloads and loads Whisper on GPU 1, which adds first-run setup time. Fast mode continues to use native browser recognition where supported.

Keep the notebook session running during use. Kaggle persistence can retain model caches, but Kaggle can still end sessions for quota or idle limits. Lessons, PDFs, website sources, and approved knowledge are stored by the app Worker, not in Kaggle model weights. Keep a separate enabled text provider as a backup.
