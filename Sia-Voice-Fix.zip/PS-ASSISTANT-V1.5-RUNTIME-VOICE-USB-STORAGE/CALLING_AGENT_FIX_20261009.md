# PS ASSISTANT V1.5 — calling conversation update

## Apply this update

Extract into a new folder. Copy your existing `worker/.dev.vars` and keep the same Worker name and D1 database settings. Run from the extracted project root:

```powershell
powershell -ExecutionPolicy Bypass -File .\LIVE_DEPLOY.ps1
```

The deploy script applies migration `0018_call_voice_turns.sql` for server-side cancellation tracking. Refresh the live app after deployment. This does not replace your saved Admin lessons or deletion password. Use the latest reusable Kaggle notebook already supplied; it is included under `kaggle/PS_ASSISTANT_KAGGLE_REUSABLE_FAST_20261009.ipynb`. There is no need to recompile Kaggle because of this frontend/Worker update.

## Required setup for voice and search

- Company profile: enter the correct company name and approved services/prices.
- Developer System Control → Company name pronunciation: enter the name as you want it spoken, for example `ग्लोबल पी एस इन्फोटेक` for Global PS Infotech. This changes speech only. Use your actual company name.
- Desktop voice: start `phone-bridge/START-USB-PHONE-BRIDGE.ps1`, select Neural Female Voice / Local Bridge, `hi-IN-SwaraNeural`, and Save & test voice. Internet is required by the upstream synthesis service.
- Mobile or optional cloud voice: select a supported cloud speech engine, configure your own speech endpoint, key, model and feminine voice, then Save & test voice. A text-model API key does not necessarily support speech. Billing and quotas apply to the chosen service. Device/browser fallback is not guaranteed to be feminine or sound like a cloud voice.
- Brave Search API key: configure your own key and switch Automatic web search On. Without a valid key or quota, successful live web lookup is not available. Current facts must not be presented as verified when lookup fails.
- Voice interruption On. Use a headset or a clean echo-cancelled audio path. USB data alone controls Android dialing/status; cellular audio needs compatible phone–PC audio wiring.

## Conversation changes

The live call starts with a brief feminine AI greeting and asks permission to talk. The greeting uses the configured company name. Customer speech is combined across recognition fragments, with a short end-of-turn pause rather than starting a new request for each tiny final segment. New speech interrupts old playback; cancelled prepared audio cannot resume. Cancelled or superseded pending call turns are also blocked from saving stale full replies into the server transcript.

Completed answer sentences prepare their audio ahead of playback. The tail of a streamed answer is also spoken. A provider stream that disconnects without completion is rejected and can use the configured fallback provider. Gemini MAX_TOKENS is recognized and a bounded continuation is requested. Responses API reasoning events and terminal full-text copies are excluded from spoken deltas.

Automatic customer lookup now includes unmatched general factual questions as well as current information. During lookup the agent says “लाइन पर बने रहिए, मैं जानकारी चेक करके बताती हूँ।” The hold sentence is separate from the final answer. Admin Classroom streaming also reports lookup progress. Changing web facts remain references, not approved company terms.

Hindi prompts use feminine self-reference and prioritize the customer's latest question. Missing company facts require clarification or team follow-up, rather than inventing prices. Normal general knowledge can be answered normally. Company name pronunciation is applied to speech preparation.

## Learning

Admin “याद रखो …” and Teach this explicitly save facts, with a spoken Hindi confirmation. Ordinary questions are not treated as Admin teaching.

Customer turns also create persistent per-client, unverified conversation notes and a pending learning-inbox entry during the call. Review and approve reliable facts before sharing them as company knowledge. The configured model's neural weights are not trained by these notes. Deleted records still require the existing deletion password.

## Verified here

Production React build and Worker dry run passed. Local D1/provider fixtures cover protected persistent deletion, explicit teaching, live search progress, live customer notes, primary-provider failure after partial output, silent stream disconnect, fallback, Gemini answer continuation and Responses delta filtering. Voice fixtures cover combined recognition fragments, interruption, echo suppression, complete sentence playback, lookup announcements, pronunciation, audio preparation and stale prepared-audio cancellation.

Upstream services in these tests are mocked. Real voice quality, microphone recognition and live response speed still depend on your credentials, device, audio wiring, network and provider. This package does not clone a ChatGPT voice, guarantee perfect pronunciation on every device, or remove Kaggle session limits. A voice fallback label means the selected neural service was not successfully used; check the voice test before customer calls.
