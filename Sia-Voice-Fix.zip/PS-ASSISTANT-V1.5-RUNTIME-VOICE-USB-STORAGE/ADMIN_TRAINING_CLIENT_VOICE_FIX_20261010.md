# PS ASSISTANT V1.5 — Admin, PDF, client commands and mobile neural voice

Use this complete project update together with `kaggle/PS_ASSISTANT_KAGGLE_ADVANCED_20261015.ipynb`. This package contains one current Kaggle notebook to avoid choosing an older one. The latest notebook adds an authenticated speech endpoint as well as text replies.

## Deploy the website/Worker

1. Extract into a fresh folder. Keep your previous working folder as a backup.
2. Copy the previous `worker/.dev.vars` into the new `worker` folder. Preserve the same AUTH_SECRET and CONFIG_ENCRYPTION_KEY. Keep your existing Worker name, domain routes, D1 database name and database ID in `worker/wrangler.toml`; don't replace an existing database with a new one.
3. In VS Code Terminal / PowerShell at the project root, run:

```powershell
powershell -ExecutionPolicy Bypass -File .\LIVE_DEPLOY.ps1
```

The script installs packages, applies existing migrations through 0018, builds assets, syncs configured secrets and deploys to Cloudflare. No new migration is required for the changes in this update, but previous migrations must already exist. Refresh the live page after deployment. Nothing was deployed remotely during development here.

## Kaggle and voice — important on a mobile phone

1. Import the current notebook, GPU T4 x2, Internet ON, Persistence Files only. Prefer reusing your existing notebook/cache; a new notebook does not automatically inherit old working files.
2. Keep `PROFILE='fast'`, `ENABLE_WHISPER=False`, `ENABLE_NEURAL_VOICE=True`. Run All. Fast uses the old 4B model cache when restored; Quality uses 8B and needs its own first download. Optional Whisper adds a download/load and is only needed for Accurate server recognition.
3. Save the last cell's endpoint ending `/v1`, model ID and private API key in Developer → AI Providers → OpenAI-compatible. Enable it, then List Models and Test.
4. Developer → System Control → Cloud voice → **Use saved Kaggle neural voice**. This copies the saved enabled Kaggle provider's speech endpoint and encrypted key on the server. No need to expose or retype the key. Then **Save & test voice**. If you have several Kaggle providers, the enabled primary/highest-priority matching provider is selected.
5. The preset uses `ps-swara-neural`, `hi-IN-SwaraNeural`, rate `+10%`, pitch `+4Hz`, speech URL `https://YOUR-KAGGLE-ORIGIN/v1/audio/speech`. The notebook also prints these fields and displays a sample to listen to.
6. After a temporary tunnel URL/key changes, update the text provider and press Use saved Kaggle neural voice again. Stop and restart the Admin conversation to load the new voice settings.
7. Mobile phones cannot reach an office PC through their own `127.0.0.1`. Kaggle's public HTTPS speech endpoint avoids that localhost requirement. "Neural AI voice" means synthesis was used; "Device voice fallback" means it was unavailable. A valid model endpoint alone does not prove the speech service works.
8. The neural endpoint uses the external Edge online voice through edge-tts. It needs Internet access and can fail or change; it is not a guaranteed commercial speech service or a clone of ChatGPT Sol. You can still configure another supported cloud TTS service. Kaggle quota/idle/session limits cannot be disabled by this notebook.

## Admin conversation and teaching

Admin Classroom accepts general questions, company questions and explicit teaching. Customer calls use a separate service-focused prompt.

- "वेबसाइट क्या होती है" returns a correct short definition without waiting for model generation; requested reference lookup can complete while the definition is spoken.
- Ordinary questions do not save a lesson. "याद रखो हमारी वेबसाइट योजना की कीमत 15000 रुपये है" saves the complete fact and confirms exactly what was saved.
- Teach this saves the typed statement. A bare number or question without its answer requests clarification instead of creating an unusable lesson.
- Saved lessons and customer learning suggestions appear in the classroom. Customer notes require approval before becoming shared company knowledge; this is retrieval memory, not automatic weight training.
- Save correction is for misheard words: edit the detected text first, then save the mapping. Never replace a complete unrelated sentence with a correction; it affects future recognition too.
- Recognition now ignores duplicate final events and merges cumulative fragments instead of concatenating repeated prefixes. Hindi combining marks are preserved in recognition, matching and retrieval.
- Barge-in still depends on the phone/browser and microphone echo. A headset helps prevent speaker audio from being heard as a new turn. Use Stop & listen when needed. Real device listening must be tested; no software change guarantees perfect hearing.

## Call script training

In Talk & Teach → Call greeting & ending, edit:

- Opening line after the transparent AI introduction.
- Service conversation guidance: services to discuss, questions to ask, approved next steps. It supports up to 4000 characters and is used naturally, not recited at every turn.
- Closing line before ending the call.

Save call training. New calls read these values. Call replies are focused on the company's offered services and relevant customer requirements. Common unrelated topics redirect to services without web search. Other scope decisions use the model instructions and still depend on model compliance. Admin answers remain general-purpose and aren't bound to the customer sales script.

## PDF, website and saved knowledge

Inside Talk & Teach, or the existing Documents knowledge panel:

1. Choose a searchable PDF.
2. Press **Inspect & Save PDF**. The assistant announces that it is reading; the panel shows page progress. It confirms success only after the extracted text is saved.
3. **Inspect** displays the actual stored text, ten parts per page. Previous/Next makes all parts of that source available to review. This is source inspection, not a claim that an AI has verified every fact.
4. Ask about its plans or wording. Relevant document excerpts are retrieved into answers. Large documents are chunked; vague questions may need a plan name or the exact subject.
5. Website Read & Save reads one public HTML page. JavaScript-only pages and scanned PDFs need suitable exported text/OCR first.
6. Deleting a source removes its chunks. The classroom clears previous answer history after knowledge changes, so deleted facts are not reused from old conversation context.

Searchable PDFs: up to 15 MB, 120 pages and 190,000 extracted characters. Saved source and lesson lists load 100 at a time. Use Load more to see older entries. Inspect paginates all chunks in a selected source. Keep filenames distinctive for voice deletion.

## Web search and Maps

Full web/current searches use the configured Brave Search key. Without it, general explanatory queries can retrieve limited Wikipedia reference extracts with visible source links. That fallback cannot verify today's weather, private company prices, current news, or every website. Failed/current lookups must not be represented as verified results.

Maps buttons open a Google Maps search based on the uploaded business name/address or the typed query. They do not scrape Google Maps, resolve a verified Place ID, or import fresh phone numbers automatically. Client phone replies come from your uploaded client records.

## Uploaded client lookup and protected deletion

Examples in Admin Classroom:

- `Sunrise Cafe ka number batao`
- `client Sunrise Cafe ka address batao`
- `client ID 123 ka number batao`
- After selecting one client: `इसका नंबर बताओ`
- `Sunrise Cafe ka data delete karo`
- `delete client ID 123`
- `delete pdf Company website plan.pdf`
- `delete memory about वेबसाइट योजना` (one matching lesson)

A matching client is read directly from the database; the model doesn't guess its number. Multiple matches show selectable records and ask for an exact name/ID. Client deletion asks for the configured owner password and refuses active/dialing calls. It removes the client, related calls and dependent notes; separately taught company lessons/documents remain independent and need their own deletion command. Names in a different script may not match automatically: use the stored spelling or ID.

Create the owner deletion password in Developer → System Control first. All destructive actions still use password authorization and one-use grants. Deleted client commands do not add a learning note.

## Verification

Passed locally: frontend production build; Worker Wrangler dry run; Worker/D1 request fixtures including client ambiguity, password deletion, active-call protection, source inspection, deleted-PDF recall, Hindi retrieval, reference fallback, service scope and encrypted Kaggle voice preset; microphone transcript/interruption mocks; audio prefetch mocks; 12 notebook Python request/speech tests and compilation of every notebook cell.

Not verified here: actual Kaggle GPU session, live model factual accuracy/latency, external neural audio quality, browser mobile layout on a real device, USB SIM audio routing and end-to-end live calls. Run the notebook's sample, provider test and voice test before calling customers. Keep a tested secondary provider for availability.
