# PS ASSISTANT V1.5 — Implementation Map (Private Provider Build)

## Admin Panel

Admin sees business operations only:
- Dashboard
- client Excel upload (`Business Name`, `Contact Number`, `Address`, `Category`)
- formatted Excel export
- call scheduler/retry controls
- client queue
- live call transcript
- post-call summary and 1–5 star lead score
- follow-ups
- unanswered questions / Teach SIA
- voice training
- company knowledge, pricing, FAQs and conversation rules

No provider/model/cost/developer information is rendered in Admin UI.

## Developer Console

Separate engineering authentication controls access to:
- per-call technical cost
- token/request usage
- model/provider configuration visibility
- latency/errors
- system health
- credit estimates
- import pipeline
- queue/campaign diagnostics
- logs

Developer console is lazy-loaded into a separate production chunk and has no Admin navigation link.

## Private backend flow

1. Admin browser authenticates.
2. Worker creates an HttpOnly session cookie.
3. Browser calls generic business endpoints.
4. Worker reads approved company knowledge from D1.
5. Worker privately constructs the PS ASSISTANT V1.5 system instruction.
6. Worker calls the configured AI provider using a Worker secret.
7. Technical tokens/cost/latency are logged to `ai_usage`.
8. Admin receives only the response text and help-needed flag.
9. Unknown company question creates an `unanswered_questions` item.
10. Admin-approved answer is saved into FAQs/knowledge.

## Source protection

- no API keys in frontend
- no provider IDs in Admin UI
- HttpOnly role session
- server-side developer authorization
- source maps disabled
- production JS minified
- engineering console split into its own lazy chunk
- no Developer link in Admin UI
- noindex/noarchive headers

The browser must receive frontend code, so perfect client-side secrecy is impossible. The secure design is to keep secrets and sensitive implementation on the Worker and not distribute owner source code to admins.
