# PS V1.5 · Protected Admin training and recovery

## Deploy
Extract into a fresh folder. Copy the working worker/wrangler.toml (same D1 database) and worker/.dev.vars from the previous version. Preserve AUTH_SECRET and CONFIG_ENCRYPTION_KEY. In the project root run:

```powershell
powershell -ExecutionPolicy Bypass -File .\LIVE_DEPLOY.ps1
```

This applies migrations through 0020, builds the app and deploys. Keep the previous working folder as a backup. No live deployment was performed while preparing this ZIP.

## Owner setup
Open your existing /developer panel > System Control > Training access & recovery. Set a new 8–128 character Training password. This is separate from Admin login and the deletion password. Changing it revokes every training unlock. Keep/set your separate deletion password too: resetting and recovering training require it.

Admin > Training Center asks for the Training password. The unlock is tied to the Admin session, expires after one hour, and can be closed with Lock Training Centre. Training writes, document upload/inspection, company knowledge edits and approved FAQ answers also require this access on the server. Incorrect password attempts are rate limited. Hashes never appear in UI/API settings.

## Talk, teach and check saved data
- Teach Me answers normal questions. “याद रखो …” and Teach this save a complete approved fact and confirm what was saved.
- Automatically save Admin teaching is enabled initially and can be switched off. It saves clear company statements/call guidance, not questions or casual conversation. Review/delete mistaken statements from Saved lessons. Customer Talk cannot change approved memory even if someone says “remember” or “delete”.
- Teach employees, services, company timings/address, history and approved prices as statements. Saved company knowledge, lessons, documents and learning inbox appear together in the classroom. Customer conversation notes require Admin approval before becoming shared company knowledge.
- This is persistent knowledge memory used when answering, not automatic retraining of model weights. Cloudflare D1 stores it; restarting/stopping Kaggle does not erase it. The selected model must be online for model-generated replies; keeping memory does not keep an offline model running.

Examples (say “याद रखो” before these):

```text
हमारे कर्मचारी रोहन software development करते हैं।
company name: GENZ TECH SOLUTION
co-founder: Vijay Singh Sir
address: Transport Nagar, Lucknow
working hours: Monday to Saturday, 10 AM to 6 PM
company introduction: हम व्यवसायों के लिए वेबसाइट और software बनाते हैं।
company pronunciation: जेन ज़ी टेक सॉल्यूशन
opening line: {business_name} के लिए वेबसाइट या software development की जरूरत है?
closing line: समय देने के लिए धन्यवाद, आपका दिन अच्छा रहे।
call rule: पहले ग्राहक की जरूरत समझो, फिर एक सवाल पूछो।
```

Labelled company/profile/script statements update the relevant operational fields as well as the saved lesson. Other facts remain searchable lessons. They must be accurate and approved: do not claim “cheapest anywhere” as a verified comparison without evidence; use your approved affordable-price wording and actual prices. The assistant is instructed to avoid emoji, emoji names and stage directions; speech also strips emoji characters.

## Pronunciation and call scripts
In Teach Me > Call greeting & ending, set Company name pronunciation, use Listen to company pronunciation, and Save call training. The saved pronunciation is used by the normal TTS path. Try जेन ज़ी टेक सॉल्यूशन and adjust it to the company's preferred pronunciation.

Opening supports {business_name}, {category} and {company_name}. Real calls read the customer business/category from uploaded Excel records and get a fresh personalized greeting per call. The AI identifies itself as an AI representative, uses the saved opening, answers the latest customer question first, and asks relevant service/requirement questions. It must not invent missing category details, prices, employees, bookings or approved company policies. Customer Talk remains a practice mode and never dials a real number.

Phone dialing still uses the existing Queue/Scheduler and Android USB Phone Bridge. Keep the Admin tab and bridge open; phone call audio needs the compatible audio path documented in SETUP_AND_TROUBLESHOOTING.md.

## Reset and recovery
Admin > Teach Me > Reset training memory: type RESET TRAINING and enter the deletion password. This clears company profile, services, FAQs, rules, learned lessons, corrections, PDFs/website sources, call script, pronunciation override, customer memory notes, learning inbox and training audit entries. It stops while calls are active/dialing. Client Excel records, call history, provider/API keys, passwords and technical agent identity remain.

Each reset first captures an atomic recovery snapshot in D1. Last five reset snapshots are kept. If a snapshot would exceed the configured safe row-size limit, reset refuses and leaves the knowledge untouched; split/reduce/export large documents first. Only /developer > Training access & recovery lists the backups and offers Recover. Type RESTORE TRAINING and enter the deletion password. Recovery replaces any new training with that snapshot. Notes for deleted clients and learning suggestions for deleted calls are skipped; a note for an existing client can be restored without its deleted call link. These recovery snapshots are intentionally retained; reset is not permanent erasure from backups.

Refresh an older Admin tab after recovery. Conversation history from an earlier memory revision is excluded from future teaching/practice replies, preventing old reset facts from returning as chat context.

## Voice and Kaggle
Use the updated notebook at kaggle/PS_ASSISTANT_KAGGLE_ADVANCED_20261015.ipynb for Whisper-backed accurate recognition and mobile browser fallback. If it is already running, leave it running. After its URL/key changes update the provider and reapply the saved Kaggle neural-voice preset.

Voice groups nearby complete sentences with at most a short batching wait instead of producing one tiny clip for every sentence. It prepares audio ahead, removes bounded near-silent encoder padding, cancels stale replies/audio on interruption, and strips emoji. This reduces gaps; speed and live audio quality still depend on the selected model, network, speech provider, microphone and phone audio setup. It does not clone a real person or guarantee instant uninterrupted speech.

## Validation
Production frontend build, Worker deployment dry run, password/authorization/memory/reset/recovery tests, conversational interruption tests and pronunciation/audio-prefetch tests passed. Security tests cover separate training credentials, revocation, lock, rate limiting, role boundaries, customer mutation prevention, complete snapshot recovery, active-call protection and preservation of clients/provider settings. Audio tests use mocks. Actual browser/Android call acoustics, live Gemini/TTS network streaming and Kaggle GPU operation must be checked on your equipment.
