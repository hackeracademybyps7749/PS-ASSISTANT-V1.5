$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

Write-Host "" 
Write-Host "==============================================" -ForegroundColor Cyan
Write-Host " PS ASSISTANT V1.5 - CLOUDFLARE LIVE DEPLOY " -ForegroundColor Cyan
Write-Host "==============================================" -ForegroundColor Cyan

function Read-DevVars([string]$path) {
  $map = @{}
  if (-not (Test-Path $path)) { return $map }
  foreach ($line in Get-Content $path) {
    $t = $line.Trim()
    if (-not $t -or $t.StartsWith('#') -or -not $t.Contains('=')) { continue }
    $i = $t.IndexOf('=')
    $k = $t.Substring(0,$i).Trim()
    $v = $t.Substring($i+1).Trim()
    if (($v.StartsWith('"') -and $v.EndsWith('"')) -or ($v.StartsWith("'") -and $v.EndsWith("'"))) {
      $v = $v.Substring(1,$v.Length-2)
    }
    $map[$k] = $v
  }
  return $map
}

function Put-Secret([string]$name,[string]$value) {
  if ([string]::IsNullOrWhiteSpace($value)) { return }
  Write-Host "Uploading secret: $name" -ForegroundColor DarkCyan
  $value | npx wrangler secret put $name
  if ($LASTEXITCODE -ne 0) { throw "Failed to upload Cloudflare secret $name" }
}

Write-Host "[1/7] Checking Node/npm..." -ForegroundColor Yellow
node --version
npm --version

Write-Host "[2/7] Installing dependencies..." -ForegroundColor Yellow
npm install --include=dev --bin-links=true
if ($LASTEXITCODE -ne 0) { throw "Dependency installation failed. Close apps locking node_modules and retry." }

Write-Host "Checking Cloudflare login..." -ForegroundColor Yellow
npx wrangler whoami
if ($LASTEXITCODE -ne 0) {
  Write-Host "Cloudflare login required. Browser will open now..." -ForegroundColor Yellow
  npx wrangler login
  if ($LASTEXITCODE -ne 0) { throw "Wrangler login failed" }
}

$devVarsPath = Join-Path $root 'worker\.dev.vars'
$vars = Read-DevVars $devVarsPath
foreach ($required in @('ADMIN_ACCESS_CODE','DEV_ACCESS_CODE','AUTH_SECRET')) {
  if (-not $vars.ContainsKey($required) -or [string]::IsNullOrWhiteSpace($vars[$required])) {
    throw "Missing $required in worker\.dev.vars. Copy your working .dev.vars into this project's worker folder first."
  }
}

Write-Host "[3/7] Dependencies and configuration ready." -ForegroundColor Yellow

Write-Host "[4/7] Applying remote D1 migrations..." -ForegroundColor Yellow
Set-Location (Join-Path $root 'worker')
npx wrangler d1 migrations apply DB --remote
if ($LASTEXITCODE -ne 0) { throw "D1 migration failed" }

Write-Host "[5/7] Building production frontend..." -ForegroundColor Yellow
Set-Location (Join-Path $root 'app')
npm run build
if ($LASTEXITCODE -ne 0) { throw "Frontend build failed" }
if (-not (Test-Path (Join-Path $root 'app\dist\index.html'))) { throw "app\dist\index.html was not created" }

Write-Host "[6/7] Syncing production secrets from worker\.dev.vars..." -ForegroundColor Yellow
Set-Location (Join-Path $root 'worker')
# Keep AUTH_SECRET identical to local so AI-provider keys already encrypted in remote D1 remain decryptable.
Put-Secret 'ADMIN_ACCESS_CODE' $vars['ADMIN_ACCESS_CODE']
Put-Secret 'DEV_ACCESS_CODE' $vars['DEV_ACCESS_CODE']
Put-Secret 'AUTH_SECRET' $vars['AUTH_SECRET']
if ($vars.ContainsKey('CONFIG_ENCRYPTION_KEY')) { Put-Secret 'CONFIG_ENCRYPTION_KEY' $vars['CONFIG_ENCRYPTION_KEY'] }
if ($vars.ContainsKey('AWS_BEDROCK_API_KEY')) { Put-Secret 'AWS_BEDROCK_API_KEY' $vars['AWS_BEDROCK_API_KEY'] }
if ($vars.ContainsKey('CALL_BRIDGE_TOKEN')) { Put-Secret 'CALL_BRIDGE_TOKEN' $vars['CALL_BRIDGE_TOKEN'] }

Write-Host "[7/7] Deploying Worker + React assets..." -ForegroundColor Yellow
npx wrangler deploy
if ($LASTEXITCODE -ne 0) { throw "Cloudflare deployment failed" }

Write-Host "" 
Write-Host "DEPLOYMENT COMPLETE" -ForegroundColor Green
Write-Host "Admin:     open the workers.dev URL printed above" -ForegroundColor Green
Write-Host "Developer: add /developer to the same URL" -ForegroundColor Green
Write-Host "" 
Write-Host "Your AI Providers are stored in the remote D1 database, so the Kaggle provider saved in Developer Panel remains available after deploy." -ForegroundColor Cyan
Write-Host "If Kaggle restarts, only update its new tunnel URL/API key in /developer -> AI Providers." -ForegroundColor Cyan
